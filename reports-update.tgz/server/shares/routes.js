"use strict";
// Stratus Weather Server
// Created by Lukas Esterhuizen
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const crypto_1 = require("crypto");
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const db_1 = require("../db");
const postgres = __importStar(require("../db-postgres"));
const localAuth_1 = require("../localAuth");
const localStorage_1 = require("../localStorage");
const router = (0, express_1.Router)();
const usePostgres = postgres.isPostgresEnabled();
// Abstraction layer: use PostgreSQL or SQLite
async function dbCreateShare(share) {
    if (usePostgres) {
        return postgres.pgCreateShare({
            station_id: share.station_id,
            share_token: share.share_token,
            slug: share.slug,
            name: share.name || 'Shared Dashboard',
            email: share.email,
            access_level: share.access_level || 'viewer',
            password: share.password,
            expires_at: share.expires_at,
            is_active: share.is_active === 1 || share.is_active === true,
            access_count: share.access_count || 0,
            created_by: share.created_by || 'admin',
        });
    }
    return (0, db_1.createShare)(share);
}
async function dbGetShareByToken(token) {
    if (usePostgres) {
        const row = await postgres.pgGetShareByToken(token);
        if (!row)
            return null;
        return {
            ...row,
            is_active: row.is_active ? 1 : 0,
        };
    }
    return (0, db_1.getShareByToken)(token);
}
async function dbGetShareBySlug(slug) {
    if (usePostgres) {
        const row = await postgres.pgGetShareBySlug(slug);
        if (!row)
            return null;
        return {
            ...row,
            is_active: row.is_active ? 1 : 0,
        };
    }
    // SQLite fallback: not supported, return null
    return null;
}
async function dbGetSharesByStation(stationId) {
    if (usePostgres) {
        const rows = await postgres.pgGetSharesByStation(stationId);
        return rows.map(row => ({
            ...row,
            is_active: row.is_active ? 1 : 0,
        }));
    }
    return (0, db_1.getSharesByStation)(stationId);
}
async function dbUpdateShare(token, updates) {
    if (usePostgres) {
        return postgres.pgUpdateShare(token, updates);
    }
    (0, db_1.updateShare)(token, updates);
}
async function dbDeleteShare(token) {
    if (usePostgres) {
        return postgres.pgDeleteShare(token);
    }
    (0, db_1.deleteShare)(token);
}
// Number of salt rounds for bcrypt
const SALT_ROUNDS = 10;
// Validated share sessions: maps "shareToken:sessionId" to expiry timestamp
// When a password-protected share is validated, a session is created
const validatedSessions = new Map();
// Generate a session ID for validated share access
const generateSessionId = () => {
    return (0, crypto_1.randomBytes)(24).toString('hex');
};
// Session duration: 24 hours
const SESSION_DURATION_MS = 24 * 60 * 60 * 1000;
// Generate a unique share token
const generateShareToken = () => {
    return (0, crypto_1.randomBytes)(16).toString('hex');
};
// Generate a URL-safe slug from a string
const generateSlug = (text) => {
    return text
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-|-$/g, '')
        .substring(0, 60);
};
// Hash a password using bcrypt
const hashPassword = async (password) => {
    return bcryptjs_1.default.hash(password, SALT_ROUNDS);
};
// Verify a password against a hash
const verifyPassword = async (password, hash) => {
    return bcryptjs_1.default.compare(password, hash);
};
// Create a new share link for a station (requires authentication)
router.post('/stations/:stationId/shares', localAuth_1.isAuthenticated, async (req, res) => {
    try {
        const { stationId } = req.params;
        const { name, email, accessLevel = 'viewer', password, expiresAt, slug: requestedSlug } = req.body;
        const shareToken = generateShareToken();
        // Generate or validate slug
        let slug;
        if (requestedSlug) {
            slug = generateSlug(requestedSlug);
            // Check for slug collision
            const existing = await dbGetShareBySlug(slug);
            if (existing) {
                return res.status(409).json({ success: false, error: 'This friendly URL is already in use. Please choose a different one.' });
            }
        }
        // Hash password if provided
        const hashedPassword = password ? await hashPassword(password) : undefined;
        const share = {
            station_id: parseInt(stationId),
            share_token: shareToken,
            slug,
            name: name || 'Shared Dashboard',
            email,
            access_level: accessLevel,
            password: hashedPassword,
            expires_at: expiresAt || undefined,
            is_active: 1,
            access_count: 0,
            created_by: 'admin',
        };
        await dbCreateShare(share);
        // Return share info with the full URL (prefer slug URL if available)
        const shareUrl = slug ? `/${slug}` : `/shared/${shareToken}`;
        res.json({
            success: true,
            share: {
                id: share.share_token,
                stationId: share.station_id,
                shareToken: share.share_token,
                slug: slug,
                name: share.name,
                email: share.email,
                accessLevel: share.access_level,
                password: password ? '••••••' : undefined,
                expiresAt: share.expires_at,
                isActive: share.is_active === 1,
                accessCount: share.access_count,
                createdBy: share.created_by,
                shareUrl,
            },
        });
    }
    catch (error) {
        console.error('Error creating share:', error);
        res.status(500).json({ success: false, error: 'Failed to create share link' });
    }
});
// Get all shares for a station (requires authentication)
router.get('/stations/:stationId/shares', localAuth_1.isAuthenticated, async (req, res) => {
    try {
        const { stationId } = req.params;
        const stationIdNum = parseInt(stationId);
        const dbShares = await dbGetSharesByStation(stationIdNum);
        const stationShares = dbShares.map(s => ({
            id: s.share_token,
            stationId: s.station_id,
            shareToken: s.share_token,
            slug: s.slug,
            name: s.name,
            email: s.email,
            accessLevel: s.access_level,
            password: s.password ? '••••••' : undefined,
            expiresAt: s.expires_at,
            isActive: s.is_active === 1,
            lastAccessedAt: s.last_accessed_at,
            accessCount: s.access_count,
            createdBy: s.created_by,
            createdAt: s.created_at,
            updatedAt: s.updated_at,
            shareUrl: s.slug ? `/${s.slug}` : `/shared/${s.share_token}`,
        }));
        res.json({ success: true, shares: stationShares });
    }
    catch (error) {
        console.error('Error getting shares:', error);
        res.status(500).json({ success: false, error: 'Failed to get shares' });
    }
});
// Resolve a friendly slug to its share token (public)
// Must be defined BEFORE /shares/:shareToken to avoid conflict
router.get('/shares/resolve/:slug', async (req, res) => {
    try {
        const { slug } = req.params;
        const share = await dbGetShareBySlug(slug);
        if (!share) {
            return res.status(404).json({ success: false, error: 'Share not found' });
        }
        if (share.is_active !== 1) {
            return res.status(403).json({ success: false, error: 'Share link is no longer active' });
        }
        if (share.expires_at && new Date() > new Date(share.expires_at)) {
            return res.status(403).json({ success: false, error: 'Share link has expired' });
        }
        res.json({
            success: true,
            shareToken: share.share_token,
            share: {
                stationId: share.station_id,
                name: share.name,
                accessLevel: share.access_level,
                requiresPassword: !!share.password,
            },
        });
    }
    catch (error) {
        console.error('Error resolving slug:', error);
        res.status(500).json({ success: false, error: 'Failed to resolve share link' });
    }
});
// Validate a share token and get access
router.post('/shares/:shareToken/validate', async (req, res) => {
    try {
        const { shareToken } = req.params;
        const { password } = req.body;
        const share = await dbGetShareByToken(shareToken);
        if (!share) {
            return res.status(404).json({ success: false, error: 'Share link not found' });
        }
        if (share.is_active !== 1) {
            return res.status(403).json({ success: false, error: 'Share link is no longer active' });
        }
        if (share.expires_at && new Date() > new Date(share.expires_at)) {
            return res.status(403).json({ success: false, error: 'Share link has expired' });
        }
        // Verify password using bcrypt if share has a password
        if (share.password) {
            if (!password) {
                return res.status(401).json({ success: false, error: 'Password required', requiresPassword: true });
            }
            const isValidPassword = await verifyPassword(password, share.password);
            if (!isValidPassword) {
                return res.status(401).json({ success: false, error: 'Invalid password', requiresPassword: true });
            }
        }
        // Update access stats
        await dbUpdateShare(shareToken, {
            last_accessed_at: new Date().toISOString(),
            access_count: (share.access_count || 0) + 1
        });
        // Create a session token for password-protected shares
        let sessionToken;
        if (share.password) {
            sessionToken = generateSessionId();
            const sessionKey = `${shareToken}:${sessionToken}`;
            validatedSessions.set(sessionKey, Date.now() + SESSION_DURATION_MS);
        }
        res.json({
            success: true,
            sessionToken,
            access: {
                stationId: share.station_id,
                accessLevel: share.access_level,
                name: share.name,
            },
        });
    }
    catch (error) {
        console.error('Error validating share:', error);
        res.status(500).json({ success: false, error: 'Failed to validate share' });
    }
});
// Get share info (public endpoint, minimal info)
router.get('/shares/:shareToken', async (req, res) => {
    try {
        const { shareToken } = req.params;
        const share = await dbGetShareByToken(shareToken);
        if (!share) {
            return res.status(404).json({ success: false, error: 'Share link not found' });
        }
        if (share.is_active !== 1) {
            return res.status(403).json({ success: false, error: 'Share link is no longer active' });
        }
        if (share.expires_at && new Date() > new Date(share.expires_at)) {
            return res.status(403).json({ success: false, error: 'Share link has expired' });
        }
        res.json({
            success: true,
            share: {
                stationId: share.station_id,
                name: share.name,
                accessLevel: share.access_level,
                requiresPassword: !!share.password,
            },
        });
    }
    catch (error) {
        console.error('Error getting share:', error);
        res.status(500).json({ success: false, error: 'Failed to get share info' });
    }
});
// Update a share (requires authentication)
router.patch('/shares/:shareToken', localAuth_1.isAuthenticated, async (req, res) => {
    try {
        const { shareToken } = req.params;
        const share = await dbGetShareByToken(shareToken);
        if (!share) {
            return res.status(404).json({ success: false, error: 'Share not found' });
        }
        const { name, email, accessLevel, password, expiresAt, isActive } = req.body;
        const updates = {};
        if (name !== undefined)
            updates.name = name;
        if (email !== undefined)
            updates.email = email;
        if (accessLevel !== undefined)
            updates.access_level = accessLevel;
        if (password !== undefined) {
            // Hash new password if provided
            updates.password = password ? await hashPassword(password) : undefined;
        }
        if (expiresAt !== undefined)
            updates.expires_at = expiresAt || undefined;
        if (isActive !== undefined)
            updates.is_active = isActive ? 1 : 0;
        await dbUpdateShare(shareToken, updates);
        const updatedShare = await dbGetShareByToken(shareToken);
        res.json({
            success: true,
            share: {
                id: updatedShare?.share_token,
                stationId: updatedShare?.station_id,
                shareToken: updatedShare?.share_token,
                name: updatedShare?.name,
                email: updatedShare?.email,
                accessLevel: updatedShare?.access_level,
                expiresAt: updatedShare?.expires_at,
                isActive: updatedShare?.is_active === 1,
            }
        });
    }
    catch (error) {
        console.error('Error updating share:', error);
        res.status(500).json({ success: false, error: 'Failed to update share' });
    }
});
// Delete a share (requires authentication)
router.delete('/shares/:shareToken', localAuth_1.isAuthenticated, async (req, res) => {
    try {
        const { shareToken } = req.params;
        const share = await dbGetShareByToken(shareToken);
        if (!share) {
            return res.status(404).json({ success: false, error: 'Share not found' });
        }
        await dbDeleteShare(shareToken);
        res.json({ success: true, message: 'Share deleted successfully' });
    }
    catch (error) {
        console.error('Error deleting share:', error);
        res.status(500).json({ success: false, error: 'Failed to delete share' });
    }
});
// Public Share Data Routes (no authentication required, share token acts as access key)
// These routes allow anyone with a valid share link to view station data
// Use the shared storage singleton imported from localStorage
// Helper: validate share token and return station_id if valid
// For password-protected shares, requires a valid session token in X-Share-Session header
async function validateShareAccess(shareToken, req) {
    const share = await dbGetShareByToken(shareToken);
    if (!share)
        return null;
    if (share.is_active !== 1)
        return null;
    if (share.expires_at && new Date() > new Date(share.expires_at))
        return null;
    // For password-protected shares, verify session token
    if (share.password) {
        const sessionToken = req.headers['x-share-session'];
        if (!sessionToken)
            return null;
        const sessionKey = `${shareToken}:${sessionToken}`;
        const expiry = validatedSessions.get(sessionKey);
        if (!expiry || Date.now() > expiry) {
            validatedSessions.delete(sessionKey);
            return null;
        }
    }
    return { stationId: share.station_id, name: share.name || 'Shared Dashboard' };
}
// Get station info via share token (public)
router.get('/shares/:shareToken/station', async (req, res) => {
    try {
        const access = await validateShareAccess(req.params.shareToken, req);
        if (!access) {
            return res.status(404).json({ success: false, error: 'Share not found or expired' });
        }
        const stations = await localStorage_1.storage.getStations();
        const station = stations.find((s) => s.id === access.stationId);
        if (!station) {
            return res.status(404).json({ success: false, error: 'Station not found' });
        }
        // Return only public-safe station info (no connection config/secrets)
        res.json({
            station: {
                id: station.id,
                name: station.name,
                location: station.location,
                latitude: station.latitude,
                longitude: station.longitude,
                altitude: station.altitude,
                stationImage: station.stationImage,
                isActive: station.isActive,
                windSpeedUnit: station.windSpeedUnit || 'ms',
            }
        });
    }
    catch (error) {
        console.error('Error getting shared station:', error);
        res.status(500).json({ success: false, error: 'Failed to get station info' });
    }
});
// Get latest weather data via share token (public)
router.get('/shares/:shareToken/data/latest', async (req, res) => {
    try {
        const access = await validateShareAccess(req.params.shareToken, req);
        if (!access) {
            return res.status(404).json({ success: false, error: 'Share not found or expired' });
        }
        const data = await localStorage_1.storage.getLatestWeatherData(access.stationId);
        if (!data) {
            return res.status(404).json({ message: 'No weather data found' });
        }
        res.json(data);
    }
    catch (error) {
        console.error('Error getting shared latest data:', error);
        res.status(500).json({ message: 'Failed to fetch weather data' });
    }
});
// Get weather data range via share token (public)
router.get('/shares/:shareToken/data', async (req, res) => {
    try {
        const access = await validateShareAccess(req.params.shareToken, req);
        if (!access) {
            return res.status(404).json({ success: false, error: 'Share not found or expired' });
        }
        const { startTime, endTime, limit } = req.query;
        if (!startTime || !endTime) {
            return res.status(400).json({ message: 'startTime and endTime are required' });
        }
        let data = await localStorage_1.storage.getWeatherDataRange(access.stationId, new Date(startTime), new Date(endTime));
        const rawCount = data.length;
        // Server-side downsampling
        const maxPoints = limit ? parseInt(limit) : 500;
        if (data.length > maxPoints) {
            const step = data.length / maxPoints;
            const sampled = [];
            for (let i = 0; i < data.length; i += step) {
                sampled.push(data[Math.floor(i)]);
            }
            if (sampled[sampled.length - 1] !== data[data.length - 1]) {
                sampled.push(data[data.length - 1]);
            }
            data = sampled;
        }
        const firstTs = data.length > 0 ? data[0].timestamp : null;
        const lastTs = data.length > 0 ? data[data.length - 1].timestamp : null;
        console.log(`[shared-data] station=${access.stationId} raw=${rawCount} sent=${data.length} maxPts=${maxPoints} range=${firstTs}..${lastTs}`);
        res.json(data);
    }
    catch (error) {
        console.error('Error getting shared data range:', error);
        res.status(500).json({ message: 'Failed to fetch weather data' });
    }
});
// Get data time range via share token (public)
router.get('/shares/:shareToken/data/range', async (req, res) => {
    try {
        const access = await validateShareAccess(req.params.shareToken, req);
        if (!access) {
            return res.status(404).json({ success: false, error: 'Share not found or expired' });
        }
        const result = await postgres.query('SELECT MIN(timestamp) as earliest, MAX(timestamp) as latest, COUNT(*) as count FROM weather_data WHERE station_id = $1', [access.stationId]);
        const row = result.rows[0];
        res.json({
            earliest: row.earliest,
            latest: row.latest,
            count: parseInt(row.count),
        });
    }
    catch (error) {
        console.error('Error getting shared data range:', error);
        res.status(500).json({ message: 'Failed to fetch data range' });
    }
});
// Rainfall yearly totals via share token (public)
router.get('/shares/:shareToken/data/rainfall-yearly', async (req, res) => {
    try {
        const access = await validateShareAccess(req.params.shareToken, req);
        if (!access) {
            return res.status(404).json({ success: false, error: 'Share not found or expired' });
        }
        // Apply per-station rainfall offset (matches client-side mapToWeatherData)
        const { STATION_RAINFALL_OFFSETS } = await Promise.resolve().then(() => __importStar(require('../config/stationRainfallOffsets')));
        const rainfallOffset = STATION_RAINFALL_OFFSETS[access.stationId] || 0;
        const rainfallFields = [
            "data->>'Rain_mm_Tot'", "data->>'Rain_Tot'", "data->>'Precip_Tot'",
            "data->>'Rain_1_Tot'", "data->>'Rain_Tot_1'",
            "data->>'rainfall'", "data->>'Rain_mm'", "data->>'Precip'",
            "data->>'Rain'", "data->>'Rainfall'"
        ];
        const coalesce = rainfallFields.join(', ');
        const rainfallExpr = rainfallOffset > 0
            ? `GREATEST(0, COALESCE(${coalesce})::numeric - ${rainfallOffset})`
            : `COALESCE(${coalesce})::numeric`;
        const result = await postgres.query(`
      WITH rainfall_readings AS (
        SELECT
          EXTRACT(YEAR FROM timestamp) AS year,
          timestamp,
          ${rainfallExpr} AS rainfall_val,
          LAG(${rainfallExpr}) OVER (
            PARTITION BY EXTRACT(YEAR FROM timestamp)
            ORDER BY timestamp
          ) AS prev_val
        FROM weather_data
        WHERE station_id = $1
          AND COALESCE(${coalesce}) IS NOT NULL
      )
      SELECT
        year,
        COUNT(*) AS readings,
        MAX(rainfall_val) AS max_val,
        MIN(rainfall_val) AS min_val,
        SUM(CASE WHEN rainfall_val > 0 AND rainfall_val < 100 THEN rainfall_val ELSE 0 END) AS sum_total,
        SUM(CASE
          WHEN prev_val IS NOT NULL AND rainfall_val >= prev_val
            AND (rainfall_val - prev_val) < 100
          THEN rainfall_val - prev_val
          ELSE 0
        END) AS delta_sum,
        COUNT(CASE WHEN rainfall_val = 0 THEN 1 END) AS zero_count,
        COUNT(CASE WHEN rainfall_val > 0 AND rainfall_val < 100 THEN 1 END) AS positive_count,
        AVG(CASE WHEN rainfall_val > 0 AND rainfall_val < 100 THEN rainfall_val END) AS mean_positive,
        COUNT(CASE WHEN prev_val IS NOT NULL AND rainfall_val > prev_val + 0.01 THEN 1 END) AS increase_count,
        COUNT(CASE WHEN prev_val IS NOT NULL AND rainfall_val < prev_val - 0.5 THEN 1 END) AS reset_count
      FROM rainfall_readings
      GROUP BY year
      HAVING COUNT(*) >= 2
      ORDER BY year DESC
      LIMIT 6
    `, [access.stationId]);
        const currentYear = new Date().getFullYear();
        const yearlyTotals = result.rows.map((row) => {
            const year = parseInt(row.year);
            const readings = parseInt(row.readings);
            const sumTotal = parseFloat(row.sum_total) || 0;
            const deltaSum = parseFloat(row.delta_sum) || 0;
            const resetCount = parseInt(row.reset_count) || 0;
            const maxVal = parseFloat(row.max_val) || 0;
            const zeroCount = parseInt(row.zero_count) || 0;
            const positiveCount = parseInt(row.positive_count) || 0;
            const increaseCount = parseInt(row.increase_count) || 0;
            const meanPositive = parseFloat(row.mean_positive) || 0;
            const zeroFraction = readings > 0 ? zeroCount / readings : 0;
            const increaseFraction = readings > 0 ? increaseCount / readings : 0;
            let total;
            let mode;
            if (zeroFraction >= 0.30 && meanPositive < 20 && maxVal < 100) {
                mode = 'incremental';
                total = sumTotal;
            }
            else if (increaseFraction >= 0.40 || maxVal >= 50 || resetCount > 0) {
                mode = 'cumulative';
                total = deltaSum;
            }
            else if (positiveCount === 0) {
                mode = 'incremental';
                total = 0;
            }
            else {
                mode = sumTotal <= deltaSum ? 'incremental' : 'cumulative';
                total = Math.min(sumTotal, deltaSum);
            }
            if (total > 5000)
                total = Math.min(deltaSum, sumTotal);
            if (total > 5000)
                total = 0;
            return {
                year,
                total: Math.round(Math.max(0, total) * 10) / 10,
                readings,
                mode,
                isCurrent: year === currentYear,
            };
        });
        res.json(yearlyTotals);
    }
    catch (error) {
        console.error('Error fetching shared rainfall yearly totals:', error);
        res.status(500).json({ message: 'Failed to fetch rainfall data' });
    }
});
// Dashboard config via share token (public, read-only)
router.get('/shares/:shareToken/dashboard-config', async (req, res) => {
    try {
        const access = await validateShareAccess(req.params.shareToken, req);
        if (!access) {
            return res.status(404).json({ success: false, error: 'Share not found or expired' });
        }
        const result = await postgres.query('SELECT dashboard_config FROM stations WHERE id = $1', [access.stationId]);
        if (result.rows.length === 0)
            return res.status(404).json({ message: 'Station not found' });
        res.json(result.rows[0].dashboard_config || null);
    }
    catch (error) {
        console.error('Error fetching shared dashboard config:', error);
        res.status(500).json({ message: 'Failed to fetch dashboard config' });
    }
});
exports.default = router;
