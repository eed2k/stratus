import type { Express } from "express";
import { type Server } from "http";
import { type WeatherData } from "./localStorage";
export declare function broadcastWeatherData(stationId: number, data: WeatherData): void;
export declare function registerRoutes(httpServer: Server, app: Express): Promise<Server>;
