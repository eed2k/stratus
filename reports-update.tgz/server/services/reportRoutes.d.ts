/**
 * Routes for the password-protected /reports portal.
 *
 * Auth model: a single shared password (env REPORTS_PASSWORD). On successful
 * POST /api/reports/auth we set an HTTP-only cookie `stratus_reports` whose
 * value is an HMAC of the password+expiry. requireReportsAuth verifies this
 * cookie. No interaction with the main user/admin auth.
 */
import { type Request, type Response, type NextFunction } from 'express';
declare const router: import("express-serve-static-core").Router;
export declare function requireReportsAuth(req: Request, res: Response, next: NextFunction): void;
export default router;
