"use strict";
// Stratus Weather Server
// Created by Lukas Esterhuizen
Object.defineProperty(exports, "__esModule", { value: true });
exports.dropboxSyncService = exports.DropboxSyncService = void 0;
exports.setWeatherDataBroadcaster = setWeatherDataBroadcaster;
/**
 * Dropbox Sync Service
 * Automatically syncs weather data files from Dropbox App Folder
 * and imports them into Stratus
 *
 * Supports OAuth 2.0 refresh tokens for 24/7 operation
 * Supports multiple folder configurations from database
 */
const events_1 = require("events");
const localStorage_1 = require("../localStorage");
const campbellScientific_1 = require("../parsers/campbellScientific");
// Callback for broadcasting weather data updates via WebSocket
// Set by routes.ts to avoid circular dependency
let weatherDataBroadcaster = null;
/** Default coordinates for known stations (used during auto-creation or coordinate backfill). */
const KNOWN_STATION_DEFAULTS = {
    'hopefield': { latitude: -33.0630, longitude: 18.3528, altitude: 95, location: 'Hopefield, Western Cape, South Africa' },
};
function setWeatherDataBroadcaster(fn) {
    weatherDataBroadcaster = fn;
}
/**
 * Get timezone offset for station (default SAST = UTC+2)
 */
function getStationTimezoneOffset(lat, lon) {
    if (lat === undefined || lon === undefined)
        return 2; // Default SAST
    // South Africa: SAST (UTC+2)
    if (lat >= -35 && lat <= -22 && lon >= 16 && lon <= 33)
        return 2;
    // East Africa: EAT (UTC+3)
    if (lat >= -12 && lat <= 5 && lon >= 29 && lon <= 42)
        return 3;
    // West Africa: WAT (UTC+1)
    if (lat >= -5 && lat <= 13 && lon >= -5 && lon <= 15)
        return 1;
    // Central Africa: CAT (UTC+2)
    if (lat >= -22 && lat <= -8 && lon >= 12 && lon <= 36)
        return 2;
    return 2; // Default SAST
}
/**
 * Format timestamp in station's local timezone
 */
function formatLocalTime(date, timezoneOffset) {
    const localTime = new Date(date.getTime() + timezoneOffset * 3600000);
    return localTime.toISOString().replace('T', ' ').substring(0, 19);
}
class DropboxSyncService extends events_1.EventEmitter {
    constructor() {
        super();
        this.config = null;
        this.dbConfigs = [];
        this.syncedFiles = new Map();
        this.syncTimer = null;
        this.isSyncing = false;
        this.isFullImport = false;
        this.lastSyncTime = null;
        this.lastError = null;
        this.isRefreshingToken = false;
        this.pendingBackfills = new Map();
        this.isBackfilling = false;
    }
    /**
     * Refresh the access token using the refresh token
     * Dropbox short-lived tokens expire after 4 hours
     */
    async refreshAccessToken() {
        if (!this.config?.refreshToken || !this.config?.appKey || !this.config?.appSecret) {
            console.log('[DropboxSync] No refresh token configured, cannot refresh access token');
            return false;
        }
        if (this.isRefreshingToken) {
            console.log('[DropboxSync] Token refresh already in progress');
            return false;
        }
        try {
            this.isRefreshingToken = true;
            console.log('[DropboxSync] Refreshing access token...');
            const credentials = Buffer.from(`${this.config.appKey}:${this.config.appSecret}`).toString('base64');
            const response = await fetch('https://api.dropboxapi.com/oauth2/token', {
                method: 'POST',
                headers: {
                    'Authorization': `Basic ${credentials}`,
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    grant_type: 'refresh_token',
                    refresh_token: this.config.refreshToken,
                }).toString(),
            });
            if (!response.ok) {
                const errorText = await response.text();
                console.error('[DropboxSync] Token refresh failed:', response.status, errorText);
                this.lastError = `Token refresh failed: ${response.status} - ${errorText}`;
                return false;
            }
            const data = await response.json();
            // Update the access token and expiration time
            this.config.accessToken = data.access_token;
            // Set expiration 5 minutes early to ensure we refresh before actual expiration
            this.config.tokenExpiresAt = new Date(Date.now() + (data.expires_in - 300) * 1000);
            console.log(`[DropboxSync] Access token refreshed successfully. Expires at: ${this.config.tokenExpiresAt.toISOString()}`);
            this.lastError = null;
            return true;
        }
        catch (error) {
            const errMsg = error instanceof Error ? error.message : 'Unknown error';
            console.error('[DropboxSync] Token refresh error:', errMsg);
            this.lastError = `Token refresh error: ${errMsg}`;
            return false;
        }
        finally {
            this.isRefreshingToken = false;
        }
    }
    /**
     * Ensure we have a valid access token, refreshing if necessary
     */
    async ensureValidToken() {
        if (!this.config)
            return false;
        // If we have refresh token support and token is expired or expiring soon
        if (this.config.refreshToken && this.config.appKey && this.config.appSecret) {
            const now = new Date();
            const tokenExpired = this.config.tokenExpiresAt && now >= this.config.tokenExpiresAt;
            const noExpiration = !this.config.tokenExpiresAt; // First time, set expiration
            if (tokenExpired || noExpiration) {
                console.log('[DropboxSync] Token expired or expiration unknown, refreshing...');
                return await this.refreshAccessToken();
            }
        }
        return true;
    }
    /**
     * Check if Dropbox credentials are configured
     */
    hasCredentials() {
        return !!(this.config?.accessToken || this.config?.refreshToken);
    }
    /**
     * Reinitialize the service with updated configs from database
     */
    async reinitialize() {
        try {
            this.dbConfigs = await localStorage_1.storage.getDropboxConfigs();
            console.log(`[DropboxSync] Reinitialized with ${this.dbConfigs.length} configurations from database`);
        }
        catch (err) {
            console.error('[DropboxSync] Failed to load configs from database:', err);
        }
    }
    /**
     * Get all database configurations
     */
    getDbConfigs() {
        return this.dbConfigs;
    }
    /**
     * List all .dat files in Dropbox (for UI file browser)
     */
    async listAllFiles() {
        if (!this.config) {
            throw new Error('Dropbox not configured');
        }
        await this.ensureValidToken();
        // List all files recursively from root
        const response = await fetch('https://api.dropboxapi.com/2/files/list_folder', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${this.config.accessToken}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                path: '',
                recursive: true,
                include_media_info: false,
                include_deleted: false,
            }),
        });
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Dropbox API error: ${response.status} - ${errorText}`);
        }
        const data = await response.json();
        let allEntries = data.entries;
        // Handle pagination with retry logic (Dropbox returns ~500 entries per page)
        let cursor = data.cursor;
        let hasMore = data.has_more;
        let page = 1;
        while (hasMore) {
            let continueResponse = null;
            for (let attempt = 0; attempt < 3; attempt++) {
                if (attempt > 0)
                    await new Promise(r => setTimeout(r, 1000 * attempt));
                continueResponse = await fetch('https://api.dropboxapi.com/2/files/list_folder/continue', {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${this.config.accessToken}`,
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ cursor }),
                });
                if (continueResponse.ok)
                    break;
                console.warn(`[DropboxSync] Pagination page ${page + 1} failed (attempt ${attempt + 1}/3): ${continueResponse.status}`);
            }
            if (!continueResponse || !continueResponse.ok) {
                console.error(`[DropboxSync] Pagination failed after 3 retries at page ${page + 1}, got ${allEntries.length} entries so far`);
                break;
            }
            const continueData = await continueResponse.json();
            allEntries = allEntries.concat(continueData.entries);
            cursor = continueData.cursor;
            hasMore = continueData.has_more;
            page++;
        }
        console.log(`[DropboxSync] listAllFiles: fetched ${page} pages, ${allEntries.length} total entries`);
        // Filter to .dat files only
        return allEntries
            .filter(entry => entry['.tag'] === 'file' && entry.name.toLowerCase().endsWith('.dat'))
            .map(entry => ({
            name: entry.name,
            path: entry.path_display,
            modified: entry.server_modified || '',
            size: entry.size || 0,
        }));
    }
    /**
     * Configure the Dropbox sync service
     */
    configure(config) {
        this.config = config;
        console.log(`[DropboxSync] Configured for station ${config.stationId}, folder: ${config.folderPath || '/'}`);
        if (config.enabled) {
            this.startSync();
        }
    }
    /**
     * Get current configuration
     */
    getConfig() {
        return this.config;
    }
    /**
     * Get sync status
     */
    getStatus() {
        return {
            configured: this.config !== null,
            enabled: this.config?.enabled ?? false,
            isSyncing: this.isSyncing,
            lastSyncTime: this.lastSyncTime,
            lastError: this.lastError,
            syncedFileCount: this.syncedFiles.size,
            dbConfigCount: this.dbConfigs.length,
        };
    }
    /**
     * Start automatic syncing
     */
    startSync() {
        if (!this.config) {
            console.warn('[DropboxSync] Cannot start sync - not configured');
            return;
        }
        if (this.syncTimer) {
            clearInterval(this.syncTimer);
        }
        console.log(`[DropboxSync] Starting sync every ${this.config.syncInterval / 1000}s`);
        // Initial sync
        this.syncNow();
        // Schedule periodic sync
        this.syncTimer = setInterval(() => {
            this.syncNow();
        }, this.config.syncInterval);
    }
    /**
     * Stop automatic syncing
     */
    stopSync() {
        if (this.syncTimer) {
            clearInterval(this.syncTimer);
            this.syncTimer = null;
            console.log('[DropboxSync] Sync stopped');
        }
    }
    /**
     * Perform a sync now
     * fullImport: - If true, import all records regardless of timestamp (useful for initial setup)
     */
    async syncNow(fullImport = false) {
        if (this.isSyncing) {
            console.log('[DropboxSync] Sync already in progress, skipping');
            return { success: false, filesProcessed: 0, recordsImported: 0, error: 'Sync already in progress' };
        }
        // If no main config, skip main sync but still process DB configs
        if (!this.config) {
            console.log('[DropboxSync] No main config — skipping main sync, processing DB configs only');
            this.isSyncing = true;
            try {
                const dbResults = await this.syncDbConfigs();
                return { success: true, filesProcessed: dbResults.filesProcessed, recordsImported: dbResults.recordsImported };
            }
            catch (err) {
                console.error('[DropboxSync] DB config sync error:', err.message);
                return { success: false, filesProcessed: 0, recordsImported: 0, error: err.message };
            }
            finally {
                this.isSyncing = false;
                // Process any pending historical backfills in the background
                this.processBackfills().catch(err => console.error('[DropboxSync] Backfill error:', err.message));
            }
        }
        this.isSyncing = true;
        this.isFullImport = fullImport;
        this.lastError = null;
        let filesProcessed = 0;
        let totalRecordsImported = 0;
        try {
            console.log('[DropboxSync] Starting sync...');
            // Extract station name from folder path (e.g., /CAMPBELLSCI/PRIMARY/HOPEFIELD_CR300 -> "Hopefield CR300")
            const pathSegments = this.config.folderPath.replace(/^\//, '').split('/');
            const folderName = pathSegments[pathSegments.length - 1] || pathSegments[0];
            const stationName = folderName.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
            // Find or create station
            const stations = await localStorage_1.storage.getStations();
            let station = null;
            // If stationId is provided and > 0, use it
            if (this.config.stationId > 0) {
                station = stations.find((s) => s.id === this.config.stationId);
            }
            // If no station found by ID, try to find by matching name
            if (!station) {
                station = stations.find((s) => s.name.toLowerCase() === stationName.toLowerCase() ||
                    s.name.toLowerCase().includes(folderName.toLowerCase().replace(/_/g, ' ').split(' ')[0]));
                if (station) {
                    console.log(`[DropboxSync] Found existing station by name: ${station.name} (ID: ${station.id})`);
                    this.config.stationId = station.id;
                }
            }
            // Create station if none found — BUT only if stationId was 0 (auto-detect mode)
            // If stationId was explicitly set and not found, that's an error — don't auto-create
            if (!station) {
                if (this.config.stationId > 0) {
                    console.error(`[DropboxSync] Configured station ID ${this.config.stationId} not found — aborting sync. Do NOT auto-create.`);
                    return { success: false, filesProcessed: 0, recordsImported: 0, error: `Station ID ${this.config.stationId} not found` };
                }
                console.log(`[DropboxSync] Creating new station: ${stationName}`);
                try {
                    // Default coordinates for known stations
                    const stationKey = stationName.toLowerCase().split(' ')[0];
                    const defaults = KNOWN_STATION_DEFAULTS[stationKey] || {};
                    station = await localStorage_1.storage.createStation({
                        name: stationName,
                        pakbusAddress: 1,
                        connectionType: 'http',
                        connectionConfig: {
                            type: 'import-only',
                            importSource: 'dropbox',
                            folderPath: this.config.folderPath
                        },
                        isActive: true,
                        latitude: defaults.latitude,
                        longitude: defaults.longitude,
                        altitude: defaults.altitude,
                        location: defaults.location,
                    });
                    console.log(`[DropboxSync] Created station: ${station.name} (ID: ${station.id})`);
                    this.config.stationId = station.id;
                }
                catch (createErr) {
                    console.error('[DropboxSync] Failed to create station:', createErr);
                    return { success: false, filesProcessed: 0, recordsImported: 0, error: 'Failed to create station' };
                }
            }
            // Update existing station with default coordinates if not set
            if (station && (!station.latitude || !station.longitude)) {
                const stationKey = station.name.toLowerCase().split(' ')[0];
                const defaults = KNOWN_STATION_DEFAULTS[stationKey];
                if (defaults) {
                    try {
                        await localStorage_1.storage.updateStation(station.id, {
                            latitude: defaults.latitude,
                            longitude: defaults.longitude,
                            altitude: defaults.altitude,
                            location: defaults.location,
                        });
                        console.log(`[DropboxSync] Updated station ${station.name} with default coordinates`);
                    }
                    catch (updateErr) {
                        console.warn('[DropboxSync] Could not update station coordinates:', updateErr);
                    }
                }
            }
            // List files in Dropbox folder (recursive to catch subfolders)
            let files;
            try {
                files = await this.listFiles(this.config.folderPath, false, true);
            }
            catch (listErr) {
                // If folder path not found (409), fall through to DB configs
                if (listErr.message?.includes('409') || listErr.message?.includes('not_found')) {
                    console.log(`[DropboxSync] Main sync folder not found (${this.config.folderPath}) — skipping to DB configs`);
                    const dbResults = await this.syncDbConfigs();
                    return { success: true, filesProcessed: dbResults.filesProcessed, recordsImported: dbResults.recordsImported };
                }
                throw listErr;
            }
            console.log(`[DropboxSync] Found ${files.length} files in Dropbox`);
            // Use the same folder name extracted earlier for matching
            const stationPrefix = folderName.split('_')[0].toLowerCase();
            console.log(`[DropboxSync] Looking for files matching station: ${stationPrefix}`);
            // Filter for .dat files only - prioritize files matching station name
            // Skip "conflicted copy" files and old backups
            const datFiles = files.filter(f => {
                if (f['.tag'] !== 'file')
                    return false;
                if (!f.name.toLowerCase().endsWith('.dat'))
                    return false;
                if (f.name.toLowerCase().includes('conflicted copy'))
                    return false;
                if (f.name.toLowerCase().includes('backup'))
                    return false;
                if (f.name.toLowerCase().includes('old'))
                    return false;
                if (f.name.toLowerCase().includes(' - copy'))
                    return false; // Skip manual copies
                if (f.name.toLowerCase().includes('_copy'))
                    return false;
                // Only include files that start with the station prefix
                if (!f.name.toLowerCase().startsWith(stationPrefix)) {
                    // Don't log skip messages for files belonging to other stations (reduces log noise)
                    return false;
                }
                return true;
            });
            // Sort by modification time descending (newest first)
            datFiles.sort((a, b) => {
                const aTime = a.server_modified ? new Date(a.server_modified).getTime() : 0;
                const bTime = b.server_modified ? new Date(b.server_modified).getTime() : 0;
                return bTime - aTime;
            });
            // Process all matching .dat files — rev check skips unchanged files efficiently
            const filesToProcess = datFiles;
            console.log(`[DropboxSync] Processing ${filesToProcess.length} matching .dat files`);
            for (const file of filesToProcess) {
                try {
                    // Check if file has been updated since last sync
                    const existingSynced = this.syncedFiles.get(file.path_lower);
                    if (existingSynced && existingSynced.rev === file.rev) {
                        console.log(`[DropboxSync] Skipping ${file.name} - no changes`);
                        continue;
                    }
                    console.log(`[DropboxSync] Downloading ${file.name}...`);
                    const content = await this.downloadFile(file.path_display);
                    // Parse the file
                    const parsed = (0, campbellScientific_1.parseDataFile)(content);
                    if (parsed.errors.length > 0) {
                        console.warn(`[DropboxSync] Parse warnings for ${file.name}:`, parsed.errors);
                    }
                    if (parsed.records.length === 0) {
                        console.log(`[DropboxSync] No records in ${file.name}`);
                        continue;
                    }
                    console.log(`[DropboxSync] Parsed ${parsed.records.length} total records from ${file.name}`);
                    // Auto-detect wind speed unit from DAT file headers and update station if needed
                    const detectedUnit = (0, campbellScientific_1.detectWindSpeedUnit)(parsed.headers, parsed.units);
                    try {
                        await localStorage_1.storage.updateStation(this.config.stationId, { windSpeedUnit: detectedUnit });
                    }
                    catch (e) {
                        console.warn(`[DropboxSync] Could not update wind_speed_unit:`, e.message);
                    }
                    // Filter records based on import mode
                    let recordsToImport;
                    if (this.isFullImport) {
                        // Full import: import all records (useful for initial setup)
                        recordsToImport = parsed.records;
                        console.log(`[DropboxSync] Full import: importing all ${recordsToImport.length} records`);
                    }
                    else {
                        // Normal sync: only import records since the most-recent record
                        // already in the DB for this station, falling back to a 48-hour
                        // window if there is no existing data. Using the DB high-water-mark
                        // ensures gaps are filled when a station resumes after being offline
                        // for longer than the 48-hour window — the previous fixed 48-hour
                        // cutoff dropped any records older than that on every sync, leaving
                        // permanent holes in the data.
                        const cutoffTime = new Date(Date.now() - 48 * 60 * 60 * 1000);
                        let latestExisting = null;
                        try {
                            const latestData = await localStorage_1.storage.getLatestWeatherData(this.config.stationId);
                            if (latestData?.timestamp) {
                                latestExisting = new Date(latestData.timestamp);
                            }
                        }
                        catch { }
                        // Use the OLDER of (48h-ago, latestExisting) so that:
                        //  - healthy stations: latestExisting is recent, only new records pulled
                        //  - long-offline stations resuming: any records newer than the
                        //    last record in the DB are pulled, even if they pre-date the
                        //    48-hour window, so the gap gets filled automatically.
                        const effectiveCutoff = latestExisting && latestExisting < cutoffTime
                            ? latestExisting
                            : cutoffTime;
                        recordsToImport = parsed.records.filter((r) => r.timestamp > effectiveCutoff);
                        const cutoffSrc = effectiveCutoff === cutoffTime ? '48h window' : `last record ${latestExisting.toISOString()}`;
                        console.log(`[DropboxSync] Importing ${recordsToImport.length} records since ${cutoffSrc}`);
                    }
                    // Import records to database in efficient batches
                    let recordsImported = 0;
                    const batchSize = 1000;
                    for (let i = 0; i < recordsToImport.length; i += batchSize) {
                        const batch = recordsToImport.slice(i, i + batchSize);
                        // Prepare batch data
                        const batchData = batch.map((record) => {
                            const mappedData = (0, campbellScientific_1.mapToWeatherData)(record, parsed.units, parsed.headers);
                            const combinedData = { ...record.data, ...mappedData };
                            return {
                                stationId: this.config.stationId,
                                tableName: parsed.tableName || 'Table1',
                                recordNumber: record.recordNumber,
                                timestamp: record.timestamp,
                                data: combinedData,
                            };
                        });
                        try {
                            // Use batch insert for efficiency
                            const inserted = await localStorage_1.storage.insertWeatherDataBatch(batchData);
                            recordsImported += inserted;
                        }
                        catch (err) {
                            console.warn(`[DropboxSync] Batch insert error, falling back to individual inserts:`, err.message);
                            // Fallback to individual inserts
                            for (const data of batchData) {
                                try {
                                    await localStorage_1.storage.createWeatherData(data);
                                    recordsImported++;
                                }
                                catch (individualErr) {
                                    if (!individualErr.message?.includes('UNIQUE constraint')) {
                                        console.warn(`[DropboxSync] Error importing record:`, individualErr.message);
                                    }
                                }
                            }
                        }
                        // Progress update every 5000 records
                        if (i > 0 && i % 5000 === 0) {
                            console.log(`[DropboxSync] Progress: ${i}/${recordsToImport.length} records processed`);
                        }
                    }
                    console.log(`[DropboxSync] Imported ${recordsImported} new records from ${file.name}`);
                    totalRecordsImported += recordsImported;
                    // Mark file as synced
                    this.syncedFiles.set(file.path_lower, {
                        name: file.name,
                        path: file.path_display,
                        rev: file.rev,
                        modifiedAt: new Date(file.server_modified),
                        lastSynced: new Date(),
                    });
                    filesProcessed++;
                }
                catch (err) {
                    console.error(`[DropboxSync] Error processing ${file.name}:`, err.message);
                }
            }
            this.lastSyncTime = new Date();
            this.emit('syncComplete', { filesProcessed, recordsImported: totalRecordsImported });
            // Persist last sync time to station record in DB so the client can display it
            try {
                await localStorage_1.storage.updateStation(this.config.stationId, {
                    lastConnected: this.lastSyncTime,
                    isActive: true,
                });
                console.log(`[DropboxSync] Updated station ${this.config.stationId} last_connected to ${this.lastSyncTime.toISOString()}, marked active`);
            }
            catch (persistErr) {
                console.warn('[DropboxSync] Could not persist last_connected:', persistErr.message);
            }
            // Broadcast latest data via WebSocket so dashboards update immediately
            if (totalRecordsImported > 0 && weatherDataBroadcaster) {
                try {
                    const latestData = await localStorage_1.storage.getLatestWeatherData(this.config.stationId);
                    if (latestData) {
                        weatherDataBroadcaster(this.config.stationId, latestData);
                        console.log(`[DropboxSync] Broadcast latest data for station ${this.config.stationId}`);
                    }
                }
                catch (broadcastErr) {
                    console.warn('[DropboxSync] Could not broadcast data:', broadcastErr.message);
                }
            }
            // Get station info for timezone-aware logging
            const stationInfo = await localStorage_1.storage.getStation(this.config.stationId);
            const timezoneOffset = getStationTimezoneOffset(stationInfo?.latitude, stationInfo?.longitude);
            const localTime = formatLocalTime(this.lastSyncTime, timezoneOffset);
            console.log(`[DropboxSync] Sync complete: ${filesProcessed} files, ${totalRecordsImported} records`);
            console.log(`[DropboxSync] Local time: ${localTime} (UTC+${timezoneOffset})`);
            return { success: true, filesProcessed, recordsImported: totalRecordsImported };
        }
        catch (err) {
            this.lastError = err.message;
            console.error('[DropboxSync] Main sync error:', err.message);
            this.emit('syncError', err);
            return { success: false, filesProcessed, recordsImported: totalRecordsImported, error: err.message };
        }
        finally {
            // Always sync DB configs, even if main sync failed
            try {
                const dbResults = await this.syncDbConfigs(totalRecordsImported);
                filesProcessed += dbResults.filesProcessed;
                totalRecordsImported += dbResults.recordsImported;
            }
            catch (dbErr) {
                console.error('[DropboxSync] DB config sync error in finally:', dbErr.message);
            }
            this.isSyncing = false;
            // Process any pending historical backfills in the background
            this.processBackfills().catch(err => console.error('[DropboxSync] Backfill error:', err.message));
        }
    }
    /**
     * Sync files based on database configurations
     */
    async syncDbConfigs(mainSyncRecords = 0) {
        let filesProcessed = 0;
        let recordsImported = 0;
        try {
            // Reload configs from database
            this.dbConfigs = await localStorage_1.storage.getDropboxConfigs();
            if (this.dbConfigs.length === 0) {
                return { filesProcessed: 0, recordsImported: 0 };
            }
            // Filter out DB configs that duplicate the main env-configured sync
            // Only skip if main sync actually imported records — if 0 records, let DB config handle it
            const mainStationId = this.config?.stationId;
            const filteredConfigs = this.dbConfigs.filter(c => {
                if (mainStationId && c.stationId === mainStationId && mainSyncRecords > 0) {
                    console.log(`[DropboxSync] Skipping DB config "${c.name}" — already synced by main sync (station ${mainStationId}, ${mainSyncRecords} records)`);
                    // Still mark as success since main sync handled it — pass actual record count
                    localStorage_1.storage.updateDropboxSyncStatus(c.id, 'success (handled by main sync)', mainSyncRecords).catch(() => { });
                    return false;
                }
                return true;
            });
            if (filteredConfigs.length === 0) {
                console.log(`[DropboxSync] No additional DB configs to process (${this.dbConfigs.length} skipped as duplicates)`);
                return { filesProcessed: 0, recordsImported: 0 };
            }
            console.log(`[DropboxSync] Processing ${filteredConfigs.length} database configurations...`);
            // Get all files from Dropbox
            const allFiles = await this.listAllFiles();
            for (const dbConfig of filteredConfigs) {
                if (!dbConfig.enabled) {
                    console.log(`[DropboxSync] Skipping disabled config: ${dbConfig.name}`);
                    continue;
                }
                console.log(`[DropboxSync] Processing config: ${dbConfig.name} (folder: ${dbConfig.folderPath})`);
                // Find matching files based on folder path and optional file pattern
                const matchingFiles = allFiles.filter(file => {
                    // Check if file is in the configured folder
                    const inFolder = file.path.toLowerCase().startsWith(dbConfig.folderPath.toLowerCase());
                    // Check file pattern if specified
                    if (dbConfig.filePattern) {
                        let effectivePattern = dbConfig.filePattern.trim();
                        // Auto-append wildcard if pattern looks like a prefix (no wildcards and no file extension)
                        if (!effectivePattern.includes('*') && !effectivePattern.includes('?')) {
                            if (!effectivePattern.includes('.')) {
                                // Looks like a prefix (e.g. "Inteltronics_SAWS_TestBed_5263") — treat as prefix match
                                effectivePattern = effectivePattern + '*';
                                console.log(`[DropboxSync] Pattern "${dbConfig.filePattern}" has no wildcard or extension — auto-expanded to "${effectivePattern}"`);
                            }
                            else {
                                // Has a dot, looks like an exact filename (e.g. "MyFile.dat") — do exact match
                                return inFolder && file.name.toLowerCase() === effectivePattern.toLowerCase();
                            }
                        }
                        // Convert glob to regex: * → .*, ? → .
                        const pattern = effectivePattern
                            .replace(/[.+^${}()|[\]\\]/g, '\\$&') // Escape regex chars except * and ?
                            .replace(/\*/g, '.*')
                            .replace(/\?/g, '.');
                        const regex = new RegExp(`^${pattern}$`, 'i');
                        return inFolder && regex.test(file.name);
                    }
                    return inFolder;
                });
                console.log(`[DropboxSync] Found ${matchingFiles.length} matching files for ${dbConfig.name}`);
                if (matchingFiles.length === 0) {
                    await localStorage_1.storage.updateDropboxSyncStatus(dbConfig.id, 'success (no new files)', 0);
                    continue;
                }
                for (const file of matchingFiles) {
                    try {
                        // Check if file has been modified since last sync
                        const fileKey = `${dbConfig.id}:${file.path}`;
                        const existingSynced = this.syncedFiles.get(fileKey);
                        if (existingSynced && new Date(file.modified) <= existingSynced.modifiedAt) {
                            console.log(`[DropboxSync] Skipping ${file.name} - no changes`);
                            continue;
                        }
                        console.log(`[DropboxSync] Downloading ${file.name}...`);
                        let content = await this.downloadFile(file.path);
                        // Parse the file
                        const parsed = (0, campbellScientific_1.parseDataFile)(content);
                        // Release raw file content from memory immediately
                        content = '';
                        if (!parsed || parsed.records.length === 0) {
                            console.warn(`[DropboxSync] No records found in ${file.name}`);
                            continue;
                        }
                        console.log(`[DropboxSync] Parsed ${parsed.records.length} total records from ${file.name}`);
                        // Extract station name from file or use config name
                        const stationName = dbConfig.name.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
                        // Find or create station
                        const stations = await localStorage_1.storage.getStations();
                        let station = dbConfig.stationId
                            ? stations.find((s) => s.id === dbConfig.stationId)
                            : stations.find((s) => s.name.toLowerCase() === stationName.toLowerCase() ||
                                s.name.toLowerCase().includes(dbConfig.name.toLowerCase().split('_')[0]));
                        if (!station) {
                            // If stationId was explicitly set in config, don't auto-create
                            if (dbConfig.stationId && dbConfig.stationId > 0) {
                                console.error(`[DropboxSync] Config "${dbConfig.name}" station ID ${dbConfig.stationId} not found — skipping. Do NOT auto-create.`);
                                continue;
                            }
                            console.log(`[DropboxSync] Creating new station: ${stationName}`);
                            station = await localStorage_1.storage.createStation({
                                name: stationName,
                                pakbusAddress: 1,
                                connectionType: 'http',
                                connectionConfig: {
                                    type: 'import-only',
                                    importSource: 'dropbox',
                                    folderPath: dbConfig.folderPath
                                },
                                isActive: true,
                            });
                            // Update config with new station ID
                            await localStorage_1.storage.updateDropboxConfig(dbConfig.id, { stationId: station.id });
                        }
                        // Filter records based on import mode
                        // Auto-full-import for configs that have never successfully imported data
                        // Check: no lastSyncAt, OR lastSyncRecords is 0/null (previous syncs found no recent data)
                        const neverImportedData = !dbConfig.lastSyncAt || (!dbConfig.lastSyncRecords || dbConfig.lastSyncRecords === 0);
                        const isFirstImport = neverImportedData && dbConfig.lastSyncStatus !== 'success (handled by main sync)';
                        let recordsToImport;
                        if (this.isFullImport) {
                            // Manual full import: import all records
                            recordsToImport = parsed.records;
                            console.log(`[DropboxSync] Full import: importing all ${recordsToImport.length} records`);
                        }
                        else if (isFirstImport) {
                            // Recent-first strategy: import last 30 days immediately so the dashboard works,
                            // then schedule historical backfill in the background
                            let latestExisting = null;
                            try {
                                const latestData = await localStorage_1.storage.getLatestWeatherData(station.id);
                                if (latestData?.timestamp) {
                                    latestExisting = new Date(latestData.timestamp);
                                }
                            }
                            catch { }
                            const recentCutoff = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
                            if (latestExisting && latestExisting >= recentCutoff) {
                                // Already have recent data — just import newer records
                                recordsToImport = parsed.records.filter((r) => r.timestamp > latestExisting);
                                console.log(`[DropboxSync] Resuming import for "${dbConfig.name}": ${recordsToImport.length} new records (after ${latestExisting.toISOString()})`);
                            }
                            else {
                                // Import recent 30 days first for immediate dashboard readiness
                                const recentRecords = parsed.records.filter((r) => r.timestamp >= recentCutoff);
                                const olderRecords = latestExisting
                                    ? parsed.records.filter((r) => r.timestamp > latestExisting && r.timestamp < recentCutoff)
                                    : parsed.records.filter((r) => r.timestamp < recentCutoff);
                                recordsToImport = recentRecords;
                                console.log(`[DropboxSync] Recent-first import for "${dbConfig.name}": ${recentRecords.length} recent records (last 30d), ${olderRecords.length} older records queued for backfill`);
                                // Queue older records for background backfill
                                if (olderRecords.length > 0) {
                                    this.pendingBackfills.set(station.id, {
                                        records: olderRecords,
                                        parsed: { units: parsed.units, headers: parsed.headers, tableName: parsed.tableName },
                                        station,
                                        dbConfig,
                                    });
                                }
                            }
                        }
                        else {
                            // Normal sync: pull records newer than the last record in DB,
                            // falling back to a 48-hour window if no record exists. This
                            // ensures gaps are filled automatically when a station resumes
                            // after being offline for more than 48 hours — the previous
                            // fixed-48h cutoff used to drop any records older than that on
                            // every sync, leaving permanent holes.
                            const cutoffTime = new Date();
                            cutoffTime.setHours(cutoffTime.getHours() - 48);
                            let latestExisting = null;
                            try {
                                const latestData = await localStorage_1.storage.getLatestWeatherData(station.id);
                                if (latestData?.timestamp)
                                    latestExisting = new Date(latestData.timestamp);
                            }
                            catch { }
                            const effectiveCutoff = latestExisting && latestExisting < cutoffTime
                                ? latestExisting
                                : cutoffTime;
                            recordsToImport = parsed.records.filter((r) => r.timestamp > effectiveCutoff);
                            const cutoffSrc = effectiveCutoff === cutoffTime ? '48h window' : `last record ${latestExisting.toISOString()}`;
                            console.log(`[DropboxSync] Importing ${recordsToImport.length} records since ${cutoffSrc}`);
                        }
                        let configRecordsImported = 0;
                        const BATCH_SIZE = 1000;
                        for (let i = 0; i < recordsToImport.length; i += BATCH_SIZE) {
                            const batch = recordsToImport.slice(i, i + BATCH_SIZE);
                            const batchData = batch.map(record => {
                                const mappedData = (0, campbellScientific_1.mapToWeatherData)(record, parsed.units, parsed.headers);
                                return {
                                    stationId: station.id,
                                    tableName: parsed.tableName || 'Table1',
                                    recordNumber: record.recordNumber,
                                    timestamp: record.timestamp,
                                    data: { ...record.data, ...mappedData },
                                };
                            });
                            try {
                                const inserted = await localStorage_1.storage.insertWeatherDataBatch(batchData);
                                configRecordsImported += inserted;
                            }
                            catch (err) {
                                for (const data of batchData) {
                                    try {
                                        await localStorage_1.storage.createWeatherData(data);
                                        configRecordsImported++;
                                    }
                                    catch (individualErr) {
                                        if (!individualErr.message?.includes('UNIQUE constraint') && !individualErr.message?.includes('duplicate key')) {
                                            console.warn(`[DropboxSync] Error importing record:`, individualErr.message);
                                        }
                                    }
                                }
                            }
                            // Progress logging and status updates for large imports
                            if (recordsToImport.length > 1000 && (i + BATCH_SIZE) % 10000 < BATCH_SIZE) {
                                const processed = Math.min(i + BATCH_SIZE, recordsToImport.length);
                                console.log(`[DropboxSync] Progress: ${processed}/${recordsToImport.length} records processed for ${dbConfig.name}`);
                                // Update sync status periodically so it's visible even if import is interrupted
                                await localStorage_1.storage.updateDropboxSyncStatus(dbConfig.id, `importing (${processed}/${recordsToImport.length})`, configRecordsImported);
                                // Also update last_connected so station preview shows activity
                                if (station && configRecordsImported > 0) {
                                    try {
                                        await localStorage_1.storage.updateStation(station.id, { lastConnected: new Date(), isActive: true });
                                    }
                                    catch { }
                                }
                            }
                        }
                        console.log(`[DropboxSync] Imported ${configRecordsImported} records from ${file.name}`);
                        recordsImported += configRecordsImported;
                        filesProcessed++;
                        // Persist last sync time to station record
                        if (station && configRecordsImported > 0) {
                            try {
                                await localStorage_1.storage.updateStation(station.id, { lastConnected: new Date(), isActive: true });
                            }
                            catch (e) {
                                console.warn(`[DropboxSync] Could not update last_connected for station ${station.id}:`, e.message);
                            }
                            // Broadcast latest data via WebSocket so dashboards update immediately
                            if (weatherDataBroadcaster) {
                                try {
                                    const latestData = await localStorage_1.storage.getLatestWeatherData(station.id);
                                    if (latestData) {
                                        weatherDataBroadcaster(station.id, latestData);
                                    }
                                }
                                catch (broadcastErr) {
                                    console.warn('[DropboxSync] Could not broadcast data:', broadcastErr.message);
                                }
                            }
                        }
                        // Mark file as synced
                        this.syncedFiles.set(fileKey, {
                            name: file.name,
                            path: file.path,
                            rev: '',
                            modifiedAt: new Date(file.modified),
                            lastSynced: new Date(),
                        });
                        // Update sync status in database
                        await localStorage_1.storage.updateDropboxSyncStatus(dbConfig.id, 'success', configRecordsImported);
                    }
                    catch (fileErr) {
                        console.error(`[DropboxSync] Error processing ${file.name}:`, fileErr.message);
                        await localStorage_1.storage.updateDropboxSyncStatus(dbConfig.id, `error: ${fileErr.message}`, 0);
                    }
                }
            }
        }
        catch (err) {
            console.error('[DropboxSync] Error syncing db configs:', err.message);
        }
        return { filesProcessed, recordsImported };
    }
    /**
     * Process pending historical backfills in the background.
     * Called after each sync cycle completes so the dashboard has recent data first.
     */
    async processBackfills() {
        if (this.isBackfilling || this.pendingBackfills.size === 0)
            return;
        this.isBackfilling = true;
        for (const [stationId, backfill] of this.pendingBackfills) {
            const { records, parsed, station, dbConfig } = backfill;
            console.log(`[DropboxSync] Starting background backfill for "${dbConfig.name}": ${records.length} historical records`);
            await localStorage_1.storage.updateDropboxSyncStatus(dbConfig.id, `backfilling (0/${records.length})`, 0);
            let imported = 0;
            const BATCH_SIZE = 1000;
            for (let i = 0; i < records.length; i += BATCH_SIZE) {
                const batch = records.slice(i, i + BATCH_SIZE);
                const batchData = batch.map((record) => {
                    const mappedData = (0, campbellScientific_1.mapToWeatherData)(record, parsed.units, parsed.headers);
                    return {
                        stationId: station.id,
                        tableName: parsed.tableName || 'Table1',
                        recordNumber: record.recordNumber,
                        timestamp: record.timestamp,
                        data: { ...record.data, ...mappedData },
                    };
                });
                try {
                    const inserted = await localStorage_1.storage.insertWeatherDataBatch(batchData);
                    imported += inserted;
                }
                catch {
                    for (const data of batchData) {
                        try {
                            await localStorage_1.storage.createWeatherData(data);
                            imported++;
                        }
                        catch (e) {
                            if (!e.message?.includes('UNIQUE constraint') && !e.message?.includes('duplicate key')) {
                                console.warn(`[DropboxSync] Backfill record error:`, e.message);
                            }
                        }
                    }
                }
                // Progress update every 5000 records
                if ((i + BATCH_SIZE) % 5000 < BATCH_SIZE) {
                    const processed = Math.min(i + BATCH_SIZE, records.length);
                    console.log(`[DropboxSync] Backfill progress for "${dbConfig.name}": ${processed}/${records.length}`);
                    await localStorage_1.storage.updateDropboxSyncStatus(dbConfig.id, `backfilling (${processed}/${records.length})`, imported);
                }
                // Yield to event loop periodically to keep the server responsive
                if (i % 1000 === 0) {
                    await new Promise(resolve => setTimeout(resolve, 10));
                }
            }
            console.log(`[DropboxSync] Backfill complete for "${dbConfig.name}": ${imported} historical records imported`);
            await localStorage_1.storage.updateDropboxSyncStatus(dbConfig.id, 'success', imported);
            this.pendingBackfills.delete(stationId);
        }
        this.isBackfilling = false;
    }
    /**
     * List files in Dropbox folder
     */
    async listFiles(folderPath, retried = false, recursive = false) {
        // Ensure we have a valid token before making API calls
        await this.ensureValidToken();
        const response = await fetch('https://api.dropboxapi.com/2/files/list_folder', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${this.config.accessToken}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                path: folderPath || '', // Empty string = app folder root
                recursive: recursive,
                include_media_info: false,
                include_deleted: false,
                include_has_explicit_shared_members: false,
                include_mounted_folders: true,
            }),
        });
        if (!response.ok) {
            const errorText = await response.text();
            // If we get a 401, try to refresh the token and retry ONCE
            if (response.status === 401 && this.config?.refreshToken && !retried) {
                console.log('[DropboxSync] Got 401, attempting token refresh and retry...');
                const refreshed = await this.refreshAccessToken();
                if (refreshed) {
                    // Retry the request with the new token (only once)
                    return this.listFiles(folderPath, true, recursive);
                }
            }
            throw new Error(`Dropbox API error: ${response.status} - ${errorText}`);
        }
        const data = await response.json();
        let allEntries = data.entries;
        // Handle pagination
        let cursor = data.cursor;
        while (data.has_more) {
            const continueResponse = await fetch('https://api.dropboxapi.com/2/files/list_folder/continue', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.config.accessToken}`,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ cursor }),
            });
            if (!continueResponse.ok) {
                break;
            }
            const continueData = await continueResponse.json();
            allEntries = allEntries.concat(continueData.entries);
            cursor = continueData.cursor;
            if (!continueData.has_more)
                break;
        }
        return allEntries;
    }
    /**
     * Download file content from Dropbox
     */
    async downloadFile(filePath, retryCount = 0) {
        // Ensure we have a valid token before making API calls
        await this.ensureValidToken();
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 5 * 60 * 1000); // 5 minute timeout
        try {
            const response = await fetch('https://content.dropboxapi.com/2/files/download', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.config.accessToken}`,
                    'Dropbox-API-Arg': JSON.stringify({ path: filePath }),
                },
                signal: controller.signal,
            });
            if (!response.ok) {
                const errorText = await response.text();
                // If we get a 401, try to refresh the token and retry ONCE
                if (response.status === 401 && this.config?.refreshToken && retryCount === 0) {
                    console.log('[DropboxSync] Got 401 on download, attempting token refresh and retry...');
                    const refreshed = await this.refreshAccessToken();
                    if (refreshed) {
                        return this.downloadFile(filePath, 1);
                    }
                }
                throw new Error(`Dropbox download error: ${response.status} - ${errorText}`);
            }
            return await response.text();
        }
        catch (err) {
            // Retry once on network/timeout errors
            if (retryCount < 1 && (err.name === 'AbortError' || err.message === 'fetch failed')) {
                console.log(`[DropboxSync] Download failed (${err.message}), retrying in 5s...`);
                await new Promise(resolve => setTimeout(resolve, 5000));
                return this.downloadFile(filePath, retryCount + 1);
            }
            throw err;
        }
        finally {
            clearTimeout(timeout);
        }
    }
    /**
     * Test the Dropbox connection
     */
    async testConnection() {
        if (!this.config) {
            return { success: false, message: 'Not configured' };
        }
        try {
            const files = await this.listFiles(this.config.folderPath);
            const fileNames = files
                .filter(f => f['.tag'] === 'file')
                .map(f => f.name);
            return {
                success: true,
                message: `Connected! Found ${files.length} items in folder`,
                files: fileNames,
            };
        }
        catch (err) {
            return {
                success: false,
                message: err.message,
            };
        }
    }
    /**
     * Preview a specific file from Dropbox — downloads and returns header + last N data lines
     * Used to check if a .dat file has recent records before setting up sync
     */
    async previewFile(filePath, tailLines = 10) {
        if (!this.config) {
            throw new Error('Not configured');
        }
        await this.ensureValidToken();
        // Download the file content
        const response = await fetch('https://content.dropboxapi.com/2/files/download', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${this.config.accessToken}`,
                'Dropbox-API-Arg': JSON.stringify({ path: filePath }),
            },
        });
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Dropbox download error: ${response.status} - ${errorText}`);
        }
        // Get metadata from response header
        const apiResult = response.headers.get('dropbox-api-result');
        let size = 0;
        let modified = '';
        if (apiResult) {
            try {
                const meta = JSON.parse(apiResult);
                size = meta.size || 0;
                modified = meta.server_modified || '';
            }
            catch { }
        }
        const content = await response.text();
        const allLines = content.split('\n').filter(l => l.trim().length > 0);
        const totalLines = allLines.length;
        // TOA5 format: first 4 lines are headers (environment, field names, units, processing)
        const headerLines = allLines.slice(0, 4);
        // Data lines follow after headers
        const dataLines = allLines.slice(4);
        const lastRecords = dataLines.slice(-tailLines);
        // Parse timestamps from first and last data records (field 0 is typically "TIMESTAMP")
        let oldestTimestamp = null;
        let newestTimestamp = null;
        if (dataLines.length > 0) {
            // TOA5 timestamps are in the first field, quoted: "2026-02-14 12:00:00"
            const parseTs = (line) => {
                const match = line.match(/"(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})"/);
                return match ? match[1] : null;
            };
            oldestTimestamp = parseTs(dataLines[0]);
            newestTimestamp = parseTs(dataLines[dataLines.length - 1]);
        }
        return {
            path: filePath,
            size,
            modified,
            headerLines,
            lastRecords,
            totalLines,
            newestTimestamp,
            oldestTimestamp,
        };
    }
    /**
     * List ALL files and folders in Dropbox root (for discovery)
     */
    async listAllDropboxContents() {
        if (!this.config) {
            throw new Error('Not configured');
        }
        await this.ensureValidToken();
        // List recursively from root
        const response = await fetch('https://api.dropboxapi.com/2/files/list_folder', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${this.config.accessToken}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                path: '', // Root of app folder
                recursive: true, // Get everything
                include_media_info: false,
                include_deleted: false,
            }),
        });
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Dropbox API error: ${response.status} - ${errorText}`);
        }
        const data = await response.json();
        let allEntries = data.entries;
        // Handle pagination with retry logic
        let cursor = data.cursor;
        let hasMore = data.has_more;
        let page = 1;
        while (hasMore) {
            let continueResponse = null;
            for (let attempt = 0; attempt < 3; attempt++) {
                if (attempt > 0)
                    await new Promise(r => setTimeout(r, 1000 * attempt));
                continueResponse = await fetch('https://api.dropboxapi.com/2/files/list_folder/continue', {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${this.config.accessToken}`,
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ cursor }),
                });
                if (continueResponse.ok)
                    break;
                console.warn(`[DropboxSync] Discovery pagination page ${page + 1} failed (attempt ${attempt + 1}/3): ${continueResponse.status}`);
            }
            if (!continueResponse || !continueResponse.ok) {
                console.error(`[DropboxSync] Discovery pagination failed after 3 retries at page ${page + 1}, got ${allEntries.length} entries so far`);
                break;
            }
            const continueData = await continueResponse.json();
            allEntries = allEntries.concat(continueData.entries);
            cursor = continueData.cursor;
            hasMore = continueData.has_more;
            page++;
        }
        console.log(`[DropboxSync] listAllDropboxContents: fetched ${page} pages, ${allEntries.length} total entries`);
        // Separate folders and files
        const folders = allEntries
            .filter(e => e['.tag'] === 'folder')
            .map(e => e.path_display);
        const files = allEntries
            .filter(e => e['.tag'] === 'file')
            .map(e => ({
            name: e.name,
            path: e.path_display,
            modified: e.server_modified || '',
            size: e.size || 0,
        }));
        // Log discovery results
        console.log('[DropboxSync] === DROPBOX CONTENTS DISCOVERY ===');
        console.log(`[DropboxSync] Found ${folders.length} folders:`);
        folders.forEach(f => console.log(`[DropboxSync]   📁 ${f}`));
        console.log(`[DropboxSync] Found ${files.length} files:`);
        files.forEach(f => console.log(`[DropboxSync]   📄 ${f.path} (${(f.size / 1024).toFixed(1)} KB, modified: ${f.modified})`));
        console.log('[DropboxSync] === END DISCOVERY ===');
        return { folders, files };
    }
}
exports.DropboxSyncService = DropboxSyncService;
// Singleton instance
exports.dropboxSyncService = new DropboxSyncService();
