/**
 * Initialise the staleness monitor
 */
export declare function initStalenessMonitor(): Promise<void>;
/**
 * Stop the staleness monitor
 */
export declare function stopStalenessMonitor(): void;
/**
 * Manually trigger a staleness check (for testing/API use)
 */
export declare function triggerStalenessCheck(): Promise<{
    stale: any[];
    healthy: any[];
}>;
/**
 * Send a test staleness alert email to verify the system works
 */
export declare function sendTestStalenessAlert(recipientEmail?: string): Promise<boolean>;
