/**
 * Dropbox Sync Service
 * Automatically syncs weather data files from Dropbox App Folder
 * and imports them into Stratus
 *
 * Supports OAuth 2.0 refresh tokens for 24/7 operation
 * Supports multiple folder configurations from database
 */
import { EventEmitter } from 'events';
export declare function setWeatherDataBroadcaster(fn: (stationId: number, data: any) => void): void;
export interface DropboxConfig {
    accessToken: string;
    folderPath: string;
    stationId: number;
    syncInterval: number;
    enabled: boolean;
    refreshToken?: string;
    appKey?: string;
    appSecret?: string;
    tokenExpiresAt?: Date;
}
export interface DbDropboxConfig {
    id: number;
    name: string;
    folderPath: string;
    filePattern?: string;
    stationId?: number;
    syncInterval: number;
    enabled: boolean;
    lastSyncAt?: Date;
    lastSyncStatus?: string;
    lastSyncRecords?: number;
}
export interface SyncedFile {
    name: string;
    path: string;
    rev: string;
    modifiedAt: Date;
    lastSynced: Date;
}
export declare class DropboxSyncService extends EventEmitter {
    private config;
    private dbConfigs;
    private syncedFiles;
    private syncTimer;
    private isSyncing;
    private isFullImport;
    private lastSyncTime;
    private lastError;
    private isRefreshingToken;
    private pendingBackfills;
    private isBackfilling;
    constructor();
    /**
     * Refresh the access token using the refresh token
     * Dropbox short-lived tokens expire after 4 hours
     */
    private refreshAccessToken;
    /**
     * Ensure we have a valid access token, refreshing if necessary
     */
    private ensureValidToken;
    /**
     * Check if Dropbox credentials are configured
     */
    hasCredentials(): boolean;
    /**
     * Reinitialize the service with updated configs from database
     */
    reinitialize(): Promise<void>;
    /**
     * Get all database configurations
     */
    getDbConfigs(): DbDropboxConfig[];
    /**
     * List all .dat files in Dropbox (for UI file browser)
     */
    listAllFiles(): Promise<{
        name: string;
        path: string;
        modified: string;
        size: number;
    }[]>;
    /**
     * Configure the Dropbox sync service
     */
    configure(config: DropboxConfig): void;
    /**
     * Get current configuration
     */
    getConfig(): DropboxConfig | null;
    /**
     * Get sync status
     */
    getStatus(): {
        configured: boolean;
        enabled: boolean;
        isSyncing: boolean;
        lastSyncTime: Date | null;
        lastError: string | null;
        syncedFileCount: number;
        dbConfigCount: number;
    };
    /**
     * Start automatic syncing
     */
    startSync(): void;
    /**
     * Stop automatic syncing
     */
    stopSync(): void;
    /**
     * Perform a sync now
     * fullImport: - If true, import all records regardless of timestamp (useful for initial setup)
     */
    syncNow(fullImport?: boolean): Promise<{
        success: boolean;
        filesProcessed: number;
        recordsImported: number;
        error?: string;
    }>;
    /**
     * Sync files based on database configurations
     */
    private syncDbConfigs;
    /**
     * Process pending historical backfills in the background.
     * Called after each sync cycle completes so the dashboard has recent data first.
     */
    private processBackfills;
    /**
     * List files in Dropbox folder
     */
    private listFiles;
    /**
     * Download file content from Dropbox
     */
    private downloadFile;
    /**
     * Test the Dropbox connection
     */
    testConnection(): Promise<{
        success: boolean;
        message: string;
        files?: string[];
    }>;
    /**
     * Preview a specific file from Dropbox — downloads and returns header + last N data lines
     * Used to check if a .dat file has recent records before setting up sync
     */
    previewFile(filePath: string, tailLines?: number): Promise<{
        path: string;
        size: number;
        modified: string;
        headerLines: string[];
        lastRecords: string[];
        totalLines: number;
        newestTimestamp: string | null;
        oldestTimestamp: string | null;
    }>;
    /**
     * List ALL files and folders in Dropbox root (for discovery)
     */
    listAllDropboxContents(): Promise<{
        folders: string[];
        files: {
            name: string;
            path: string;
            modified: string;
            size: number;
        }[];
    }>;
}
export declare const dropboxSyncService: DropboxSyncService;
