declare const router: import("express-serve-static-core").Router;
export declare function invalidateDropboxFilesCache(): void;
export default router;
