/** Catalog of selectable fields. label is what the user sees; key is stored. */
export declare const REPORT_FIELDS: readonly [{
    readonly key: "temp_min";
    readonly label: "Temperature (minimum)";
    readonly unit: "degC";
}, {
    readonly key: "temp_avg";
    readonly label: "Temperature (average)";
    readonly unit: "degC";
}, {
    readonly key: "temp_max";
    readonly label: "Temperature (maximum)";
    readonly unit: "degC";
}, {
    readonly key: "humidity_avg";
    readonly label: "Humidity (average)";
    readonly unit: "%";
}, {
    readonly key: "pressure_avg";
    readonly label: "Pressure (average)";
    readonly unit: "mbar";
}, {
    readonly key: "wind_avg";
    readonly label: "Wind speed (average)";
    readonly unit: "m/s";
}, {
    readonly key: "wind_max";
    readonly label: "Wind speed (maximum)";
    readonly unit: "m/s";
}, {
    readonly key: "wind_gust_max";
    readonly label: "Wind gust (maximum)";
    readonly unit: "m/s";
}, {
    readonly key: "rainfall_total";
    readonly label: "Rainfall (total)";
    readonly unit: "mm";
}, {
    readonly key: "solar_total";
    readonly label: "Solar (total energy)";
    readonly unit: "MJ/m2";
}, {
    readonly key: "solar_avg";
    readonly label: "Solar (average)";
    readonly unit: "W/m2";
}, {
    readonly key: "eto_total";
    readonly label: "ETo (total)";
    readonly unit: "mm";
}, {
    readonly key: "battery_min";
    readonly label: "Battery (minimum)";
    readonly unit: "V";
}, {
    readonly key: "battery_avg";
    readonly label: "Battery (average)";
    readonly unit: "V";
}, {
    readonly key: "lightning_strikes";
    readonly label: "Lightning (total strikes)";
    readonly unit: "";
}, {
    readonly key: "lightning_dist_min";
    readonly label: "Lightning (closest distance)";
    readonly unit: "km";
}, {
    readonly key: "lightning_dist_avg";
    readonly label: "Lightning (average distance)";
    readonly unit: "km";
}, {
    readonly key: "lightning_energy_max";
    readonly label: "Lightning (peak intensity)";
    readonly unit: "";
}, {
    readonly key: "lightning_energy_avg";
    readonly label: "Lightning (average intensity)";
    readonly unit: "";
}];
export type ReportFrequency = 'daily' | 'weekly' | 'monthly';
export interface ReportSchedule {
    id: number;
    name: string;
    stationIds: number[];
    fields: string[];
    recipients: string[];
    frequency: ReportFrequency;
    hour: number;
    weekday: number | null;
    dayOfMonth: number | null;
    enabled: boolean;
    lastRunAt: Date | null;
    lastStatus: string | null;
    createdAt: Date;
    updatedAt: Date;
}
export declare function buildReportBody(s: ReportSchedule): Promise<{
    subject: string;
    text: string;
    html: string;
}>;
/**
 * Build a synthetic lightning report (no station, fabricated data) for
 * demonstration purposes. Used by POST /api/reports/send-demo.
 */
export declare function buildDemoLightningReport(): {
    subject: string;
    text: string;
    html: string;
};
export declare function getAllSchedules(): Promise<ReportSchedule[]>;
export declare function getSchedule(id: number): Promise<ReportSchedule | null>;
export interface CreateScheduleInput {
    name: string;
    stationIds: number[];
    fields: string[];
    recipients: string[];
    frequency: ReportFrequency;
    hour: number;
    weekday?: number | null;
    dayOfMonth?: number | null;
    enabled?: boolean;
}
export declare function createSchedule(input: CreateScheduleInput): Promise<ReportSchedule>;
export declare function updateSchedule(id: number, input: Partial<CreateScheduleInput>): Promise<ReportSchedule | null>;
export declare function deleteSchedule(id: number): Promise<void>;
export declare function runScheduleNow(id: number): Promise<{
    ok: boolean;
    message: string;
}>;
export declare function initReportScheduler(): Promise<void>;
