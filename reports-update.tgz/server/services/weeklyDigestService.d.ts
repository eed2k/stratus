export declare function runDigestNow(): Promise<boolean>;
export declare function initWeeklyDigest(): Promise<void>;
export declare function stopWeeklyDigest(): void;
