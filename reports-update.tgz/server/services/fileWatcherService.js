"use strict";
// Stratus Weather Server
// Created by Lukas Esterhuizen
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.fileWatcherService = exports.FileWatcherService = void 0;
/**
 * File Watcher Service
 * Watches a local folder (e.g., Dropbox sync folder) for new/updated .dat files
 * and automatically imports them into Stratus
 */
const events_1 = require("events");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const localStorage_1 = require("../localStorage");
const campbellScientific_1 = require("../parsers/campbellScientific");
class FileWatcherService extends events_1.EventEmitter {
    constructor() {
        super();
        this.watchedFolders = new Map();
        this.scanTimers = new Map();
        this.initialized = false;
        this.config = {
            scanInterval: 60000, // 1 minute default
            enableAutoImport: true,
        };
    }
    /**
     * Initialise the file watcher service
     */
    async initialize() {
        if (this.initialized)
            return;
        console.log('[FileWatcher] Initializing...');
        // Load watched folders from database/config
        try {
            const folders = await this.loadWatchedFolders();
            for (const folder of folders) {
                await this.addWatchedFolder(folder);
            }
            this.initialized = true;
            console.log(`[FileWatcher] Initialized with ${this.watchedFolders.size} watched folders`);
        }
        catch (error) {
            console.error('[FileWatcher] Initialization error:', error);
        }
    }
    /**
     * Load watched folders configuration
     */
    async loadWatchedFolders() {
        // For now, return empty - will be configured via API
        // In future, load from database
        return [];
    }
    /**
     * Add a folder to watch for new data files
     */
    async addWatchedFolder(config) {
        const folder = {
            ...config,
            lastScan: null,
            processedFiles: new Set(),
        };
        // Validate folder exists
        if (!fs.existsSync(folder.folderPath)) {
            console.warn(`[FileWatcher] Folder does not exist: ${folder.folderPath}`);
            // Try to create it
            try {
                fs.mkdirSync(folder.folderPath, { recursive: true });
                console.log(`[FileWatcher] Created folder: ${folder.folderPath}`);
            }
            catch (err) {
                console.error(`[FileWatcher] Cannot create folder: ${folder.folderPath}`);
                throw new Error(`Folder does not exist and cannot be created: ${folder.folderPath}`);
            }
        }
        this.watchedFolders.set(folder.id, folder);
        if (folder.enabled) {
            this.startWatching(folder.id);
        }
        console.log(`[FileWatcher] Added watched folder: ${folder.folderPath} for station ${folder.stationId}`);
    }
    /**
     * Remove a watched folder
     */
    async removeWatchedFolder(folderId) {
        this.stopWatching(folderId);
        this.watchedFolders.delete(folderId);
        console.log(`[FileWatcher] Removed watched folder: ${folderId}`);
    }
    /**
     * Start watching a folder
     */
    startWatching(folderId) {
        const folder = this.watchedFolders.get(folderId);
        if (!folder)
            return;
        // Initial scan
        this.scanFolder(folderId);
        // Setup periodic scan
        const timer = setInterval(() => {
            this.scanFolder(folderId);
        }, this.config.scanInterval);
        this.scanTimers.set(folderId, timer);
        console.log(`[FileWatcher] Started watching: ${folder.folderPath}`);
    }
    /**
     * Stop watching a folder
     */
    stopWatching(folderId) {
        const timer = this.scanTimers.get(folderId);
        if (timer) {
            clearInterval(timer);
            this.scanTimers.delete(folderId);
        }
    }
    /**
     * Scan a folder for new files
     */
    async scanFolder(folderId) {
        const folder = this.watchedFolders.get(folderId);
        if (!folder || !folder.enabled)
            return;
        try {
            const files = fs.readdirSync(folder.folderPath);
            const pattern = new RegExp(folder.filePattern || '\\.dat$', 'i');
            for (const filename of files) {
                if (!pattern.test(filename))
                    continue;
                if (folder.processedFiles.has(filename))
                    continue;
                const filePath = path.join(folder.folderPath, filename);
                const stats = fs.statSync(filePath);
                // Only process files, not directories
                if (!stats.isFile())
                    continue;
                // Check if file was modified since last scan
                if (folder.lastScan && stats.mtime <= folder.lastScan) {
                    folder.processedFiles.add(filename);
                    continue;
                }
                // Import the file
                await this.importFile(folder.stationId, filePath, filename);
                folder.processedFiles.add(filename);
                this.emit('fileImported', {
                    folderId,
                    stationId: folder.stationId,
                    filename,
                    filePath,
                });
            }
            folder.lastScan = new Date();
        }
        catch (error) {
            console.error(`[FileWatcher] Error scanning folder ${folder.folderPath}:`, error);
            this.emit('error', { folderId, error });
        }
    }
    /**
     * Import a data file into a station
     */
    async importFile(stationId, filePath, filename) {
        console.log(`[FileWatcher] Importing file: ${filename} to station ${stationId}`);
        try {
            const content = fs.readFileSync(filePath, 'utf-8');
            const parsed = (0, campbellScientific_1.parseDataFile)(content);
            if (parsed.errors.length > 0 && parsed.records.length === 0) {
                console.error(`[FileWatcher] Failed to parse ${filename}:`, parsed.errors);
                return 0;
            }
            let importedCount = 0;
            for (const record of parsed.records) {
                try {
                    const weatherData = (0, campbellScientific_1.mapToWeatherData)(record, parsed.units, parsed.headers);
                    // Only insert if we have some valid data
                    if (Object.values(weatherData).some(v => v !== null)) {
                        await localStorage_1.storage.insertWeatherData({
                            stationId,
                            timestamp: record.timestamp,
                            tableName: 'import',
                            data: {
                                temperature: weatherData.temperature ?? undefined,
                                humidity: weatherData.humidity ?? undefined,
                                pressure: weatherData.pressure ?? undefined,
                                windSpeed: weatherData.windSpeed ?? undefined,
                                windDirection: weatherData.windDirection ?? undefined,
                                windGust: weatherData.windGust ?? undefined,
                                solarRadiation: weatherData.solarRadiation ?? undefined,
                                rainfall: weatherData.rainfall ?? undefined,
                                dewPoint: weatherData.dewPoint ?? undefined,
                                soilTemperature: weatherData.soilTemperature ?? undefined,
                                soilMoisture: weatherData.soilMoisture ?? undefined,
                                batteryVoltage: weatherData.batteryVoltage ?? undefined,
                                panelTemperature: weatherData.panelTemperature ?? undefined,
                            }
                        });
                        importedCount++;
                    }
                }
                catch (err) {
                    console.error(`[FileWatcher] Error importing record from ${filename}:`, err.message);
                }
            }
            console.log(`[FileWatcher] Imported ${importedCount} records from ${filename}`);
            return importedCount;
        }
        catch (error) {
            console.error(`[FileWatcher] Error reading file ${filePath}:`, error);
            return 0;
        }
    }
    /**
     * Manually trigger a scan of all watched folders
     */
    async scanAll() {
        for (const folderId of this.watchedFolders.keys()) {
            await this.scanFolder(folderId);
        }
    }
    /**
     * Get all watched folders
     */
    getWatchedFolders() {
        return Array.from(this.watchedFolders.values());
    }
    /**
     * Update configuration
     */
    setConfig(config) {
        this.config = { ...this.config, ...config };
    }
    /**
     * Stop all watchers
     */
    async shutdown() {
        for (const folderId of this.scanTimers.keys()) {
            this.stopWatching(folderId);
        }
        this.watchedFolders.clear();
        console.log('[FileWatcher] Shutdown complete');
    }
}
exports.FileWatcherService = FileWatcherService;
// Singleton instance
exports.fileWatcherService = new FileWatcherService();
