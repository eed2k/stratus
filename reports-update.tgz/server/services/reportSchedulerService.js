"use strict";
// Stratus Weather Server
// Created by Lukas Esterhuizen
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.REPORT_FIELDS = void 0;
exports.buildReportBody = buildReportBody;
exports.buildDemoLightningReport = buildDemoLightningReport;
exports.getAllSchedules = getAllSchedules;
exports.getSchedule = getSchedule;
exports.createSchedule = createSchedule;
exports.updateSchedule = updateSchedule;
exports.deleteSchedule = deleteSchedule;
exports.runScheduleNow = runScheduleNow;
exports.initReportScheduler = initReportScheduler;
/**
 * Report Scheduler Service
 *
 * Powers the password-protected /reports portal. Each row in the
 * `report_schedules` table becomes a node-cron task that builds a
 * plain-text + HTML report for one or more stations and sends it via
 * MailerSend (from MAILERSEND_FROM_EMAIL, default noreply@stratusweather.co.za).
 *
 * Frequencies:
 *   daily        - every day at HH:00 SAST
 *   weekly       - every WEEKDAY at HH:00 SAST  (weekday: 0=Sun..6=Sat)
 *   monthly      - on day-of-month at HH:00 SAST
 *
 * Reporting period:
 *   daily        - last 24 hours
 *   weekly       - last 7 days
 *   monthly      - last 30 days
 */
const cron = __importStar(require("node-cron"));
const emailService_1 = require("./emailService");
const pg = __importStar(require("../db-postgres"));
const stationRainfallOffsets_1 = require("../config/stationRainfallOffsets");
const REPORTS_TZ = process.env.REPORTS_TZ || 'Africa/Johannesburg';
/** Catalog of selectable fields. label is what the user sees; key is stored. */
exports.REPORT_FIELDS = [
    { key: 'temp_min', label: 'Temperature (minimum)', unit: 'degC' },
    { key: 'temp_avg', label: 'Temperature (average)', unit: 'degC' },
    { key: 'temp_max', label: 'Temperature (maximum)', unit: 'degC' },
    { key: 'humidity_avg', label: 'Humidity (average)', unit: '%' },
    { key: 'pressure_avg', label: 'Pressure (average)', unit: 'mbar' },
    { key: 'wind_avg', label: 'Wind speed (average)', unit: 'm/s' },
    { key: 'wind_max', label: 'Wind speed (maximum)', unit: 'm/s' },
    { key: 'wind_gust_max', label: 'Wind gust (maximum)', unit: 'm/s' },
    { key: 'rainfall_total', label: 'Rainfall (total)', unit: 'mm' },
    { key: 'solar_total', label: 'Solar (total energy)', unit: 'MJ/m2' },
    { key: 'solar_avg', label: 'Solar (average)', unit: 'W/m2' },
    { key: 'eto_total', label: 'ETo (total)', unit: 'mm' },
    { key: 'battery_min', label: 'Battery (minimum)', unit: 'V' },
    { key: 'battery_avg', label: 'Battery (average)', unit: 'V' },
    { key: 'lightning_strikes', label: 'Lightning (total strikes)', unit: '' },
    { key: 'lightning_dist_min', label: 'Lightning (closest distance)', unit: 'km' },
    { key: 'lightning_dist_avg', label: 'Lightning (average distance)', unit: 'km' },
    { key: 'lightning_energy_max', label: 'Lightning (peak intensity)', unit: '' },
    { key: 'lightning_energy_avg', label: 'Lightning (average intensity)', unit: '' },
];
const tasks = new Map();
function rowToSchedule(row) {
    return {
        id: row.id,
        name: row.name,
        stationIds: row.station_ids || [],
        fields: row.fields || [],
        recipients: row.recipients || [],
        frequency: row.frequency,
        hour: row.hour,
        weekday: row.weekday,
        dayOfMonth: row.day_of_month,
        enabled: row.enabled,
        lastRunAt: row.last_run_at ? new Date(row.last_run_at) : null,
        lastStatus: row.last_status,
        createdAt: new Date(row.created_at),
        updatedAt: new Date(row.updated_at),
    };
}
function cronExprFor(s) {
    const h = Math.max(0, Math.min(23, s.hour));
    if (s.frequency === 'daily')
        return `0 ${h} * * *`;
    if (s.frequency === 'weekly') {
        const wd = s.weekday == null ? 1 : Math.max(0, Math.min(6, s.weekday));
        return `0 ${h} * * ${wd}`;
    }
    if (s.frequency === 'monthly') {
        const dom = s.dayOfMonth == null ? 1 : Math.max(1, Math.min(28, s.dayOfMonth));
        return `0 ${h} ${dom} * *`;
    }
    return null;
}
function periodFor(freq) {
    const now = Date.now();
    if (freq === 'daily')
        return { startMs: now - 24 * 3600000, endMs: now, label: 'last 24 hours' };
    if (freq === 'weekly')
        return { startMs: now - 7 * 24 * 3600000, endMs: now, label: 'last 7 days' };
    return { startMs: now - 30 * 24 * 3600000, endMs: now, label: 'last 30 days' };
}
const RAIN_COALESCE = `COALESCE(
  data->>'Rain_mm_Tot', data->>'Rain_Tot', data->>'Precip_Tot',
  data->>'Rain_1_Tot', data->>'Rain_Tot_1',
  data->>'rainfall', data->>'Rain_mm', data->>'Precip',
  data->>'Rain', data->>'Rainfall'
)::numeric`;
const TEMP_COALESCE = `COALESCE(data->>'temperature', data->>'AirTC_Avg', data->>'AirTemp', data->>'Temp_Avg', data->>'AirTemp_Avg', data->>'AirTC', data->>'Temp_C', data->>'Temperature')::numeric`;
const HUMIDITY_COALESCE = `COALESCE(data->>'humidity', data->>'RH_Avg', data->>'RH', data->>'RelHumidity_Avg', data->>'RelHumidity', data->>'Humidity')::numeric`;
const PRESSURE_COALESCE = `COALESCE(data->>'pressure', data->>'BP_mbar', data->>'Pressure', data->>'Pressure_Avg', data->>'BaroPressure_Avg', data->>'BP_Avg', data->>'BaroPres', data->>'BP_mbar_Avg', data->>'BPress_Avg', data->>'BPress')::numeric`;
const WIND_COALESCE = `COALESCE(data->>'windSpeed', data->>'WS_ms_Avg', data->>'WindSpeed', data->>'Wind_Spd_S_WVT', data->>'WindSpeed_Avg', data->>'WS_ms', data->>'WS_Avg', data->>'WS_ms_S_WVT', data->>'WSpd_1_Avg', data->>'WSpd_Avg', data->>'WSpd_1_S_WVT')::numeric`;
const GUST_COALESCE = `COALESCE(data->>'windGust', data->>'WS_ms_Max', data->>'Wind_Spd_Max', data->>'WindSpeed_Max', data->>'WS_Max', data->>'Wind_Gust', data->>'WSpd_1_Max', data->>'WSpd_Max')::numeric`;
const SOLAR_COALESCE = `COALESCE(data->>'solarRadiation', data->>'SlrW', data->>'Solar', data->>'Solar_Rad_Avg', data->>'SolarRad_Avg', data->>'SlrW_Avg', data->>'SR_Avg')::numeric`;
const SOLAR_MJ_COALESCE = `COALESCE(data->>'solarMJTotal', data->>'SlrMJ_Tot', data->>'SlrMJ', data->>'Solar_MJ_Tot')::numeric`;
const BATTERY_COALESCE = `COALESCE(data->>'batteryVoltage', data->>'BattV', data->>'BattV_Min', data->>'Batt_volt_Min', data->>'BattV_Avg', data->>'Batt_V', data->>'LoggerBattery_Avg', data->>'LoggerBattery')::numeric`;
const LIGHTNING_COALESCE = `COALESCE(data->>'lightning', data->>'Lightning_Tot', data->>'Lightning_Count', data->>'Lightning')::numeric`;
const LIGHTNING_DIST_COALESCE = `COALESCE(data->>'lightningDistance', data->>'LightningDist', data->>'Lightning_Dist')::numeric`;
const LIGHTNING_ENERGY_COALESCE = `COALESCE(data->>'lightningEnergy', data->>'LightningEnergy', data->>'Lightning_Energy')::numeric`;
async function gatherStationData(stationId, startMs, endMs, fields) {
    const stationRow = await pg.query(`SELECT name FROM stations WHERE id = $1`, [stationId]);
    const name = stationRow.rows[0]?.name || `Station ${stationId}`;
    const stats = {};
    const start = new Date(startMs);
    const end = new Date(endMs);
    // ── Temperature / humidity / pressure / wind / battery / solar (avg/min/max) ──
    if (fields.has('temp_min') || fields.has('temp_avg') || fields.has('temp_max')) {
        const r = await pg.query(`
      SELECT MIN(${TEMP_COALESCE}) AS mn, AVG(${TEMP_COALESCE}) AS av, MAX(${TEMP_COALESCE}) AS mx, COUNT(*) AS n
      FROM weather_data WHERE station_id = $1 AND timestamp >= $2 AND timestamp < $3
        AND ${TEMP_COALESCE} IS NOT NULL
    `, [stationId, start, end]);
        const row = r.rows[0];
        const n = Number(row.n);
        if (fields.has('temp_min'))
            stats['temp_min'] = { value: row.mn != null ? Number(row.mn) : null, readings: n };
        if (fields.has('temp_avg'))
            stats['temp_avg'] = { value: row.av != null ? Number(row.av) : null, readings: n };
        if (fields.has('temp_max'))
            stats['temp_max'] = { value: row.mx != null ? Number(row.mx) : null, readings: n };
    }
    if (fields.has('humidity_avg')) {
        const r = await pg.query(`SELECT AVG(${HUMIDITY_COALESCE}) AS av, COUNT(*) AS n FROM weather_data WHERE station_id = $1 AND timestamp >= $2 AND timestamp < $3 AND ${HUMIDITY_COALESCE} IS NOT NULL`, [stationId, start, end]);
        stats['humidity_avg'] = { value: r.rows[0].av != null ? Number(r.rows[0].av) : null, readings: Number(r.rows[0].n) };
    }
    if (fields.has('pressure_avg')) {
        const r = await pg.query(`SELECT AVG(${PRESSURE_COALESCE}) AS av, COUNT(*) AS n FROM weather_data WHERE station_id = $1 AND timestamp >= $2 AND timestamp < $3 AND ${PRESSURE_COALESCE} IS NOT NULL`, [stationId, start, end]);
        stats['pressure_avg'] = { value: r.rows[0].av != null ? Number(r.rows[0].av) : null, readings: Number(r.rows[0].n) };
    }
    if (fields.has('wind_avg') || fields.has('wind_max')) {
        const r = await pg.query(`SELECT AVG(${WIND_COALESCE}) AS av, MAX(${WIND_COALESCE}) AS mx, COUNT(*) AS n FROM weather_data WHERE station_id = $1 AND timestamp >= $2 AND timestamp < $3 AND ${WIND_COALESCE} IS NOT NULL`, [stationId, start, end]);
        const n = Number(r.rows[0].n);
        if (fields.has('wind_avg'))
            stats['wind_avg'] = { value: r.rows[0].av != null ? Number(r.rows[0].av) : null, readings: n };
        if (fields.has('wind_max'))
            stats['wind_max'] = { value: r.rows[0].mx != null ? Number(r.rows[0].mx) : null, readings: n };
    }
    if (fields.has('wind_gust_max')) {
        const r = await pg.query(`SELECT MAX(${GUST_COALESCE}) AS mx, COUNT(*) AS n FROM weather_data WHERE station_id = $1 AND timestamp >= $2 AND timestamp < $3 AND ${GUST_COALESCE} IS NOT NULL`, [stationId, start, end]);
        stats['wind_gust_max'] = { value: r.rows[0].mx != null ? Number(r.rows[0].mx) : null, readings: Number(r.rows[0].n) };
    }
    if (fields.has('solar_avg') || fields.has('solar_total')) {
        const r = await pg.query(`SELECT AVG(${SOLAR_COALESCE}) AS av, SUM(${SOLAR_MJ_COALESCE}) AS mj_sum, COUNT(*) AS n FROM weather_data WHERE station_id = $1 AND timestamp >= $2 AND timestamp < $3`, [stationId, start, end]);
        if (fields.has('solar_avg'))
            stats['solar_avg'] = { value: r.rows[0].av != null ? Number(r.rows[0].av) : null, readings: Number(r.rows[0].n) };
        if (fields.has('solar_total'))
            stats['solar_total'] = { value: r.rows[0].mj_sum != null ? Number(r.rows[0].mj_sum) : null, readings: Number(r.rows[0].n) };
    }
    if (fields.has('battery_min') || fields.has('battery_avg')) {
        const r = await pg.query(`SELECT MIN(${BATTERY_COALESCE}) AS mn, AVG(${BATTERY_COALESCE}) AS av, COUNT(*) AS n FROM weather_data WHERE station_id = $1 AND timestamp >= $2 AND timestamp < $3 AND ${BATTERY_COALESCE} IS NOT NULL`, [stationId, start, end]);
        const n = Number(r.rows[0].n);
        if (fields.has('battery_min'))
            stats['battery_min'] = { value: r.rows[0].mn != null ? Number(r.rows[0].mn) : null, readings: n };
        if (fields.has('battery_avg'))
            stats['battery_avg'] = { value: r.rows[0].av != null ? Number(r.rows[0].av) : null, readings: n };
    }
    // ── Rainfall total — use cumulative-aware delta sum with per-station offset ──
    if (fields.has('rainfall_total')) {
        const r = await pg.query(`
      WITH r AS (
        SELECT timestamp, ${RAIN_COALESCE} AS v,
               LAG(${RAIN_COALESCE}) OVER (ORDER BY timestamp) AS pv
        FROM weather_data
        WHERE station_id = $1 AND timestamp >= $2 AND timestamp < $3
          AND ${RAIN_COALESCE} IS NOT NULL
      )
      SELECT COUNT(*) AS n, MAX(v) AS mx,
             SUM(CASE WHEN v > 0 AND v < 100 THEN v ELSE 0 END) AS sum_inc,
             SUM(CASE WHEN pv IS NOT NULL AND v >= pv AND (v - pv) < 100 THEN v - pv ELSE 0 END) AS delta_sum
      FROM r
    `, [stationId, start, end]);
        const row = r.rows[0];
        const n = Number(row.n);
        if (n === 0) {
            stats['rainfall_total'] = { value: 0, readings: 0 };
        }
        else {
            const maxV = Number(row.mx);
            // Same heuristic as the dashboard: small max => incremental; large max => cumulative deltas
            let total;
            if (maxV <= 50)
                total = Number(row.sum_inc);
            else
                total = Number(row.delta_sum);
            // Apply per-station rainfall offset clamp at the boundary (same transform applied
            // to live readings via mapToWeatherData, so totals correlate with dashboard).
            const offsetApplied = (0, stationRainfallOffsets_1.applyRainfallOffset)(stationId, total);
            stats['rainfall_total'] = { value: offsetApplied != null ? Math.max(0, offsetApplied) : null, readings: n };
        }
    }
    // ── ETo total (sum of per-record ETo) — cheap approximation: integrate solar MJ ──
    if (fields.has('eto_total')) {
        // We approximate: ETo total ~= 0.5 * solar MJ total (rough ref ET coefficient).
        // Better: compute per-row using FAO PM, but that's heavy in SQL.
        const r = await pg.query(`SELECT SUM(${SOLAR_MJ_COALESCE}) AS s, COUNT(*) AS n FROM weather_data WHERE station_id = $1 AND timestamp >= $2 AND timestamp < $3`, [stationId, start, end]);
        const mjSum = r.rows[0].s != null ? Number(r.rows[0].s) : 0;
        stats['eto_total'] = { value: mjSum > 0 ? Math.round(mjSum * 0.5 * 100) / 100 : 0, readings: Number(r.rows[0].n) };
    }
    // ── Lightning ──
    if (fields.has('lightning_strikes')) {
        // Count strikes = positive deltas in the cumulative counter (same as rainfall pattern)
        const r = await pg.query(`
      WITH r AS (
        SELECT timestamp, ${LIGHTNING_COALESCE} AS v,
               LAG(${LIGHTNING_COALESCE}) OVER (ORDER BY timestamp) AS pv
        FROM weather_data
        WHERE station_id = $1 AND timestamp >= $2 AND timestamp < $3
          AND ${LIGHTNING_COALESCE} IS NOT NULL
      )
      SELECT MAX(v) AS mx,
             SUM(CASE WHEN pv IS NOT NULL AND v > pv AND (v - pv) < 1000 THEN v - pv ELSE 0 END) AS delta_sum,
             SUM(CASE WHEN v > 0 AND v < 1000 THEN v ELSE 0 END) AS sum_inc,
             COUNT(*) AS n
      FROM r
    `, [stationId, start, end]);
        const row = r.rows[0];
        const n = Number(row.n);
        let total = 0;
        if (n > 0) {
            const mx = Number(row.mx);
            total = mx <= 50 ? Number(row.sum_inc) : Number(row.delta_sum);
        }
        stats['lightning_strikes'] = { value: Math.round(total), readings: n };
    }
    if (fields.has('lightning_dist_min') || fields.has('lightning_dist_avg')) {
        const r = await pg.query(`SELECT MIN(${LIGHTNING_DIST_COALESCE}) AS mn, AVG(${LIGHTNING_DIST_COALESCE}) AS av, COUNT(*) AS n FROM weather_data WHERE station_id = $1 AND timestamp >= $2 AND timestamp < $3 AND ${LIGHTNING_DIST_COALESCE} IS NOT NULL AND ${LIGHTNING_DIST_COALESCE} > 0`, [stationId, start, end]);
        const n = Number(r.rows[0].n);
        if (fields.has('lightning_dist_min'))
            stats['lightning_dist_min'] = { value: r.rows[0].mn != null ? Number(r.rows[0].mn) : null, readings: n };
        if (fields.has('lightning_dist_avg'))
            stats['lightning_dist_avg'] = { value: r.rows[0].av != null ? Number(r.rows[0].av) : null, readings: n };
    }
    if (fields.has('lightning_energy_max') || fields.has('lightning_energy_avg')) {
        const r = await pg.query(`SELECT MAX(${LIGHTNING_ENERGY_COALESCE}) AS mx, AVG(${LIGHTNING_ENERGY_COALESCE}) AS av, COUNT(*) AS n FROM weather_data WHERE station_id = $1 AND timestamp >= $2 AND timestamp < $3 AND ${LIGHTNING_ENERGY_COALESCE} IS NOT NULL AND ${LIGHTNING_ENERGY_COALESCE} > 0`, [stationId, start, end]);
        const n = Number(r.rows[0].n);
        if (fields.has('lightning_energy_max'))
            stats['lightning_energy_max'] = { value: r.rows[0].mx != null ? Number(r.rows[0].mx) : null, readings: n };
        if (fields.has('lightning_energy_avg'))
            stats['lightning_energy_avg'] = { value: r.rows[0].av != null ? Number(r.rows[0].av) : null, readings: n };
    }
    return { name, stats };
}
function fmtVal(v, decimals = 1) {
    if (v == null || isNaN(v))
        return 'n/a';
    return v.toFixed(decimals);
}
function escapeHtml(s) {
    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function renderEmail(opts) {
    const { title, periodLabel, fromLabel, toLabel, sections, frequencyLabel, notes } = opts;
    // ── plain text ──
    const tLines = [];
    tLines.push(title);
    tLines.push('='.repeat(Math.min(title.length, 60)));
    tLines.push('');
    tLines.push(`Period:    ${periodLabel}`);
    tLines.push(`From:      ${fromLabel}`);
    tLines.push(`To:        ${toLabel}`);
    tLines.push(`Frequency: ${frequencyLabel}`);
    tLines.push('');
    for (const sec of sections) {
        const heading = sec.stationId != null ? `${sec.name} (id ${sec.stationId})` : sec.name;
        tLines.push(heading);
        tLines.push('-'.repeat(Math.min(heading.length, 60)));
        if (sec.rows.length === 0) {
            tLines.push(sec.emptyMessage || '  (no data)');
        }
        else {
            for (const r of sec.rows) {
                const v = r.unit ? `${r.value} ${r.unit}` : r.value;
                const tag = r.readings > 0 ? `(${r.readings} readings)` : '(no data)';
                tLines.push(`  ${r.label.padEnd(40)} ${v.padEnd(14)} ${tag}`);
            }
        }
        tLines.push('');
    }
    if (notes && notes.length) {
        tLines.push('Notes:');
        for (const n of notes)
            tLines.push(`  - ${n}`);
        tLines.push('');
    }
    tLines.push('Stratus Weather');
    tLines.push('https://stratusweather.co.za/reports');
    const text = tLines.join('\n');
    // ── HTML ──
    const sectionsHtml = sections.map(sec => {
        const heading = sec.stationId != null ? `${escapeHtml(sec.name)} (id ${sec.stationId})` : escapeHtml(sec.name);
        if (sec.rows.length === 0) {
            return `<h3 style="margin:24px 0 8px 0;font-size:15px;color:#0f172a;border-bottom:1px solid #e2e8f0;padding-bottom:6px;">${heading}</h3>
              <p style="margin:8px 0;color:#64748b;font-size:13px;">${escapeHtml(sec.emptyMessage || 'No data available for this period.')}</p>`;
        }
        const rowsHtml = sec.rows.map(r => {
            const v = r.unit ? `${escapeHtml(r.value)} <span style="color:#64748b;">${escapeHtml(r.unit)}</span>` : escapeHtml(r.value);
            const tag = r.readings > 0 ? `${r.readings} readings` : 'no data';
            return `<tr>
        <td style="padding:6px 12px;border-bottom:1px solid #f1f5f9;font-size:13px;color:#334155;">${escapeHtml(r.label)}</td>
        <td style="padding:6px 12px;border-bottom:1px solid #f1f5f9;font-size:13px;color:#0f172a;text-align:right;font-variant-numeric:tabular-nums;">${v}</td>
        <td style="padding:6px 12px;border-bottom:1px solid #f1f5f9;font-size:12px;color:#94a3b8;text-align:right;">${tag}</td>
      </tr>`;
        }).join('');
        return `<h3 style="margin:24px 0 8px 0;font-size:15px;color:#0f172a;border-bottom:1px solid #e2e8f0;padding-bottom:6px;">${heading}</h3>
            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;">${rowsHtml}</table>`;
    }).join('');
    const notesHtml = (notes && notes.length)
        ? `<div style="margin-top:24px;padding:12px 16px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;">
         <p style="margin:0 0 6px 0;font-size:12px;font-weight:600;color:#475569;text-transform:uppercase;letter-spacing:0.5px;">Notes</p>
         <ul style="margin:0;padding-left:20px;color:#475569;font-size:13px;line-height:1.5;">
           ${notes.map(n => `<li>${escapeHtml(n)}</li>`).join('')}
         </ul>
       </div>` : '';
    const html = `<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>${escapeHtml(title)}</title></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;color:#0f172a;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f1f5f9;padding:24px 0;">
  <tr><td align="center">
    <table role="presentation" width="640" cellpadding="0" cellspacing="0" style="max-width:640px;width:100%;background:#ffffff;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,0.06);">
      <tr><td style="padding:24px 32px;border-bottom:1px solid #e2e8f0;">
        <p style="margin:0;font-size:12px;letter-spacing:1px;color:#64748b;text-transform:uppercase;">Stratus Weather Report</p>
        <h1 style="margin:6px 0 0 0;font-size:22px;color:#0f172a;font-weight:600;">${escapeHtml(title)}</h1>
      </td></tr>
      <tr><td style="padding:20px 32px;background:#f8fafc;border-bottom:1px solid #e2e8f0;">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="font-size:13px;color:#475569;">
          <tr><td style="padding:2px 0;width:90px;color:#94a3b8;">Period</td><td style="padding:2px 0;color:#0f172a;">${escapeHtml(periodLabel)}</td></tr>
          <tr><td style="padding:2px 0;color:#94a3b8;">From</td><td style="padding:2px 0;color:#0f172a;">${escapeHtml(fromLabel)}</td></tr>
          <tr><td style="padding:2px 0;color:#94a3b8;">To</td><td style="padding:2px 0;color:#0f172a;">${escapeHtml(toLabel)}</td></tr>
          <tr><td style="padding:2px 0;color:#94a3b8;">Frequency</td><td style="padding:2px 0;color:#0f172a;">${escapeHtml(frequencyLabel)}</td></tr>
        </table>
      </td></tr>
      <tr><td style="padding:8px 32px 24px 32px;">
        ${sectionsHtml}
        ${notesHtml}
      </td></tr>
      <tr><td style="padding:16px 32px;background:#f8fafc;border-top:1px solid #e2e8f0;border-radius:0 0 8px 8px;">
        <p style="margin:0;font-size:12px;color:#64748b;line-height:1.5;">
          This report was generated automatically by Stratus Weather. To manage report schedules,
          visit <a href="https://stratusweather.co.za/reports" style="color:#2563eb;text-decoration:none;">stratusweather.co.za/reports</a>.
        </p>
        <p style="margin:8px 0 0 0;font-size:11px;color:#94a3b8;">
          Sent from noreply@stratusweather.co.za. Please do not reply to this address.
        </p>
      </td></tr>
    </table>
  </td></tr>
</table>
</body></html>`;
    return { text, html };
}
function periodLabelFromFreq(freq) {
    if (freq === 'daily')
        return 'Last 24 hours';
    if (freq === 'weekly')
        return 'Last 7 days';
    return 'Last 30 days';
}
function frequencyLabelFromFreq(freq, hour, weekday, dom) {
    const hh = String(hour).padStart(2, '0');
    if (freq === 'daily')
        return `Daily at ${hh}:00 SAST`;
    if (freq === 'weekly') {
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        return `Weekly on ${days[weekday ?? 1]} at ${hh}:00 SAST`;
    }
    return `Monthly on day ${dom ?? 1} at ${hh}:00 SAST`;
}
async function buildReportBody(s) {
    const { startMs, endMs } = periodFor(s.frequency);
    const fieldSet = new Set(s.fields);
    const sastNow = new Date(endMs).toLocaleString('en-ZA', { timeZone: REPORTS_TZ });
    const sastStart = new Date(startMs).toLocaleString('en-ZA', { timeZone: REPORTS_TZ });
    const periodLabel = periodLabelFromFreq(s.frequency);
    const freqLabel = frequencyLabelFromFreq(s.frequency, s.hour, s.weekday, s.dayOfMonth);
    const sections = [];
    for (const stationId of s.stationIds) {
        const { name, stats } = await gatherStationData(stationId, startMs, endMs, fieldSet);
        const rows = [];
        for (const f of exports.REPORT_FIELDS) {
            if (!fieldSet.has(f.key))
                continue;
            const stat = stats[f.key];
            const decimals = f.key === 'lightning_strikes' ? 0 : (f.unit === '%' || f.unit === 'mbar' ? 1 : 2);
            rows.push({
                label: f.label,
                value: stat ? fmtVal(stat.value, decimals) : 'n/a',
                unit: f.unit,
                readings: stat ? stat.readings : 0,
            });
        }
        const anyData = rows.some(r => r.readings > 0);
        sections.push({
            name,
            stationId,
            rows: anyData ? rows : [],
            emptyMessage: 'No readings recorded for this station during the selected period.',
        });
    }
    const { text, html } = renderEmail({
        title: s.name,
        periodLabel,
        fromLabel: `${sastStart} SAST`,
        toLabel: `${sastNow} SAST`,
        sections,
        frequencyLabel: freqLabel,
    });
    const subject = `Stratus Weather Report: ${s.name} (${periodLabel})`;
    return { subject, text, html };
}
/**
 * Build a synthetic lightning report (no station, fabricated data) for
 * demonstration purposes. Used by POST /api/reports/send-demo.
 */
function buildDemoLightningReport() {
    const endMs = Date.now();
    const startMs = endMs - 24 * 3600 * 1000;
    const sastNow = new Date(endMs).toLocaleString('en-ZA', { timeZone: REPORTS_TZ });
    const sastStart = new Date(startMs).toLocaleString('en-ZA', { timeZone: REPORTS_TZ });
    const rows = [
        { label: 'Lightning (total strikes)', value: '47', unit: '', readings: 1440 },
        { label: 'Lightning (closest distance)', value: '2.3', unit: 'km', readings: 47 },
        { label: 'Lightning (average distance)', value: '11.8', unit: 'km', readings: 47 },
        { label: 'Lightning (peak intensity)', value: '218', unit: '', readings: 47 },
        { label: 'Lightning (average intensity)', value: '74', unit: '', readings: 47 },
    ];
    const sections = [
        { name: 'Demonstration sensor', stationId: null, rows },
    ];
    const { text, html } = renderEmail({
        title: 'Lightning Activity (Demonstration)',
        periodLabel: 'Last 24 hours',
        fromLabel: `${sastStart} SAST`,
        toLabel: `${sastNow} SAST`,
        sections,
        frequencyLabel: 'On demand (demonstration)',
        notes: [
            'This is a demonstration report. The figures shown are illustrative and do not reflect any real measurements.',
            'When connected to a live station, intensity values are reported in raw sensor units (typically 0-1023).',
            'Closest distance is the minimum range of any detected strike during the reporting period.',
        ],
    });
    return {
        subject: 'Stratus Weather Report: Lightning Activity (Demonstration)',
        text,
        html,
    };
}
async function runSchedule(s) {
    if (!(0, emailService_1.isEmailConfigured)()) {
        const msg = 'MailerSend not configured';
        await pg.query(`UPDATE report_schedules SET last_run_at = NOW(), last_status = $1 WHERE id = $2`, [`error: ${msg}`, s.id]);
        return { ok: false, message: msg };
    }
    if (!s.recipients?.length) {
        await pg.query(`UPDATE report_schedules SET last_run_at = NOW(), last_status = $1 WHERE id = $2`, ['error: no recipients', s.id]);
        return { ok: false, message: 'no recipients' };
    }
    if (!s.stationIds?.length) {
        await pg.query(`UPDATE report_schedules SET last_run_at = NOW(), last_status = $1 WHERE id = $2`, ['error: no stations', s.id]);
        return { ok: false, message: 'no stations' };
    }
    try {
        const { subject, text, html } = await buildReportBody(s);
        const sent = await (0, emailService_1.sendEmail)({ to: s.recipients, subject, text, html });
        const status = sent ? `sent to ${s.recipients.length} recipient(s)` : 'send failed';
        await pg.query(`UPDATE report_schedules SET last_run_at = NOW(), last_status = $1 WHERE id = $2`, [status, s.id]);
        console.log(`[Reports] Schedule "${s.name}" (#${s.id}): ${status}`);
        return { ok: sent, message: status };
    }
    catch (err) {
        const msg = err.message || String(err);
        await pg.query(`UPDATE report_schedules SET last_run_at = NOW(), last_status = $1 WHERE id = $2`, [`error: ${msg}`, s.id]);
        console.error(`[Reports] Schedule "${s.name}" (#${s.id}) failed:`, msg);
        return { ok: false, message: msg };
    }
}
async function loadAll() {
    const r = await pg.query(`SELECT * FROM report_schedules ORDER BY id`);
    return r.rows.map(rowToSchedule);
}
async function getAllSchedules() {
    return loadAll();
}
async function getSchedule(id) {
    const r = await pg.query(`SELECT * FROM report_schedules WHERE id = $1`, [id]);
    return r.rows[0] ? rowToSchedule(r.rows[0]) : null;
}
async function createSchedule(input) {
    const r = await pg.query(`
    INSERT INTO report_schedules (name, station_ids, fields, recipients, frequency, hour, weekday, day_of_month, enabled)
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
    RETURNING *
  `, [
        input.name, input.stationIds, input.fields, input.recipients,
        input.frequency, input.hour,
        input.frequency === 'weekly' ? (input.weekday ?? 1) : null,
        input.frequency === 'monthly' ? (input.dayOfMonth ?? 1) : null,
        input.enabled !== false,
    ]);
    const s = rowToSchedule(r.rows[0]);
    registerTask(s);
    return s;
}
async function updateSchedule(id, input) {
    const existing = await getSchedule(id);
    if (!existing)
        return null;
    const merged = {
        name: input.name ?? existing.name,
        stationIds: input.stationIds ?? existing.stationIds,
        fields: input.fields ?? existing.fields,
        recipients: input.recipients ?? existing.recipients,
        frequency: input.frequency ?? existing.frequency,
        hour: input.hour ?? existing.hour,
        weekday: input.weekday ?? existing.weekday,
        dayOfMonth: input.dayOfMonth ?? existing.dayOfMonth,
        enabled: input.enabled ?? existing.enabled,
    };
    const r = await pg.query(`
    UPDATE report_schedules
       SET name = $1, station_ids = $2, fields = $3, recipients = $4,
           frequency = $5, hour = $6, weekday = $7, day_of_month = $8,
           enabled = $9, updated_at = NOW()
     WHERE id = $10 RETURNING *
  `, [
        merged.name, merged.stationIds, merged.fields, merged.recipients,
        merged.frequency, merged.hour,
        merged.frequency === 'weekly' ? (merged.weekday ?? 1) : null,
        merged.frequency === 'monthly' ? (merged.dayOfMonth ?? 1) : null,
        merged.enabled, id,
    ]);
    const s = rowToSchedule(r.rows[0]);
    unregisterTask(id);
    registerTask(s);
    return s;
}
async function deleteSchedule(id) {
    await pg.query(`DELETE FROM report_schedules WHERE id = $1`, [id]);
    unregisterTask(id);
}
async function runScheduleNow(id) {
    const s = await getSchedule(id);
    if (!s)
        return { ok: false, message: 'schedule not found' };
    return runSchedule(s);
}
function registerTask(s) {
    if (!s.enabled)
        return;
    const expr = cronExprFor(s);
    if (!expr || !cron.validate(expr)) {
        console.warn(`[Reports] Skipping schedule #${s.id}: invalid cron "${expr}"`);
        return;
    }
    const task = cron.schedule(expr, () => {
        runSchedule(s).catch(err => console.error(`[Reports] Scheduled run #${s.id} failed:`, err));
    }, { timezone: REPORTS_TZ });
    tasks.set(s.id, task);
}
function unregisterTask(id) {
    const t = tasks.get(id);
    if (t) {
        t.stop();
        tasks.delete(id);
    }
}
async function initReportScheduler() {
    try {
        const all = await loadAll();
        for (const s of all)
            registerTask(s);
        console.log(`[Reports] Scheduler initialised: ${tasks.size} active task(s) of ${all.length} schedule(s)`);
    }
    catch (err) {
        console.error('[Reports] Failed to initialise scheduler:', err.message);
    }
}
