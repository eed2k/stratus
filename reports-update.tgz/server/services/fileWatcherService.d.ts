/**
 * File Watcher Service
 * Watches a local folder (e.g., Dropbox sync folder) for new/updated .dat files
 * and automatically imports them into Stratus
 */
import { EventEmitter } from 'events';
export interface WatchedFolder {
    id: string;
    stationId: number;
    folderPath: string;
    filePattern: string;
    enabled: boolean;
    lastScan: Date | null;
    processedFiles: Set<string>;
}
export interface FileWatcherConfig {
    scanInterval: number;
    enableAutoImport: boolean;
}
export declare class FileWatcherService extends EventEmitter {
    private watchedFolders;
    private scanTimers;
    private config;
    private initialized;
    constructor();
    /**
     * Initialise the file watcher service
     */
    initialize(): Promise<void>;
    /**
     * Load watched folders configuration
     */
    private loadWatchedFolders;
    /**
     * Add a folder to watch for new data files
     */
    addWatchedFolder(config: Omit<WatchedFolder, 'lastScan' | 'processedFiles'>): Promise<void>;
    /**
     * Remove a watched folder
     */
    removeWatchedFolder(folderId: string): Promise<void>;
    /**
     * Start watching a folder
     */
    private startWatching;
    /**
     * Stop watching a folder
     */
    private stopWatching;
    /**
     * Scan a folder for new files
     */
    private scanFolder;
    /**
     * Import a data file into a station
     */
    private importFile;
    /**
     * Manually trigger a scan of all watched folders
     */
    scanAll(): Promise<void>;
    /**
     * Get all watched folders
     */
    getWatchedFolders(): WatchedFolder[];
    /**
     * Update configuration
     */
    setConfig(config: Partial<FileWatcherConfig>): void;
    /**
     * Stop all watchers
     */
    shutdown(): Promise<void>;
}
export declare const fileWatcherService: FileWatcherService;
