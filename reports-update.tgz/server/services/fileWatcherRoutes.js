"use strict";
// Stratus Weather Server
// Created by Lukas Esterhuizen
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * File Watcher API Routes
 * Endpoints for managing watched folders (Dropbox sync, etc.)
 */
const express_1 = require("express");
const fileWatcherService_1 = require("./fileWatcherService");
const nanoid_1 = require("nanoid");
const router = (0, express_1.Router)();
/**
 * GET /api/file-watcher/folders
 * Get all watched folders
 */
router.get('/folders', (_req, res) => {
    try {
        const folders = fileWatcherService_1.fileWatcherService.getWatchedFolders();
        // Convert Set to Array for JSON serialization
        const serializable = folders.map(f => ({
            ...f,
            processedFiles: Array.from(f.processedFiles),
        }));
        res.json(serializable);
    }
    catch (error) {
        console.error('[FileWatcher API] Error getting folders:', error);
        res.status(500).json({ error: error.message });
    }
});
/**
 * POST /api/file-watcher/folders
 * Add a new watched folder
 */
router.post('/folders', async (req, res) => {
    try {
        const { stationId, folderPath, filePattern, enabled = true } = req.body;
        if (!stationId || !folderPath) {
            return res.status(400).json({ error: 'stationId and folderPath are required' });
        }
        const folder = {
            id: (0, nanoid_1.nanoid)(),
            stationId: parseInt(stationId),
            folderPath,
            filePattern: filePattern || '\\.dat$',
            enabled,
        };
        await fileWatcherService_1.fileWatcherService.addWatchedFolder(folder);
        res.status(201).json({
            success: true,
            folder: {
                ...folder,
                lastScan: null,
                processedFiles: [],
            },
        });
    }
    catch (error) {
        console.error('[FileWatcher API] Error adding folder:', error);
        res.status(500).json({ error: error.message });
    }
});
/**
 * DELETE /api/file-watcher/folders/:id
 * Remove a watched folder
 */
router.delete('/folders/:id', async (req, res) => {
    try {
        const { id } = req.params;
        await fileWatcherService_1.fileWatcherService.removeWatchedFolder(id);
        res.json({ success: true });
    }
    catch (error) {
        console.error('[FileWatcher API] Error removing folder:', error);
        res.status(500).json({ error: error.message });
    }
});
/**
 * POST /api/file-watcher/scan
 * Manually trigger a scan of all watched folders
 */
router.post('/scan', async (_req, res) => {
    try {
        await fileWatcherService_1.fileWatcherService.scanAll();
        res.json({ success: true, message: 'Scan triggered' });
    }
    catch (error) {
        console.error('[FileWatcher API] Error scanning folders:', error);
        res.status(500).json({ error: error.message });
    }
});
/**
 * POST /api/file-watcher/scan/:id
 * Manually trigger a scan of a specific folder
 */
router.post('/scan/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const folders = fileWatcherService_1.fileWatcherService.getWatchedFolders();
        const folder = folders.find(f => f.id === id);
        if (!folder) {
            return res.status(404).json({ error: 'Folder not found' });
        }
        await fileWatcherService_1.fileWatcherService.scanAll(); // Will scan the specific folder
        res.json({ success: true, message: `Scan triggered for folder ${folder.folderPath}` });
    }
    catch (error) {
        console.error('[FileWatcher API] Error scanning folder:', error);
        res.status(500).json({ error: error.message });
    }
});
exports.default = router;
