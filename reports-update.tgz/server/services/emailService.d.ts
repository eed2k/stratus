export interface EmailOptions {
    to: string | string[];
    subject: string;
    text?: string;
    html?: string;
}
export interface AlarmEmailData {
    stationName: string;
    stationId: number;
    alarmName: string;
    severity: 'info' | 'warning' | 'error' | 'critical';
    condition: string;
    threshold: number;
    currentValue: number;
    unit: string;
    triggeredAt: Date;
    dashboardUrl?: string;
}
/**
 * Check if email service is configured
 */
export declare function isEmailConfigured(): boolean;
/**
 * Send a generic email via MailerSend API
 */
export declare function sendEmail(options: EmailOptions): Promise<boolean>;
/**
 * Send email using alerts address (for alarm notifications)
 */
export declare function sendAlertEmail(options: EmailOptions): Promise<boolean>;
/**
 * Send alarm notification email
 */
export declare function sendAlarmEmail(recipients: string[], data: AlarmEmailData): Promise<boolean>;
/**
 * Send alarm resolution email
 */
export declare function sendAlarmResolvedEmail(recipients: string[], data: AlarmEmailData & {
    resolvedAt: Date;
}): Promise<boolean>;
/**
 * Send user invitation email with password setup link
 */
export declare function sendUserInvitationEmail(to: string, data: {
    firstName?: string;
    inviterName?: string;
    setupToken: string;
    customMessage?: string;
}): Promise<boolean>;
/**
 * Send password reset email
 */
export declare function sendPasswordResetEmail(to: string, data: {
    firstName?: string;
    resetToken: string;
}): Promise<boolean>;
/**
 * Send test email to verify configuration
 */
export declare function sendTestEmail(to: string): Promise<boolean>;
