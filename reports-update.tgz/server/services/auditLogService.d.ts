export interface AuditLogEntry {
    timestamp: string;
    userId: string;
    userEmail: string;
    action: string;
    resource: string;
    resourceId?: string | number;
    details?: Record<string, any>;
    ip?: string;
    userAgent?: string;
    status: 'success' | 'failure';
    errorMessage?: string;
}
export declare const AUDIT_ACTIONS: {
    readonly LOGIN: "USER_LOGIN";
    readonly LOGOUT: "USER_LOGOUT";
    readonly LOGIN_FAILED: "LOGIN_FAILED";
    readonly PASSWORD_CHANGE: "PASSWORD_CHANGE";
    readonly PASSWORD_RESET_REQUEST: "PASSWORD_RESET_REQUEST";
    readonly PASSWORD_RESET: "PASSWORD_RESET";
    readonly USER_ACTIVATED: "USER_ACTIVATED";
    readonly USER_CREATE: "USER_CREATE";
    readonly USER_UPDATE: "USER_UPDATE";
    readonly USER_DELETE: "USER_DELETE";
    readonly USER_ROLE_CHANGE: "USER_ROLE_CHANGE";
    readonly STATION_CREATE: "STATION_CREATE";
    readonly STATION_UPDATE: "STATION_UPDATE";
    readonly STATION_DELETE: "STATION_DELETE";
    readonly STATION_CONNECT: "STATION_CONNECT";
    readonly STATION_DISCONNECT: "STATION_DISCONNECT";
    readonly DATA_COLLECT: "DATA_COLLECT";
    readonly DATA_EXPORT: "DATA_EXPORT";
    readonly DATA_DELETE: "DATA_DELETE";
    readonly ALARM_CREATE: "ALARM_CREATE";
    readonly ALARM_UPDATE: "ALARM_UPDATE";
    readonly ALARM_DELETE: "ALARM_DELETE";
    readonly ALARM_ACKNOWLEDGE: "ALARM_ACKNOWLEDGE";
    readonly ORG_CREATE: "ORG_CREATE";
    readonly ORG_UPDATE: "ORG_UPDATE";
    readonly ORG_DELETE: "ORG_DELETE";
    readonly SETTINGS_UPDATE: "SETTINGS_UPDATE";
    readonly SYSTEM_STARTUP: "SYSTEM_STARTUP";
    readonly SYSTEM_SHUTDOWN: "SYSTEM_SHUTDOWN";
    readonly CONFIG_CHANGE: "CONFIG_CHANGE";
};
export type AuditAction = typeof AUDIT_ACTIONS[keyof typeof AUDIT_ACTIONS];
declare class AuditLogService {
    private logDir;
    private currentLogFile;
    private inMemoryLogs;
    private maxInMemoryLogs;
    constructor();
    private ensureLogDirectory;
    private getLogFileName;
    private formatLogEntry;
    /**
     * Log an admin action
     */
    log(action: AuditAction, resource: string, options?: {
        userId?: string;
        userEmail?: string;
        resourceId?: string | number;
        details?: Record<string, any>;
        ip?: string;
        userAgent?: string;
        status?: 'success' | 'failure';
        errorMessage?: string;
    }): Promise<void>;
    /**
     * Sanitize details to remove sensitive information
     */
    private sanitizeDetails;
    /**
     * Get recent audit logs from memory
     */
    getRecentLogs(limit?: number): AuditLogEntry[];
    /**
     * Get audit logs for a specific date
     */
    getLogsForDate(date: string): Promise<AuditLogEntry[]>;
    /**
     * Get audit logs for a specific user
     */
    getLogsForUser(userId: string, days?: number): Promise<AuditLogEntry[]>;
    /**
     * Get audit logs for a specific action
     */
    getLogsForAction(action: AuditAction, days?: number): Promise<AuditLogEntry[]>;
    /**
     * Search audit logs
     */
    searchLogs(criteria: {
        action?: AuditAction;
        userId?: string;
        resource?: string;
        startDate?: string;
        endDate?: string;
        status?: 'success' | 'failure';
    }, limit?: number): Promise<AuditLogEntry[]>;
}
export declare const auditLog: AuditLogService;
export default auditLog;
