"use strict";
// Stratus Weather Server
// Created by Lukas Esterhuizen
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.requireReportsAuth = requireReportsAuth;
/**
 * Routes for the password-protected /reports portal.
 *
 * Auth model: a single shared password (env REPORTS_PASSWORD). On successful
 * POST /api/reports/auth we set an HTTP-only cookie `stratus_reports` whose
 * value is an HMAC of the password+expiry. requireReportsAuth verifies this
 * cookie. No interaction with the main user/admin auth.
 */
const express_1 = require("express");
const crypto = __importStar(require("crypto"));
const pg = __importStar(require("../db-postgres"));
const reportSchedulerService_1 = require("./reportSchedulerService");
const emailService_1 = require("./emailService");
const router = (0, express_1.Router)();
const COOKIE_NAME = 'stratus_reports';
const COOKIE_MAX_AGE_MS = 30 * 24 * 3600 * 1000; // 30 days
function getReportsPassword() {
    const p = process.env.REPORTS_PASSWORD;
    return p && p.length > 0 ? p : null;
}
function getSecret() {
    // Reuse SESSION_SECRET if set, else derive from password — guarantees
    // tokens are invalidated whenever the password changes.
    return process.env.REPORTS_COOKIE_SECRET
        || process.env.SESSION_SECRET
        || `stratus-reports::${getReportsPassword() || 'unset'}`;
}
function signToken(expiryMs) {
    const h = crypto.createHmac('sha256', getSecret()).update(String(expiryMs)).digest('hex');
    return `${expiryMs}.${h}`;
}
function verifyToken(token) {
    if (!token || !token.includes('.'))
        return false;
    const [expStr, sig] = token.split('.', 2);
    const exp = Number(expStr);
    if (!Number.isFinite(exp) || exp < Date.now())
        return false;
    const expected = crypto.createHmac('sha256', getSecret()).update(String(exp)).digest('hex');
    try {
        return crypto.timingSafeEqual(Buffer.from(sig, 'hex'), Buffer.from(expected, 'hex'));
    }
    catch {
        return false;
    }
}
function parseCookies(header) {
    const out = {};
    if (!header)
        return out;
    for (const part of header.split(';')) {
        const idx = part.indexOf('=');
        if (idx < 0)
            continue;
        const k = part.slice(0, idx).trim();
        const v = part.slice(idx + 1).trim();
        if (k)
            out[k] = decodeURIComponent(v);
    }
    return out;
}
function setReportsCookie(res, expiryMs) {
    const token = signToken(expiryMs);
    // SameSite=Lax + HttpOnly; secure when not on plain HTTP (Traefik terminates TLS)
    const secure = (process.env.NODE_ENV || 'production') === 'production';
    const maxAgeSec = Math.floor((expiryMs - Date.now()) / 1000);
    const parts = [
        `${COOKIE_NAME}=${encodeURIComponent(token)}`,
        `Max-Age=${maxAgeSec}`,
        'Path=/',
        'HttpOnly',
        'SameSite=Lax',
    ];
    if (secure)
        parts.push('Secure');
    res.setHeader('Set-Cookie', parts.join('; '));
}
function clearReportsCookie(res) {
    res.setHeader('Set-Cookie', `${COOKIE_NAME}=; Max-Age=0; Path=/; HttpOnly; SameSite=Lax`);
}
function requireReportsAuth(req, res, next) {
    if (!getReportsPassword()) {
        res.status(503).json({ error: 'reports portal not configured (REPORTS_PASSWORD env var unset)' });
        return;
    }
    const cookies = parseCookies(req.headers.cookie);
    const tok = cookies[COOKIE_NAME];
    if (!tok || !verifyToken(tok)) {
        res.status(401).json({ error: 'unauthorized' });
        return;
    }
    next();
}
// ── Public: status + login + logout ──────────────────────────────────────────
/** Returns whether the portal is configured + whether the caller is authed. */
router.get('/auth', (req, res) => {
    const configured = !!getReportsPassword();
    let authed = false;
    if (configured) {
        const cookies = parseCookies(req.headers.cookie);
        const tok = cookies[COOKIE_NAME];
        authed = !!tok && verifyToken(tok);
    }
    res.json({ configured, authed });
});
router.post('/auth', (req, res) => {
    const expected = getReportsPassword();
    if (!expected) {
        res.status(503).json({ error: 'reports portal not configured' });
        return;
    }
    const submitted = String((req.body && req.body.password) || '');
    // Constant-time compare
    const a = Buffer.from(submitted);
    const b = Buffer.from(expected);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
        // Mild rate-limit via 401
        res.status(401).json({ error: 'invalid password' });
        return;
    }
    const exp = Date.now() + COOKIE_MAX_AGE_MS;
    setReportsCookie(res, exp);
    res.json({ ok: true, expiresAt: exp });
});
router.post('/logout', (_req, res) => {
    clearReportsCookie(res);
    res.json({ ok: true });
});
// ── Authed below ─────────────────────────────────────────────────────────────
router.use(requireReportsAuth);
router.get('/fields', (_req, res) => {
    res.json(reportSchedulerService_1.REPORT_FIELDS);
});
router.get('/stations', async (_req, res) => {
    try {
        const r = await pg.query(`SELECT id, name, location FROM stations WHERE is_active = true ORDER BY id`);
        res.json(r.rows);
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
function serialize(s) {
    return {
        id: s.id,
        name: s.name,
        stationIds: s.stationIds,
        fields: s.fields,
        recipients: s.recipients,
        frequency: s.frequency,
        hour: s.hour,
        weekday: s.weekday,
        dayOfMonth: s.dayOfMonth,
        enabled: s.enabled,
        lastRunAt: s.lastRunAt ? s.lastRunAt.toISOString() : null,
        lastStatus: s.lastStatus,
    };
}
function validateInput(body) {
    if (!body || typeof body !== 'object')
        return { ok: false, error: 'invalid body' };
    const name = String(body.name || '').trim();
    if (!name)
        return { ok: false, error: 'name is required' };
    const stationIds = Array.isArray(body.stationIds)
        ? body.stationIds.map((n) => Number(n)).filter((n) => Number.isInteger(n) && n > 0)
        : [];
    if (!stationIds.length)
        return { ok: false, error: 'at least one station is required' };
    const validKeys = new Set(reportSchedulerService_1.REPORT_FIELDS.map(f => f.key));
    const fields = Array.isArray(body.fields)
        ? body.fields.filter((k) => typeof k === 'string' && validKeys.has(k))
        : [];
    if (!fields.length)
        return { ok: false, error: 'at least one field is required' };
    const recipients = Array.isArray(body.recipients)
        ? body.recipients.map((s) => String(s).trim()).filter((s) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s))
        : [];
    if (!recipients.length)
        return { ok: false, error: 'at least one valid recipient email is required' };
    const frequency = body.frequency;
    if (frequency !== 'daily' && frequency !== 'weekly' && frequency !== 'monthly') {
        return { ok: false, error: 'frequency must be daily, weekly, or monthly' };
    }
    const hour = Number.isInteger(body.hour) ? body.hour : 8;
    if (hour < 0 || hour > 23)
        return { ok: false, error: 'hour must be 0..23' };
    const weekday = body.weekday == null ? null : Number(body.weekday);
    if (weekday != null && (weekday < 0 || weekday > 6))
        return { ok: false, error: 'weekday must be 0..6' };
    const dayOfMonth = body.dayOfMonth == null ? null : Number(body.dayOfMonth);
    if (dayOfMonth != null && (dayOfMonth < 1 || dayOfMonth > 28))
        return { ok: false, error: 'dayOfMonth must be 1..28' };
    return {
        ok: true,
        value: {
            name, stationIds, fields, recipients, frequency,
            hour, weekday, dayOfMonth,
            enabled: body.enabled !== false,
        },
    };
}
router.get('/schedules', async (_req, res) => {
    try {
        const all = await (0, reportSchedulerService_1.getAllSchedules)();
        res.json(all.map(serialize));
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
router.post('/schedules', async (req, res) => {
    const v = validateInput(req.body);
    if (!v.ok) {
        res.status(400).json({ error: v.error });
        return;
    }
    try {
        const s = await (0, reportSchedulerService_1.createSchedule)(v.value);
        res.status(201).json(serialize(s));
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
router.put('/schedules/:id', async (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) {
        res.status(400).json({ error: 'invalid id' });
        return;
    }
    const v = validateInput(req.body);
    if (!v.ok) {
        res.status(400).json({ error: v.error });
        return;
    }
    try {
        const s = await (0, reportSchedulerService_1.updateSchedule)(id, v.value);
        if (!s) {
            res.status(404).json({ error: 'not found' });
            return;
        }
        res.json(serialize(s));
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
router.delete('/schedules/:id', async (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) {
        res.status(400).json({ error: 'invalid id' });
        return;
    }
    try {
        await (0, reportSchedulerService_1.deleteSchedule)(id);
        res.json({ ok: true });
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
router.post('/schedules/:id/send-now', async (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) {
        res.status(400).json({ error: 'invalid id' });
        return;
    }
    try {
        const result = await (0, reportSchedulerService_1.runScheduleNow)(id);
        if (!result.ok) {
            res.status(500).json(result);
            return;
        }
        res.json(result);
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
/** Render plain-text body without sending — for "Preview" button. */
router.post('/preview', async (req, res) => {
    const v = validateInput(req.body);
    if (!v.ok) {
        res.status(400).json({ error: v.error });
        return;
    }
    try {
        const dummy = {
            id: 0,
            name: v.value.name,
            stationIds: v.value.stationIds,
            fields: v.value.fields,
            recipients: v.value.recipients,
            frequency: v.value.frequency,
            hour: v.value.hour,
            weekday: v.value.weekday ?? null,
            dayOfMonth: v.value.dayOfMonth ?? null,
            enabled: true,
            lastRunAt: null,
            lastStatus: null,
            createdAt: new Date(),
            updatedAt: new Date(),
        };
        const { subject, text } = await (0, reportSchedulerService_1.buildReportBody)(dummy);
        res.json({ subject, text });
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
/**
 * Send a synthetic lightning demo report to the supplied recipients.
 * No real station data is read. Useful for showing prospective users
 * what the email looks like, or for sender deliverability tests.
 */
router.post('/send-demo', async (req, res) => {
    const recipients = Array.isArray(req.body?.recipients)
        ? req.body.recipients.map((s) => String(s).trim())
            .filter((s) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s))
        : [];
    if (!recipients.length) {
        res.status(400).json({ error: 'at least one valid recipient email is required' });
        return;
    }
    try {
        const { subject, text, html } = (0, reportSchedulerService_1.buildDemoLightningReport)();
        const ok = await (0, emailService_1.sendEmail)({ to: recipients, subject, text, html });
        if (!ok) {
            res.status(500).json({ ok: false, error: 'email send failed (see server logs)' });
            return;
        }
        res.json({ ok: true, message: `demo report sent to ${recipients.length} recipient(s)`, subject });
    }
    catch (err) {
        res.status(500).json({ ok: false, error: err.message });
    }
});
exports.default = router;
