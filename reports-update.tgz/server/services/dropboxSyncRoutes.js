"use strict";
// Stratus Weather Server
// Created by Lukas Esterhuizen
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.invalidateDropboxFilesCache = invalidateDropboxFilesCache;
/**
 * Dropbox Sync API Routes
 * Provides endpoints to configure and manage Dropbox synchronisation
 */
const express_1 = require("express");
const dropboxSyncService_1 = require("./dropboxSyncService");
const localStorage_1 = require("../localStorage");
const https_1 = __importDefault(require("https"));
const router = (0, express_1.Router)();
/**
 * GET /api/dropbox-sync/oauth/url
 * Generate OAuth authorisation URL for Dropbox
 */
router.get('/oauth/url', (req, res) => {
    const { appKey } = req.query;
    if (!appKey) {
        return res.status(400).json({ error: 'App Key is required' });
    }
    const authUrl = `https://www.dropbox.com/oauth2/authorize?client_id=${appKey}&response_type=code&token_access_type=offline`;
    res.json({ authUrl });
});
/**
 * POST /api/dropbox-sync/oauth/token
 * Exchange authorisation code for refresh token
 */
router.post('/oauth/token', async (req, res) => {
    try {
        const { appKey, appSecret, authCode } = req.body;
        if (!appKey || !appSecret || !authCode) {
            return res.status(400).json({ error: 'App Key, App Secret, and Authorisation Code are required' });
        }
        // Exchange code for tokens using Dropbox OAuth endpoint
        const tokenData = await new Promise((resolve, reject) => {
            const postData = `code=${encodeURIComponent(authCode)}&grant_type=authorization_code`;
            const auth = Buffer.from(`${appKey}:${appSecret}`).toString('base64');
            const options = {
                hostname: 'api.dropboxapi.com',
                path: '/oauth2/token',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Authorization': `Basic ${auth}`,
                    'Content-Length': Buffer.byteLength(postData)
                }
            };
            const request = https_1.default.request(options, (response) => {
                let data = '';
                response.on('data', chunk => data += chunk);
                response.on('end', () => {
                    try {
                        const parsed = JSON.parse(data);
                        if (response.statusCode !== 200) {
                            reject(new Error(parsed.error_description || parsed.error || 'Token exchange failed'));
                        }
                        else {
                            resolve(parsed);
                        }
                    }
                    catch (e) {
                        reject(new Error('Failed to parse Dropbox response'));
                    }
                });
            });
            request.on('error', reject);
            request.write(postData);
            request.end();
        });
        if (!tokenData.refresh_token) {
            return res.status(400).json({ error: 'No refresh token received. Make sure token_access_type=offline was used.' });
        }
        res.json({
            success: true,
            refreshToken: tokenData.refresh_token,
            accessToken: tokenData.access_token,
            expiresIn: tokenData.expires_in,
            tokenType: tokenData.token_type,
            accountId: tokenData.account_id
        });
    }
    catch (err) {
        console.error('[DropboxSync] OAuth token exchange error:', err);
        res.status(500).json({ error: err.message });
    }
});
/**
 * GET /api/dropbox-sync/status
 * Get the current sync status
 */
router.get('/status', (req, res) => {
    const status = dropboxSyncService_1.dropboxSyncService.getStatus();
    res.json(status);
});
/**
 * GET /api/dropbox-sync/configs
 * Get all Dropbox sync configurations from database
 */
router.get('/configs', async (req, res) => {
    try {
        const configs = await localStorage_1.storage.getDropboxConfigs();
        res.json(configs);
    }
    catch (err) {
        console.error('[DropboxSync] Error getting configs:', err);
        res.status(500).json({ error: err.message });
    }
});
/**
 * POST /api/dropbox-sync/configs
 * Create a new Dropbox sync configuration
 */
router.post('/configs', async (req, res) => {
    try {
        const { name, folderPath, filePattern, stationId, syncInterval, enabled } = req.body;
        if (!name || !folderPath) {
            return res.status(400).json({ error: 'Name and folder path are required' });
        }
        // Prevent duplicate configs for the same station
        if (stationId) {
            const existingConfigs = await localStorage_1.storage.getDropboxConfigs();
            const duplicate = existingConfigs.find(c => c.stationId === stationId);
            if (duplicate) {
                return res.status(409).json({
                    error: `A sync configuration already exists for this station ("${duplicate.name}"). Edit the existing one instead.`,
                    existingConfig: duplicate
                });
            }
        }
        const config = await localStorage_1.storage.createDropboxConfig({
            name,
            folderPath,
            filePattern,
            stationId,
            syncInterval: syncInterval || 3600000,
            enabled: enabled !== false,
        });
        // Reinitialise sync service to pick up new config
        await dropboxSyncService_1.dropboxSyncService.reinitialize();
        invalidateDropboxFilesCache();
        // Auto-trigger an immediate sync so new config gets data right away
        // Run in background so the API responds quickly
        setTimeout(async () => {
            try {
                console.log(`[DropboxSync] Auto-triggering sync for new config "${name}"...`);
                await dropboxSyncService_1.dropboxSyncService.syncNow();
            }
            catch (err) {
                console.error(`[DropboxSync] Auto-sync after config creation failed:`, err.message);
            }
        }, 1000);
        res.json({ success: true, config });
    }
    catch (err) {
        console.error('[DropboxSync] Error creating config:', err);
        res.status(500).json({ error: err.message });
    }
});
/**
 * PUT /api/dropbox-sync/configs/:id
 * Update a Dropbox sync configuration
 */
router.put('/configs/:id', async (req, res) => {
    try {
        const id = parseInt(req.params.id, 10);
        const { name, folderPath, filePattern, stationId, syncInterval, enabled } = req.body;
        const config = await localStorage_1.storage.updateDropboxConfig(id, {
            name,
            folderPath,
            filePattern,
            stationId,
            syncInterval,
            enabled,
        });
        // Reinitialise sync service to pick up changes
        await dropboxSyncService_1.dropboxSyncService.reinitialize();
        invalidateDropboxFilesCache();
        res.json({ success: true, config });
    }
    catch (err) {
        console.error('[DropboxSync] Error updating config:', err);
        res.status(500).json({ error: err.message });
    }
});
/**
 * DELETE /api/dropbox-sync/configs/:id
 * Delete a Dropbox sync configuration
 */
router.delete('/configs/:id', async (req, res) => {
    try {
        const id = parseInt(req.params.id, 10);
        await localStorage_1.storage.deleteDropboxConfig(id);
        // Reinitialise sync service to pick up changes
        await dropboxSyncService_1.dropboxSyncService.reinitialize();
        invalidateDropboxFilesCache();
        res.json({ success: true });
    }
    catch (err) {
        console.error('[DropboxSync] Error deleting config:', err);
        res.status(500).json({ error: err.message });
    }
});
/**
/**
 * GET /api/dropbox-sync/files
 * List .dat files in Dropbox.
 * Default window: files modified within the last 14 days. Accepts:
 *   ?windowDays=N   - override window (1..3650)
 *   ?all=1          - return every .dat file regardless of age
 *   ?refresh=1      - bypass server cache and force a fresh Dropbox listing
 *
 * Server-side cache is 60 s to keep the page snappy without holding stale
 * data when a station resumes sending after a long offline period.
 */
let filesCache = null;
const FILES_CACHE_TTL = 60 * 1000; // 60 seconds
function invalidateDropboxFilesCache() {
    filesCache = null;
}
router.get('/files', async (req, res) => {
    try {
        const now = Date.now();
        const refresh = req.query.refresh === '1' || req.query.refresh === 'true';
        const showAll = req.query.all === '1' || req.query.all === 'true';
        let windowDays = parseInt(String(req.query.windowDays ?? ''), 10);
        if (!Number.isFinite(windowDays) || windowDays <= 0)
            windowDays = 14;
        if (windowDays > 3650)
            windowDays = 3650;
        let allFiles;
        if (!refresh && filesCache && (now - filesCache.ts) < FILES_CACHE_TTL) {
            allFiles = filesCache.data;
        }
        else {
            allFiles = await dropboxSyncService_1.dropboxSyncService.listAllFiles();
            filesCache = { data: allFiles, ts: now };
        }
        if (showAll) {
            return res.json(allFiles);
        }
        const cutoff = now - windowDays * 24 * 60 * 60 * 1000;
        const recentFiles = allFiles.filter((f) => {
            if (!f.modified)
                return false;
            return new Date(f.modified).getTime() >= cutoff;
        });
        res.json(recentFiles);
    }
    catch (err) {
        console.error('[DropboxSync] Error listing files:', err);
        res.status(500).json({ error: err.message });
    }
});
/**
 * GET /api/dropbox-sync/discover
 * Discover ALL files and folders in Dropbox (for finding new data sources)
 */
router.get('/discover', async (req, res) => {
    try {
        const contents = await dropboxSyncService_1.dropboxSyncService.listAllDropboxContents();
        res.json(contents);
    }
    catch (err) {
        console.error('[DropboxSync] Error discovering contents:', err);
        res.status(500).json({ error: err.message });
    }
});
/**
 * GET /api/dropbox-sync/preview
 * Preview a specific .dat file — returns headers, last records, timestamps
 */
router.get('/preview', async (req, res) => {
    try {
        const filePath = req.query.path;
        if (!filePath) {
            return res.status(400).json({ error: 'Missing ?path= parameter' });
        }
        const tailLines = parseInt(req.query.tail) || 10;
        const preview = await dropboxSyncService_1.dropboxSyncService.previewFile(filePath, tailLines);
        res.json(preview);
    }
    catch (err) {
        console.error('[DropboxSync] Error previewing file:', err.message);
        res.status(500).json({ error: err.message });
    }
});
/**
 * GET /api/dropbox-sync/credentials
 * Check if Dropbox credentials are configured
 */
router.get('/credentials', (req, res) => {
    const configured = dropboxSyncService_1.dropboxSyncService.hasCredentials();
    // Return whether refresh token is configured (for UI display)
    const hasRefreshToken = !!process.env.DROPBOX_REFRESH_TOKEN;
    res.json({
        configured,
        hasRefreshToken,
        // Return partial info about configuration (not the actual secrets)
        appKeyConfigured: !!process.env.DROPBOX_APP_KEY,
        appSecretConfigured: !!process.env.DROPBOX_APP_SECRET,
        refreshTokenConfigured: hasRefreshToken,
    });
});
/**
 * POST /api/dropbox-sync/credentials
 * Save Dropbox credentials (admin only - updates .env file on server)
 */
router.post('/credentials', async (req, res) => {
    try {
        const { appKey, appSecret, refreshToken } = req.body;
        if (!appKey || !appSecret || !refreshToken) {
            return res.status(400).json({
                success: false,
                error: 'App Key, App Secret, and Refresh Token are all required'
            });
        }
        // Store credentials in memory and configure the service
        process.env.DROPBOX_APP_KEY = appKey;
        process.env.DROPBOX_APP_SECRET = appSecret;
        process.env.DROPBOX_REFRESH_TOKEN = refreshToken;
        // Persist credentials to database so they survive restarts
        try {
            const { setSetting } = await Promise.resolve().then(() => __importStar(require('../db-postgres')));
            const { setSetting: setSqlite } = await Promise.resolve().then(() => __importStar(require('../db')));
            const { isPostgresEnabled } = await Promise.resolve().then(() => __importStar(require('../db-postgres')));
            const credPayload = JSON.stringify({ appKey, appSecret, refreshToken });
            if (isPostgresEnabled()) {
                await setSetting('dropbox_credentials', credPayload);
            }
            else {
                setSqlite('dropbox_credentials', credPayload);
            }
            console.log('[DropboxSync] Credentials persisted to database');
        }
        catch (persistErr) {
            console.warn('[DropboxSync] Could not persist credentials to DB:', persistErr.message);
        }
        // Configure the dropbox service with the new credentials
        dropboxSyncService_1.dropboxSyncService.configure({
            accessToken: '', // Will be obtained via refresh token
            refreshToken,
            appKey,
            appSecret,
            folderPath: process.env.DROPBOX_FOLDER_PATH || '',
            stationId: parseInt(process.env.DROPBOX_STATION_ID || '0', 10),
            syncInterval: parseInt(process.env.DROPBOX_SYNC_INTERVAL || '3600000', 10),
            enabled: true,
        });
        // Test the connection with new credentials
        const testResult = await dropboxSyncService_1.dropboxSyncService.testConnection();
        if (!testResult.success) {
            return res.status(400).json({
                success: false,
                error: `Credentials saved but connection test failed: ${testResult.message}`,
                testResult
            });
        }
        res.json({
            success: true,
            message: 'Dropbox credentials configured successfully. Connection test passed.',
            testResult
        });
    }
    catch (err) {
        console.error('[DropboxSync] Credentials configuration error:', err);
        res.status(500).json({ success: false, error: err.message });
    }
});
/**
 * POST /api/dropbox-sync/configure
 * Configure Dropbox sync settings
 */
router.post('/configure', async (req, res) => {
    try {
        const { accessToken, folderPath, stationId, syncInterval, enabled } = req.body;
        if (!accessToken) {
            return res.status(400).json({ success: false, error: 'Access token is required' });
        }
        if (!stationId) {
            return res.status(400).json({ success: false, error: 'Station ID is required' });
        }
        const config = {
            accessToken,
            folderPath: folderPath || '',
            stationId: parseInt(stationId, 10),
            syncInterval: syncInterval || 300000, // Default: 5 minutes
            enabled: enabled !== false, // Default: true
        };
        dropboxSyncService_1.dropboxSyncService.configure(config);
        res.json({
            success: true,
            message: 'Dropbox sync configured successfully',
            enabled: config.enabled,
        });
    }
    catch (err) {
        console.error('[DropboxSync] Configuration error:', err);
        res.status(500).json({ success: false, error: err.message });
    }
});
/**
 * POST /api/dropbox-sync/test
 * Test the Dropbox connection
 */
router.post('/test', async (req, res) => {
    try {
        const result = await dropboxSyncService_1.dropboxSyncService.testConnection();
        res.json(result);
    }
    catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});
/**
 * POST /api/dropbox-sync/sync
 * Trigger an immediate sync
 * Query params:
 *   - fullImport=true: Import all records (not just last 48 hours)
 */
router.post('/sync', async (req, res) => {
    try {
        const fullImport = req.query.fullImport === 'true' || req.body.fullImport === true;
        const result = await dropboxSyncService_1.dropboxSyncService.syncNow(fullImport);
        res.json(result);
    }
    catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});
/**
 * POST /api/dropbox-sync/start
 * Start automatic syncing
 */
router.post('/start', (req, res) => {
    dropboxSyncService_1.dropboxSyncService.startSync();
    res.json({ success: true, message: 'Sync started' });
});
/**
 * POST /api/dropbox-sync/stop
 * Stop automatic syncing
 */
router.post('/stop', (req, res) => {
    dropboxSyncService_1.dropboxSyncService.stopSync();
    res.json({ success: true, message: 'Sync stopped' });
});
exports.default = router;
