"use strict";
// Stratus Weather Server
// Created by Lukas Esterhuizen
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.serveStatic = serveStatic;
const express_1 = __importDefault(require("express"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
function serveStatic(app) {
    // Cloud/Docker: Server runs from /app/dist/server/, client at /app/client/dist/
    // __dirname in compiled server: /app/dist/server (Docker)
    const possiblePaths = [
        path_1.default.resolve(__dirname, "..", "..", "client", "dist"), // Docker: /app/dist/server -> /app/client/dist
        path_1.default.resolve(process.cwd(), "client", "dist"), // CWD/client/dist (fallback)
        path_1.default.resolve(__dirname, "..", "client", "dist"), // Alternative layout
    ];
    let distPath = null;
    for (const p of possiblePaths) {
        console.log(`Checking for client dist at: ${p}`);
        if (fs_1.default.existsSync(p)) {
            const indexPath = path_1.default.join(p, "index.html");
            if (fs_1.default.existsSync(indexPath)) {
                distPath = p;
                console.log(`Found client dist at: ${p}`);
                break;
            }
            else {
                console.log(`Found directory but no index.html at: ${p}`);
            }
        }
    }
    if (!distPath) {
        console.error("Could not find client dist directory. Tried:", possiblePaths);
        console.error("Current __dirname:", __dirname);
        console.error("Current cwd:", process.cwd());
        // List what's in the current directory for debugging
        try {
            const cwdContents = fs_1.default.readdirSync(process.cwd());
            console.error("CWD contents:", cwdContents);
            if (fs_1.default.existsSync(path_1.default.join(process.cwd(), 'client'))) {
                const clientContents = fs_1.default.readdirSync(path_1.default.join(process.cwd(), 'client'));
                console.error("Client folder contents:", clientContents);
            }
        }
        catch (e) {
            console.error("Error listing directories:", e);
        }
        throw new Error(`Could not find the build directory, make sure to build the client first`);
    }
    console.log(`Serving static files from: ${distPath}`);
    // Cache hashed assets (JS/CSS with content hashes) for 1 year
    app.use("/assets", express_1.default.static(path_1.default.join(distPath, "assets"), {
        maxAge: "1y",
        immutable: true,
    }));
    // Serve other static files with no-cache
    app.use(express_1.default.static(distPath, {
        maxAge: 0,
        etag: false,
    }));
    app.use("*", (_req, res) => {
        // Always send fresh index.html (no browser caching)
        res.set("Cache-Control", "no-cache, no-store, must-revalidate");
        res.set("Pragma", "no-cache");
        res.set("Expires", "0");
        res.sendFile(path_1.default.resolve(distPath, "index.html"));
    });
}
