"use strict";
// Stratus Weather Server
// Created by Lukas Esterhuizen
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.saveDatabase = void 0;
exports.initDatabase = initDatabase;
exports.getAllStations = getAllStations;
exports.getStationById = getStationById;
exports.createStation = createStation;
exports.updateStation = updateStation;
exports.deleteStation = deleteStation;
exports.insertWeatherData = insertWeatherData;
exports.getWeatherData = getWeatherData;
exports.getLatestWeatherData = getLatestWeatherData;
exports.getUserByEmail = getUserByEmail;
exports.getUserById = getUserById;
exports.createUser = createUser;
exports.updateUser = updateUser;
exports.getAllActiveUsers = getAllActiveUsers;
exports.getAllDropboxConfigs = getAllDropboxConfigs;
exports.getDropboxConfigByStationId = getDropboxConfigByStationId;
exports.createDropboxConfig = createDropboxConfig;
exports.updateDropboxConfigSyncStatus = updateDropboxConfigSyncStatus;
exports.updateDropboxConfig = updateDropboxConfig;
exports.deleteDropboxConfig = deleteDropboxConfig;
exports.getDatabaseMode = getDatabaseMode;
exports.isUsingPostgres = isUsingPostgres;
/**
 * Unified Database Module
 *
 * Automatically selects between SQLite and PostgreSQL based on environment:
 * - If DATABASE_URL is set: Use PostgreSQL (for cloud/managed database deployments)
 * - If DATABASE_URL is not set: Use SQLite (for local/portable deployments)
 *
 * This provides a seamless transition path from SQLite to PostgreSQL
 * without changing application code.
 */
const db_postgres_1 = require("./db-postgres");
// Database mode detection
const usePostgres = (0, db_postgres_1.isPostgresEnabled)();
// Log which database mode is being used
console.log(`[Database] Mode: ${usePostgres ? 'PostgreSQL' : 'SQLite'}`);
if (usePostgres) {
    console.log(`[Database] PostgreSQL connection configured via DATABASE_URL`);
}
// Dynamic imports based on database mode
let dbModule = null;
/**
 * Initialise the database
 * Automatically selects SQLite or PostgreSQL based on DATABASE_URL
 */
async function initDatabase() {
    if (usePostgres) {
        const pgModule = await Promise.resolve().then(() => __importStar(require('./db-postgres')));
        dbModule = pgModule;
        return pgModule.initPostgresDatabase();
    }
    else {
        const sqliteModule = await Promise.resolve().then(() => __importStar(require('./db')));
        dbModule = sqliteModule;
        return sqliteModule.initDatabase();
    }
}
/**
 * Get all stations
 */
function getAllStations() {
    if (!dbModule)
        throw new Error('Database not initialized');
    return dbModule.getAllStations();
}
/**
 * Get station by ID
 */
function getStationById(id) {
    if (!dbModule)
        throw new Error('Database not initialized');
    return dbModule.getStationById(id);
}
/**
 * Create a new station
 */
function createStation(stationData) {
    if (!dbModule)
        throw new Error('Database not initialized');
    return dbModule.createStation(stationData);
}
/**
 * Update a station
 */
function updateStation(id, updates) {
    if (!dbModule)
        throw new Error('Database not initialized');
    return dbModule.updateStation(id, updates);
}
/**
 * Delete a station
 */
function deleteStation(id) {
    if (!dbModule)
        throw new Error('Database not initialized');
    return dbModule.deleteStation(id);
}
/**
 * Insert weather data
 */
function insertWeatherData(stationId, data) {
    if (!dbModule)
        throw new Error('Database not initialized');
    return dbModule.insertWeatherData(stationId, data);
}
/**
 * Get weather data for a station
 */
function getWeatherData(stationId, options) {
    if (!dbModule)
        throw new Error('Database not initialized');
    return dbModule.getWeatherData(stationId, options);
}
/**
 * Get latest weather data for a station
 */
function getLatestWeatherData(stationId) {
    if (!dbModule)
        throw new Error('Database not initialized');
    return dbModule.getLatestWeatherData(stationId);
}
/**
 * Get user by email
 */
function getUserByEmail(email) {
    if (!dbModule)
        throw new Error('Database not initialized');
    return dbModule.getUserByEmail(email);
}
/**
 * Get user by ID
 */
function getUserById(id) {
    if (!dbModule)
        throw new Error('Database not initialized');
    return dbModule.getUserById(id);
}
/**
 * Create a new user
 */
function createUser(email, firstName, lastName, passwordHash, role, stationPermissions) {
    if (!dbModule)
        throw new Error('Database not initialized');
    return dbModule.createUser(email, firstName, lastName, passwordHash, role, stationPermissions);
}
/**
 * Update user
 */
function updateUser(id, updates) {
    if (!dbModule)
        throw new Error('Database not initialized');
    return dbModule.updateUser(id, updates);
}
/**
 * Get all active users
 */
function getAllActiveUsers() {
    if (!dbModule)
        throw new Error('Database not initialized');
    return dbModule.getAllActiveUsers();
}
/**
 * Get all Dropbox configs
 */
function getAllDropboxConfigs() {
    if (!dbModule)
        throw new Error('Database not initialized');
    return dbModule.getAllDropboxConfigs();
}
/**
 * Get Dropbox config for a station
 */
function getDropboxConfigByStationId(stationId) {
    if (!dbModule)
        throw new Error('Database not initialized');
    return dbModule.getDropboxConfigByStationId(stationId);
}
/**
 * Create Dropbox config
 */
function createDropboxConfig(config) {
    if (!dbModule)
        throw new Error('Database not initialized');
    return dbModule.createDropboxConfig(config);
}
/**
 * Update Dropbox config sync status
 */
function updateDropboxConfigSyncStatus(id, status, timestamp) {
    if (!dbModule)
        throw new Error('Database not initialized');
    return dbModule.updateDropboxConfigSyncStatus(id, status, timestamp);
}
/**
 * Update Dropbox config
 */
function updateDropboxConfig(id, updates) {
    if (!dbModule)
        throw new Error('Database not initialized');
    return dbModule.updateDropboxConfig(id, updates);
}
/**
 * Delete Dropbox config
 */
function deleteDropboxConfig(id) {
    if (!dbModule)
        throw new Error('Database not initialized');
    return dbModule.deleteDropboxConfig(id);
}
/**
 * Get database mode
 */
function getDatabaseMode() {
    return usePostgres ? 'postgresql' : 'sqlite';
}
/**
 * Check if using PostgreSQL
 */
function isUsingPostgres() {
    return usePostgres;
}
// Re-export for backward compatibility
var db_1 = require("./db");
Object.defineProperty(exports, "saveDatabase", { enumerable: true, get: function () { return db_1.saveDatabase; } });
