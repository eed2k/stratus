/**
 * Local SQLite Database Module
 * Uses sql.js for a pure JavaScript SQLite implementation
 * No native compilation required - perfect for portable deployments
 */
import { Database } from 'sql.js';
/**
 * Initialise the database connection
 */
export declare function initDatabase(): Promise<Database>;
/**
 * Run a database transaction
 * Ensures atomicity of multiple operations - all succeed or all rollback
 * callback: Function that performs database operations
 * Returns Result of the callback function
 * Throws Error if transaction fails (after rollback)
 */
export declare function runTransaction<T>(callback: (database: Database) => T): T;
/**
 * Save database to disk
 */
export declare function saveDatabase(): void;
/**
 * Close database connection
 */
export declare function closeDatabase(): void;
/**
 * Get database instance
 */
export declare function getDatabase(): Database | null;
export interface Station {
    id?: number;
    name: string;
    pakbus_address: number;
    connection_type: string;
    connection_config: string;
    security_code?: number;
    created_at?: string;
    updated_at?: string;
    last_connected?: string;
    is_active?: number;
    location?: string;
    latitude?: number;
    longitude?: number;
    altitude?: number;
    datalogger_model?: string;
    datalogger_serial_number?: string;
    program_name?: string;
    modem_model?: string;
    modem_serial_number?: string;
    site_description?: string;
    notes?: string;
    installation_team?: string;
    station_admin?: string;
    station_admin_email?: string;
    station_admin_phone?: string;
    station_image?: string | null;
}
export declare function getAllStations(): Station[];
export declare function getStationById(id: number): Station | null;
export declare function createStation(station: Station): number;
export declare function updateStation(id: number, station: Partial<Station>): void;
export declare function deleteStation(id: number): void;
export interface WeatherRecord {
    id?: number;
    station_id: number;
    table_name: string;
    record_number?: number;
    timestamp: string;
    data: string;
    collected_at?: string;
}
export declare function insertWeatherData(records: WeatherRecord[]): void;
export declare function getWeatherData(stationId: number, tableName: string, startTime?: string, endTime?: string, limit?: number): WeatherRecord[];
export declare function getLatestWeatherData(stationId: number, tableName: string): WeatherRecord | null;
export declare function getSetting(key: string): string | null;
export declare function setSetting(key: string, value: string): void;
export declare function getAllSettings(): Record<string, string>;
export interface Alert {
    id?: number;
    station_id?: number;
    type: string;
    severity: 'info' | 'warning' | 'error' | 'critical';
    message: string;
    is_acknowledged?: number;
    acknowledged_at?: string;
    created_at?: string;
}
export declare function createAlert(alert: Alert): number;
export declare function getActiveAlerts(stationId?: number): Alert[];
export declare function acknowledgeAlert(id: number): void;
export interface OrganizationRecord {
    id: number;
    name: string;
    slug?: string;
    description?: string;
    owner_id: string;
    created_at: string;
    updated_at: string;
}
export interface OrgMemberRecord {
    id: number;
    organization_id: number;
    user_id: string;
    role: string;
    created_at: string;
}
export interface OrgInvitationRecord {
    id: number;
    organization_id: number;
    email: string;
    role: string;
    token: string;
    expires_at?: string;
    created_at: string;
}
export declare function getAllOrganizations(): OrganizationRecord[];
export declare function getOrganizationById(id: number): OrganizationRecord | null;
export declare function createOrganization(name: string, description?: string, ownerId?: string): number;
export declare function updateOrganization(id: number, data: {
    name?: string;
    description?: string | null;
    logoUrl?: string | null;
}): void;
export declare function deleteOrganization(id: number): void;
export declare function getOrganizationMembers(orgId: number): OrgMemberRecord[];
export declare function addOrganizationMember(orgId: number, userId: string, role?: string): number;
export declare function updateMemberRole(orgId: number, userId: string, role: string): void;
export declare function removeOrganizationMember(orgId: number, userId: string): void;
export declare function getOrganizationInvitations(orgId: number): OrgInvitationRecord[];
export declare function createOrganizationInvitation(orgId: number, email: string, role?: string): string;
export interface Share {
    id?: number;
    station_id: number;
    share_token: string;
    name: string;
    email?: string;
    access_level: string;
    password?: string;
    expires_at?: string;
    is_active: number;
    last_accessed_at?: string;
    access_count: number;
    created_by: string;
    created_at?: string;
    updated_at?: string;
}
export declare function createShare(share: Share): string;
export declare function getShareByToken(token: string): Share | null;
export declare function getSharesByStation(stationId: number): Share[];
export declare function updateShare(token: string, updates: Partial<Share>): void;
export declare function deleteShare(token: string): void;
export interface Alarm {
    id?: number;
    station_id: number;
    parameter: string;
    condition: 'above' | 'below' | 'equal' | 'not_equal';
    threshold: number;
    severity?: 'info' | 'warning' | 'critical';
    enabled?: boolean;
    email_notifications?: boolean;
    email_recipients?: string;
    last_triggered_at?: string;
    trigger_count?: number;
    created_at?: string;
    updated_at?: string;
}
export interface AlarmEvent {
    id?: number;
    alarm_id: number;
    station_id: number;
    triggered_value?: number;
    message?: string;
    acknowledged?: boolean;
    acknowledged_by?: string;
    acknowledged_at?: string;
    created_at?: string;
}
export declare function createAlarm(alarm: Alarm): number;
export declare function getAlarmsByStation(stationId: number): Alarm[];
export declare function getAllAlarms(): Alarm[];
export declare function getAlarmById(id: number): Alarm | null;
export declare function updateAlarm(id: number, updates: Partial<Alarm>): void;
export declare function deleteAlarm(id: number): void;
export declare function triggerAlarm(alarmId: number, triggeredValue: number, message?: string): number;
export declare function getAlarmEvents(alarmId?: number, stationId?: number, limit?: number): AlarmEvent[];
export declare function acknowledgeAlarmEvent(eventId: number, acknowledgedBy: string): void;
export declare function deleteAlarmEvent(eventId: number): void;
export declare function cleanupOldAlarmEvents(daysToKeep?: number): number;
export interface DropboxConfigRow {
    id: number;
    name: string;
    folder_path: string;
    file_pattern: string | null;
    station_id: number | null;
    sync_interval: number;
    enabled: number;
    last_sync_at: string | null;
    last_sync_status: string | null;
    last_sync_records: number;
    created_at: string;
    updated_at: string;
}
export declare function getAllDropboxConfigs(): DropboxConfigRow[];
export declare function getDropboxConfigById(id: number): DropboxConfigRow | null;
export declare function createDropboxConfig(name: string, folderPath: string, filePattern: string | null, stationId: number | null, syncInterval: number, enabled: boolean): number;
export declare function updateDropboxConfig(id: number, updates: {
    name?: string;
    folder_path?: string;
    file_pattern?: string | null;
    station_id?: number | null;
    sync_interval?: number;
    enabled?: boolean;
}): void;
export declare function updateDropboxSyncStatus(id: number, status: string, recordsImported: number): void;
export declare function deleteDropboxConfig(id: number): void;
export interface UserRecord {
    id: number;
    email: string;
    first_name: string;
    last_name: string | null;
    password_hash: string;
    role: 'admin' | 'user';
    assigned_stations: string | null;
    is_active: number;
    last_login_at: string | null;
    created_at: string;
    updated_at: string;
}
export declare function getAllActiveUsers(): UserRecord[];
export declare function getUserByEmail(email: string): UserRecord | null;
export declare function createUser(email: string, firstName: string, lastName: string | null, passwordHash: string, role?: 'admin' | 'user', assignedStations?: number[]): number;
export declare function updateUser(email: string, updates: {
    first_name?: string;
    last_name?: string | null;
    password_hash?: string;
    role?: 'admin' | 'user';
    assigned_stations?: number[];
}): void;
export declare function updateUserLastLogin(email: string): void;
export declare function deleteUser(email: string): void;
declare const _default: {
    initDatabase: typeof initDatabase;
    saveDatabase: typeof saveDatabase;
    closeDatabase: typeof closeDatabase;
    getDatabase: typeof getDatabase;
    getAllStations: typeof getAllStations;
    getStationById: typeof getStationById;
    createStation: typeof createStation;
    updateStation: typeof updateStation;
    deleteStation: typeof deleteStation;
    insertWeatherData: typeof insertWeatherData;
    getWeatherData: typeof getWeatherData;
    getLatestWeatherData: typeof getLatestWeatherData;
    getSetting: typeof getSetting;
    setSetting: typeof setSetting;
    getAllSettings: typeof getAllSettings;
    createAlert: typeof createAlert;
    getActiveAlerts: typeof getActiveAlerts;
    acknowledgeAlert: typeof acknowledgeAlert;
    getAllOrganizations: typeof getAllOrganizations;
    getOrganizationById: typeof getOrganizationById;
    createOrganization: typeof createOrganization;
    updateOrganization: typeof updateOrganization;
    deleteOrganization: typeof deleteOrganization;
    getOrganizationMembers: typeof getOrganizationMembers;
    addOrganizationMember: typeof addOrganizationMember;
    updateMemberRole: typeof updateMemberRole;
    removeOrganizationMember: typeof removeOrganizationMember;
    getOrganizationInvitations: typeof getOrganizationInvitations;
    createOrganizationInvitation: typeof createOrganizationInvitation;
    createShare: typeof createShare;
    getShareByToken: typeof getShareByToken;
    getSharesByStation: typeof getSharesByStation;
    updateShare: typeof updateShare;
    deleteShare: typeof deleteShare;
    createAlarm: typeof createAlarm;
    getAlarmById: typeof getAlarmById;
    getAlarmsByStation: typeof getAlarmsByStation;
    getAllAlarms: typeof getAllAlarms;
    updateAlarm: typeof updateAlarm;
    deleteAlarm: typeof deleteAlarm;
    triggerAlarm: typeof triggerAlarm;
    getAlarmEvents: typeof getAlarmEvents;
    acknowledgeAlarmEvent: typeof acknowledgeAlarmEvent;
    deleteAlarmEvent: typeof deleteAlarmEvent;
    cleanupOldAlarmEvents: typeof cleanupOldAlarmEvents;
    getAllDropboxConfigs: typeof getAllDropboxConfigs;
    getDropboxConfigById: typeof getDropboxConfigById;
    createDropboxConfig: typeof createDropboxConfig;
    updateDropboxConfig: typeof updateDropboxConfig;
    updateDropboxSyncStatus: typeof updateDropboxSyncStatus;
    deleteDropboxConfig: typeof deleteDropboxConfig;
    getAllActiveUsers: typeof getAllActiveUsers;
    getUserByEmail: typeof getUserByEmail;
    createUser: typeof createUser;
    updateUser: typeof updateUser;
    updateUserLastLogin: typeof updateUserLastLogin;
    deleteUser: typeof deleteUser;
};
export default _default;
