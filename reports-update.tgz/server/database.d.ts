export interface Station {
    id: number;
    name: string;
    pakbus_address: number;
    connection_type: string;
    connection_config: string;
    security_code?: number;
    created_at: string;
    updated_at: string;
    last_connected?: string;
    is_active: number;
    location?: string;
    latitude?: number;
    longitude?: number;
    altitude?: number;
    datalogger_model?: string;
    datalogger_serial_number?: string;
    program_name?: string;
    modem_model?: string;
    modem_serial_number?: string;
    site_description?: string;
    notes?: string;
    installation_team?: string;
    station_admin?: string;
    station_admin_email?: string;
    station_admin_phone?: string;
    image_url?: string;
}
export interface WeatherData {
    id: number;
    station_id: number;
    timestamp: string;
    record_number?: number;
    battery_voltage?: number;
    panel_temperature?: number;
    air_temperature?: number;
    relative_humidity?: number;
    wind_speed?: number;
    wind_direction?: number;
    solar_radiation?: number;
    rainfall?: number;
    barometric_pressure?: number;
    soil_moisture?: number;
    soil_temperature?: number;
    raw_data?: string;
    created_at: string;
}
export interface User {
    id: number;
    email: string;
    first_name: string;
    last_name?: string;
    password_hash: string;
    role: string;
    station_permissions?: string;
    created_at: string;
    updated_at: string;
    is_active: number;
    last_login?: string;
}
export interface DropboxConfig {
    id: number;
    station_id: number;
    dropbox_path: string;
    file_pattern: string;
    sync_interval: number;
    last_sync?: string;
    last_sync_status?: string;
    created_at: string;
    updated_at: string;
    is_active: number;
    sync_enabled: number;
}
/**
 * Initialise the database
 * Automatically selects SQLite or PostgreSQL based on DATABASE_URL
 */
export declare function initDatabase(): Promise<any>;
/**
 * Get all stations
 */
export declare function getAllStations(): Station[];
/**
 * Get station by ID
 */
export declare function getStationById(id: number): Station | undefined;
/**
 * Create a new station
 */
export declare function createStation(stationData: Partial<Station>): Station;
/**
 * Update a station
 */
export declare function updateStation(id: number, updates: Partial<Station>): Station | undefined;
/**
 * Delete a station
 */
export declare function deleteStation(id: number): boolean;
/**
 * Insert weather data
 */
export declare function insertWeatherData(stationId: number, data: Partial<WeatherData>[]): number;
/**
 * Get weather data for a station
 */
export declare function getWeatherData(stationId: number, options?: {
    startDate?: string;
    endDate?: string;
    limit?: number;
    offset?: number;
}): WeatherData[];
/**
 * Get latest weather data for a station
 */
export declare function getLatestWeatherData(stationId: number): WeatherData | undefined;
/**
 * Get user by email
 */
export declare function getUserByEmail(email: string): User | undefined;
/**
 * Get user by ID
 */
export declare function getUserById(id: number): User | undefined;
/**
 * Create a new user
 */
export declare function createUser(email: string, firstName: string, lastName: string | null, passwordHash: string, role: string, stationPermissions: number[]): User;
/**
 * Update user
 */
export declare function updateUser(id: number, updates: Partial<User>): User | undefined;
/**
 * Get all active users
 */
export declare function getAllActiveUsers(): User[];
/**
 * Get all Dropbox configs
 */
export declare function getAllDropboxConfigs(): DropboxConfig[];
/**
 * Get Dropbox config for a station
 */
export declare function getDropboxConfigByStationId(stationId: number): DropboxConfig | undefined;
/**
 * Create Dropbox config
 */
export declare function createDropboxConfig(config: Partial<DropboxConfig>): DropboxConfig;
/**
 * Update Dropbox config sync status
 */
export declare function updateDropboxConfigSyncStatus(id: number, status: string, timestamp?: string): void;
/**
 * Update Dropbox config
 */
export declare function updateDropboxConfig(id: number, updates: Partial<DropboxConfig>): DropboxConfig | undefined;
/**
 * Delete Dropbox config
 */
export declare function deleteDropboxConfig(id: number): boolean;
/**
 * Get database mode
 */
export declare function getDatabaseMode(): 'sqlite' | 'postgresql';
/**
 * Check if using PostgreSQL
 */
export declare function isUsingPostgres(): boolean;
export { saveDatabase } from './db';
