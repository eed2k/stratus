"use strict";
// Stratus Weather Server
// Created by Lukas Esterhuizen
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.initDatabase = initDatabase;
exports.runTransaction = runTransaction;
exports.saveDatabase = saveDatabase;
exports.closeDatabase = closeDatabase;
exports.getDatabase = getDatabase;
exports.getAllStations = getAllStations;
exports.getStationById = getStationById;
exports.createStation = createStation;
exports.updateStation = updateStation;
exports.deleteStation = deleteStation;
exports.insertWeatherData = insertWeatherData;
exports.getWeatherData = getWeatherData;
exports.getLatestWeatherData = getLatestWeatherData;
exports.getSetting = getSetting;
exports.setSetting = setSetting;
exports.getAllSettings = getAllSettings;
exports.createAlert = createAlert;
exports.getActiveAlerts = getActiveAlerts;
exports.acknowledgeAlert = acknowledgeAlert;
exports.getAllOrganizations = getAllOrganizations;
exports.getOrganizationById = getOrganizationById;
exports.createOrganization = createOrganization;
exports.updateOrganization = updateOrganization;
exports.deleteOrganization = deleteOrganization;
exports.getOrganizationMembers = getOrganizationMembers;
exports.addOrganizationMember = addOrganizationMember;
exports.updateMemberRole = updateMemberRole;
exports.removeOrganizationMember = removeOrganizationMember;
exports.getOrganizationInvitations = getOrganizationInvitations;
exports.createOrganizationInvitation = createOrganizationInvitation;
exports.createShare = createShare;
exports.getShareByToken = getShareByToken;
exports.getSharesByStation = getSharesByStation;
exports.updateShare = updateShare;
exports.deleteShare = deleteShare;
exports.createAlarm = createAlarm;
exports.getAlarmsByStation = getAlarmsByStation;
exports.getAllAlarms = getAllAlarms;
exports.getAlarmById = getAlarmById;
exports.updateAlarm = updateAlarm;
exports.deleteAlarm = deleteAlarm;
exports.triggerAlarm = triggerAlarm;
exports.getAlarmEvents = getAlarmEvents;
exports.acknowledgeAlarmEvent = acknowledgeAlarmEvent;
exports.deleteAlarmEvent = deleteAlarmEvent;
exports.cleanupOldAlarmEvents = cleanupOldAlarmEvents;
exports.getAllDropboxConfigs = getAllDropboxConfigs;
exports.getDropboxConfigById = getDropboxConfigById;
exports.createDropboxConfig = createDropboxConfig;
exports.updateDropboxConfig = updateDropboxConfig;
exports.updateDropboxSyncStatus = updateDropboxSyncStatus;
exports.deleteDropboxConfig = deleteDropboxConfig;
exports.getAllActiveUsers = getAllActiveUsers;
exports.getUserByEmail = getUserByEmail;
exports.createUser = createUser;
exports.updateUser = updateUser;
exports.updateUserLastLogin = updateUserLastLogin;
exports.deleteUser = deleteUser;
/// <reference types="node" />
/**
 * Local SQLite Database Module
 * Uses sql.js for a pure JavaScript SQLite implementation
 * No native compilation required - perfect for portable deployments
 */
const sql_js_1 = __importDefault(require("sql.js"));
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const os = __importStar(require("os"));
let db = null;
const DB_FILE = 'stratus.db';
// Simple logger for database operations
const dbLog = {
    info: (message, ...args) => console.log(`[DB] ${message}`, ...args),
    warn: (message, ...args) => console.warn(`[DB] WARNING: ${message}`, ...args),
    error: (message, error) => {
        console.error(`[DB] ERROR: ${message}`);
        if (error)
            console.error(`[DB] Details:`, error instanceof Error ? error.message : error);
    }
};
// Whitelist of valid column names for SQL safety
const VALID_STATION_COLUMNS = new Set([
    'id', 'name', 'pakbus_address', 'connection_type', 'connection_config',
    'security_code', 'created_at', 'updated_at', 'last_connected', 'is_active',
    'location', 'latitude', 'longitude', 'altitude', 'datalogger_model',
    'datalogger_serial_number', 'program_name', 'modem_model', 'modem_serial_number',
    'site_description', 'notes', 'installation_team', 'station_admin',
    'station_admin_email', 'station_admin_phone'
]);
/**
 * Validates a column name against whitelist to prevent SQL injection
 */
function validateColumnName(column) {
    return VALID_STATION_COLUMNS.has(column);
}
/**
 * Get the database file path
 * Uses standard app data location for the platform
 * Can be overridden with STRATUS_DATA_DIR environment variable
 */
function getDbPath() {
    // Check for environment variable override (useful for Docker)
    if (process.env.STRATUS_DATA_DIR) {
        return path.join(process.env.STRATUS_DATA_DIR, DB_FILE);
    }
    // Use platform-appropriate app data location
    const platform = process.platform;
    let appDataPath;
    if (platform === 'win32') {
        appDataPath = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
    }
    else if (platform === 'darwin') {
        appDataPath = path.join(os.homedir(), 'Library', 'Application Support');
    }
    else {
        appDataPath = process.env.XDG_DATA_HOME || path.join(os.homedir(), '.local', 'share');
    }
    const stratusPath = path.join(appDataPath, 'Stratus Weather Server');
    return path.join(stratusPath, DB_FILE);
}
/**
 * Initialise the database connection
 */
async function initDatabase() {
    if (db)
        return db;
    const SQL = await (0, sql_js_1.default)();
    const dbPath = getDbPath();
    // Ensure directory exists
    const dbDir = path.dirname(dbPath);
    if (!fs.existsSync(dbDir)) {
        fs.mkdirSync(dbDir, { recursive: true });
    }
    // Load existing database or create new one
    if (fs.existsSync(dbPath)) {
        const fileBuffer = fs.readFileSync(dbPath);
        db = new SQL.Database(fileBuffer);
        // Run migrations for existing databases
        await runMigrations(db);
    }
    else {
        db = new SQL.Database();
        await createTables(db);
    }
    // Run startup cleanup to remove demo stations and duplicates
    await runStartupCleanup(db);
    return db;
}
/**
 * Remove demo stations and duplicates on startup
 */
async function runStartupCleanup(database) {
    dbLog.info('Running startup cleanup...');
    try {
        // First, get all stations to identify demos and duplicates
        const stations = database.exec('SELECT id, name, connection_type FROM stations ORDER BY id');
        if (stations.length === 0 || !stations[0].values.length) {
            dbLog.info('No stations to cleanup');
            return;
        }
        const seenNames = new Map(); // name -> first id with that name
        const toDelete = [];
        for (const row of stations[0].values) {
            const id = row[0];
            const name = (row[1] || '').toLowerCase();
            const connectionType = (row[2] || '').toLowerCase();
            // Delete demo stations
            if (name.includes('demo') || connectionType === 'demo') {
                toDelete.push(id);
                dbLog.info(`Marking demo station for deletion: ${row[1]} (ID: ${id})`);
                continue;
            }
            // Delete duplicates (keep first occurrence)
            const normalizedName = name.trim();
            if (seenNames.has(normalizedName)) {
                toDelete.push(id);
                dbLog.info(`Marking duplicate station for deletion: ${row[1]} (ID: ${id})`);
            }
            else {
                seenNames.set(normalizedName, id);
            }
        }
        // Delete marked stations using batch delete for better performance
        if (toDelete.length > 0) {
            const placeholders = toDelete.map(() => '?').join(',');
            database.run(`DELETE FROM weather_data WHERE station_id IN (${placeholders})`, toDelete);
            database.run(`DELETE FROM stations WHERE id IN (${placeholders})`, toDelete);
            dbLog.info(`Cleanup complete: deleted ${toDelete.length} stations (demos and duplicates)`);
            saveDatabase();
        }
        else {
            dbLog.info('Cleanup complete: no stations to delete');
        }
    }
    catch (e) {
        dbLog.error('Startup cleanup failed', e);
    }
}
/**
 * Run a database transaction
 * Ensures atomicity of multiple operations - all succeed or all rollback
 * callback: Function that performs database operations
 * Returns Result of the callback function
 * Throws Error if transaction fails (after rollback)
 */
function runTransaction(callback) {
    if (!db) {
        throw new Error('Database not initialized');
    }
    try {
        db.run('BEGIN TRANSACTION');
        const result = callback(db);
        db.run('COMMIT');
        return result;
    }
    catch (error) {
        db.run('ROLLBACK');
        dbLog.error('Transaction rolled back due to error', error);
        throw error;
    }
}
/**
 * Run database migrations for existing databases
 */
async function runMigrations(database) {
    dbLog.info('Running database migrations...');
    // FIRST: Ensure core tables exist (might be missing if db file was corrupted or partial)
    try {
        database.run(`
      CREATE TABLE IF NOT EXISTS stations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        pakbus_address INTEGER NOT NULL,
        connection_type TEXT NOT NULL,
        connection_config TEXT NOT NULL,
        security_code INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        last_connected DATETIME,
        is_active INTEGER DEFAULT 1,
        latitude REAL,
        longitude REAL,
        altitude REAL,
        installation_team TEXT,
        station_admin TEXT,
        station_admin_email TEXT,
        station_admin_phone TEXT,
        location TEXT,
        datalogger_model TEXT,
        datalogger_serial_number TEXT,
        program_name TEXT,
        modem_model TEXT,
        modem_serial_number TEXT,
        site_description TEXT,
        notes TEXT
      )
    `);
        dbLog.info('Stations table ready');
    }
    catch (e) {
        dbLog.error('Failed to create stations table', e);
    }
    try {
        database.run(`
      CREATE TABLE IF NOT EXISTS weather_data (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        station_id INTEGER NOT NULL,
        table_name TEXT NOT NULL,
        record_number INTEGER,
        timestamp DATETIME NOT NULL,
        data TEXT NOT NULL,
        collected_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (station_id) REFERENCES stations(id) ON DELETE CASCADE
      )
    `);
        dbLog.info('Weather data table ready');
    }
    catch (e) {
        dbLog.error('Failed to create weather_data table', e);
    }
    try {
        database.run(`
      CREATE INDEX IF NOT EXISTS idx_weather_data_station_time 
      ON weather_data(station_id, timestamp)
    `);
        dbLog.info('Weather data time index ready');
    }
    catch (e) {
        // Index might already exist
    }
    // Add index for record_number to improve duplicate detection performance
    try {
        database.run(`
      CREATE INDEX IF NOT EXISTS idx_weather_data_record 
      ON weather_data(station_id, record_number)
    `);
        dbLog.info('Weather data record index ready');
    }
    catch (e) {
        // Index might already exist
    }
    // Add unique index to prevent duplicate weather data (matches PostgreSQL schema)
    try {
        database.run(`
      CREATE UNIQUE INDEX IF NOT EXISTS idx_weather_data_unique_station_table_time
      ON weather_data(station_id, table_name, timestamp)
    `);
        dbLog.info('Weather data unique constraint index ready');
    }
    catch (e) {
        // Index might already exist or duplicates prevent creation
        dbLog.warn('Could not create unique index on weather_data (duplicates may exist)', e);
    }
    // Add index on alarms(station_id) for faster alarm lookups
    try {
        database.run(`
      CREATE INDEX IF NOT EXISTS idx_alarms_station_id
      ON alarms(station_id)
    `);
    }
    catch (e) {
        // Index might already exist
    }
    // Add index on alarm_events(alarm_id) for faster event queries
    try {
        database.run(`
      CREATE INDEX IF NOT EXISTS idx_alarm_events_alarm_id
      ON alarm_events(alarm_id)
    `);
    }
    catch (e) {
        // Index might already exist
    }
    // Add index on shares(station_id) for faster share lookups
    try {
        database.run(`
      CREATE INDEX IF NOT EXISTS idx_shares_station_id
      ON shares(station_id)
    `);
    }
    catch (e) {
        // Index might already exist
    }
    // Add index on users(role) for admin email lookups
    try {
        database.run(`
      CREATE INDEX IF NOT EXISTS idx_users_role
      ON users(role)
    `);
    }
    catch (e) {
        // Index might already exist
    }
    // Add unique constraint on organization_members(organization_id, user_id)
    try {
        database.run(`
      CREATE UNIQUE INDEX IF NOT EXISTS idx_org_members_unique
      ON organization_members(organization_id, user_id)
    `);
    }
    catch (e) {
        // Index might already exist
    }
    try {
        database.run(`
      CREATE TABLE IF NOT EXISTS table_definitions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        station_id INTEGER NOT NULL,
        table_number INTEGER NOT NULL,
        table_name TEXT NOT NULL,
        columns TEXT NOT NULL,
        record_interval INTEGER,
        cached_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (station_id) REFERENCES stations(id) ON DELETE CASCADE
      )
    `);
        dbLog.info('Table definitions table ready');
    }
    catch (e) {
        dbLog.error('Failed to create table_definitions table', e);
    }
    try {
        database.run(`
      CREATE TABLE IF NOT EXISTS collection_schedules (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        station_id INTEGER NOT NULL,
        table_name TEXT NOT NULL,
        cron_expression TEXT NOT NULL,
        is_enabled INTEGER DEFAULT 1,
        last_collection DATETIME,
        next_collection DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (station_id) REFERENCES stations(id) ON DELETE CASCADE
      )
    `);
        dbLog.info('Collection schedules table ready');
    }
    catch (e) {
        dbLog.error('Failed to create collection_schedules table', e);
    }
    // Add personnel columns if they don't exist
    const columns = ['installation_team', 'station_admin', 'station_admin_email', 'station_admin_phone'];
    for (const col of columns) {
        try {
            database.run(`ALTER TABLE stations ADD COLUMN ${col} TEXT`);
            dbLog.info(`Added column: ${col}`);
        }
        catch (e) {
            // Column already exists, this is expected
        }
    }
    // Add location columns if they don't exist
    const locationColumns = ['latitude', 'longitude', 'altitude'];
    for (const col of locationColumns) {
        try {
            database.run(`ALTER TABLE stations ADD COLUMN ${col} REAL`);
            dbLog.info(`Added column: ${col}`);
        }
        catch (e) {
            // Column already exists, this is expected
        }
    }
    // Add equipment and description columns if they don't exist
    const textColumns = [
        'location', 'datalogger_model', 'datalogger_serial_number', 'program_name',
        'modem_model', 'modem_serial_number', 'site_description', 'notes',
        'installation_team', 'station_admin', 'station_admin_email', 'station_admin_phone',
        'station_image'
    ];
    for (const col of textColumns) {
        try {
            database.run(`ALTER TABLE stations ADD COLUMN ${col} TEXT`);
            dbLog.info(`Added column: ${col}`);
        }
        catch (e) {
            // Column already exists, this is expected
        }
    }
    // Add organizations table if it doesn't exist
    try {
        database.run(`
      CREATE TABLE IF NOT EXISTS organizations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        slug TEXT UNIQUE,
        description TEXT,
        owner_id TEXT DEFAULT 'local-user',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);
        dbLog.info('Organizations table ready');
    }
    catch (e) {
        dbLog.error('Failed to create organizations table', e);
    }
    // Add organization members table if it doesn't exist
    try {
        database.run(`
      CREATE TABLE IF NOT EXISTS organization_members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        organization_id INTEGER NOT NULL,
        user_id TEXT NOT NULL,
        role TEXT DEFAULT 'member',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE
      )
    `);
        dbLog.info('Organization members table ready');
    }
    catch (e) {
        dbLog.error('Failed to create organization_members table', e);
    }
    // Add organization invitations table if it doesn't exist
    try {
        database.run(`
      CREATE TABLE IF NOT EXISTS organization_invitations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        organization_id INTEGER NOT NULL,
        email TEXT NOT NULL,
        role TEXT DEFAULT 'member',
        token TEXT UNIQUE NOT NULL,
        expires_at DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE
      )
    `);
        dbLog.info('Organization invitations table ready');
    }
    catch (e) {
        dbLog.error('Failed to create organization_invitations table', e);
    }
    // Add shares table for dashboard sharing
    try {
        database.run(`
      CREATE TABLE IF NOT EXISTS shares (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        station_id INTEGER NOT NULL,
        share_token TEXT UNIQUE NOT NULL,
        name TEXT DEFAULT 'Shared Dashboard',
        email TEXT,
        access_level TEXT DEFAULT 'viewer',
        password TEXT,
        expires_at DATETIME,
        is_active INTEGER DEFAULT 1,
        last_accessed_at DATETIME,
        access_count INTEGER DEFAULT 0,
        created_by TEXT DEFAULT 'admin',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (station_id) REFERENCES stations(id) ON DELETE CASCADE
      )
    `);
        dbLog.info('Shares table ready');
    }
    catch (e) {
        dbLog.error('Failed to create shares table', e);
    }
    // Add alarms table for persistent alarm storage (Issue #10 fix)
    try {
        database.run(`
      CREATE TABLE IF NOT EXISTS alarms (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        station_id INTEGER NOT NULL,
        parameter TEXT NOT NULL,
        condition TEXT NOT NULL,
        threshold REAL NOT NULL,
        stale_minutes INTEGER,
        severity TEXT DEFAULT 'warning',
        enabled INTEGER DEFAULT 1,
        email_notifications INTEGER DEFAULT 0,
        email_recipients TEXT,
        last_triggered_at DATETIME,
        trigger_count INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (station_id) REFERENCES stations(id) ON DELETE CASCADE
      )
    `);
        dbLog.info('Alarms table ready');
    }
    catch (e) {
        dbLog.error('Failed to create alarms table', e);
    }
    // Add alarm_events table to track alarm history
    try {
        database.run(`
      CREATE TABLE IF NOT EXISTS alarm_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        alarm_id INTEGER NOT NULL,
        station_id INTEGER NOT NULL,
        triggered_value REAL,
        message TEXT,
        acknowledged INTEGER DEFAULT 0,
        acknowledged_by TEXT,
        acknowledged_at DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (alarm_id) REFERENCES alarms(id) ON DELETE CASCADE,
        FOREIGN KEY (station_id) REFERENCES stations(id) ON DELETE CASCADE
      )
    `);
        dbLog.info('Alarm events table ready');
    }
    catch (e) {
        dbLog.error('Failed to create alarm_events table', e);
    }
    // Add dropbox_configs table for managing multiple Dropbox sync configurations
    try {
        database.run(`
      CREATE TABLE IF NOT EXISTS dropbox_configs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        folder_path TEXT NOT NULL,
        file_pattern TEXT,
        station_id INTEGER,
        sync_interval INTEGER DEFAULT 3600000,
        enabled INTEGER DEFAULT 1,
        last_sync_at DATETIME,
        last_sync_status TEXT,
        last_sync_records INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);
        dbLog.info('Dropbox configs table ready');
    }
    catch (e) {
        dbLog.error('Failed to create dropbox_configs table', e);
    }
    // Add users table for multi-user authentication
    try {
        database.run(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        first_name TEXT NOT NULL,
        last_name TEXT,
        password_hash TEXT NOT NULL,
        role TEXT DEFAULT 'user',
        assigned_stations TEXT,
        is_active INTEGER DEFAULT 1,
        last_login_at DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);
        dbLog.info('Users table ready');
    }
    catch (e) {
        dbLog.error('Failed to create users table', e);
    }
    saveDatabase();
}
/**
 * Create database tables
 */
async function createTables(database) {
    // Stations table
    database.run(`
    CREATE TABLE IF NOT EXISTS stations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      pakbus_address INTEGER NOT NULL,
      connection_type TEXT NOT NULL,
      connection_config TEXT NOT NULL,
      security_code INTEGER,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      last_connected DATETIME,
      is_active INTEGER DEFAULT 1,
      latitude REAL,
      longitude REAL,
      altitude REAL,
      installation_team TEXT,
      station_admin TEXT,
      station_admin_email TEXT,
      station_admin_phone TEXT
    )
  `);
    // Table definitions cache
    database.run(`
    CREATE TABLE IF NOT EXISTS table_definitions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      station_id INTEGER NOT NULL,
      table_number INTEGER NOT NULL,
      table_name TEXT NOT NULL,
      columns TEXT NOT NULL,
      record_interval INTEGER,
      cached_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (station_id) REFERENCES stations(id) ON DELETE CASCADE
    )
  `);
    // Weather data table
    database.run(`
    CREATE TABLE IF NOT EXISTS weather_data (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      station_id INTEGER NOT NULL,
      table_name TEXT NOT NULL,
      record_number INTEGER,
      timestamp DATETIME NOT NULL,
      data TEXT NOT NULL,
      collected_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (station_id) REFERENCES stations(id) ON DELETE CASCADE
    )
  `);
    // Create index for faster queries
    database.run(`
    CREATE INDEX IF NOT EXISTS idx_weather_data_station_time 
    ON weather_data(station_id, timestamp)
  `);
    // Collection schedules table
    database.run(`
    CREATE TABLE IF NOT EXISTS collection_schedules (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      station_id INTEGER NOT NULL,
      table_name TEXT NOT NULL,
      cron_expression TEXT NOT NULL,
      is_enabled INTEGER DEFAULT 1,
      last_collection DATETIME,
      next_collection DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (station_id) REFERENCES stations(id) ON DELETE CASCADE
    )
  `);
    // Programs table (for CRBasic programs)
    database.run(`
    CREATE TABLE IF NOT EXISTS programs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      station_id INTEGER,
      name TEXT NOT NULL,
      content TEXT NOT NULL,
      is_running INTEGER DEFAULT 0,
      run_on_powerup INTEGER DEFAULT 0,
      uploaded_at DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (station_id) REFERENCES stations(id) ON DELETE SET NULL
    )
  `);
    // Alerts table
    database.run(`
    CREATE TABLE IF NOT EXISTS alerts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      station_id INTEGER,
      type TEXT NOT NULL,
      severity TEXT NOT NULL,
      message TEXT NOT NULL,
      is_acknowledged INTEGER DEFAULT 0,
      acknowledged_at DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (station_id) REFERENCES stations(id) ON DELETE CASCADE
    )
  `);
    // Settings table
    database.run(`
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);
    // Organisations table
    database.run(`
    CREATE TABLE IF NOT EXISTS organizations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      slug TEXT UNIQUE,
      description TEXT,
      owner_id TEXT DEFAULT 'local-user',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);
    // Organization members table
    database.run(`
    CREATE TABLE IF NOT EXISTS organization_members (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      organization_id INTEGER NOT NULL,
      user_id TEXT NOT NULL,
      role TEXT DEFAULT 'member',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE
    )
  `);
    // Organization invitations table
    database.run(`
    CREATE TABLE IF NOT EXISTS organization_invitations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      organization_id INTEGER NOT NULL,
      email TEXT NOT NULL,
      role TEXT DEFAULT 'member',
      token TEXT UNIQUE NOT NULL,
      expires_at DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE
    )
  `);
    // Insert default settings
    database.run(`
    INSERT OR IGNORE INTO settings (key, value) VALUES 
    ('theme', 'system'),
    ('autoConnect', 'true'),
    ('dataRetentionDays', '365'),
    ('defaultPakbusAddress', '1'),
    ('collectionTimeout', '30000')
  `);
    // Add missing columns to stations table (for upgrades from older versions)
    const addColumnIfNotExists = (columnName, columnType) => {
        try {
            // Check if column exists
            const tableInfo = database.exec('PRAGMA table_info(stations)');
            if (tableInfo.length > 0) {
                const columns = tableInfo[0].values.map((row) => row[1]);
                if (!columns.includes(columnName)) {
                    database.run(`ALTER TABLE stations ADD COLUMN ${columnName} ${columnType}`);
                }
            }
        }
        catch (e) {
            // Column might already exist, ignore error
        }
    };
    // Equipment columns
    addColumnIfNotExists('location', 'TEXT');
    addColumnIfNotExists('datalogger_model', 'TEXT');
    addColumnIfNotExists('datalogger_serial_number', 'TEXT');
    addColumnIfNotExists('program_name', 'TEXT');
    addColumnIfNotExists('modem_model', 'TEXT');
    addColumnIfNotExists('modem_serial_number', 'TEXT');
    // Description columns
    addColumnIfNotExists('site_description', 'TEXT');
    addColumnIfNotExists('notes', 'TEXT');
    // Dashboard configuration
    addColumnIfNotExists('dashboard_config', 'TEXT');
    // Add users table if it doesn't exist (for migration)
    try {
        database.run(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        first_name TEXT NOT NULL,
        last_name TEXT,
        password_hash TEXT NOT NULL,
        role TEXT DEFAULT 'user',
        assigned_stations TEXT,
        is_active INTEGER DEFAULT 1,
        last_login_at DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);
        dbLog.info('Users table migration complete');
    }
    catch (e) {
        // Table already exists
    }
    saveDatabase();
}
/**
 * Save database to disk
 */
function saveDatabase() {
    if (!db)
        return;
    const data = db.export();
    const buffer = Buffer.from(data);
    const dbPath = getDbPath();
    fs.writeFileSync(dbPath, buffer);
}
/**
 * Close database connection
 */
function closeDatabase() {
    if (db) {
        saveDatabase();
        db.close();
        db = null;
    }
}
/**
 * Get database instance
 */
function getDatabase() {
    return db;
}
function getAllStations() {
    if (!db)
        return [];
    const result = db.exec(`SELECT id, name, pakbus_address, connection_type, connection_config, security_code, 
    created_at, updated_at, last_connected, is_active, location, latitude, longitude, altitude, 
    datalogger_model, datalogger_serial_number, program_name, modem_model, modem_serial_number,
    site_description, notes, installation_team, station_admin, station_admin_email, station_admin_phone, station_image 
    FROM stations WHERE is_active = 1 ORDER BY name`);
    if (result.length === 0)
        return [];
    return result[0].values.map((row) => ({
        id: row[0],
        name: row[1],
        pakbus_address: row[2],
        connection_type: row[3],
        connection_config: row[4],
        security_code: row[5],
        created_at: row[6],
        updated_at: row[7],
        last_connected: row[8],
        is_active: row[9],
        location: row[10],
        latitude: row[11],
        longitude: row[12],
        altitude: row[13],
        datalogger_model: row[14],
        datalogger_serial_number: row[15],
        program_name: row[16],
        modem_model: row[17],
        modem_serial_number: row[18],
        site_description: row[19],
        notes: row[20],
        installation_team: row[21],
        station_admin: row[22],
        station_admin_email: row[23],
        station_admin_phone: row[24],
        station_image: row[25]
    }));
}
function getStationById(id) {
    if (!db)
        return null;
    const result = db.exec(`SELECT id, name, pakbus_address, connection_type, connection_config, security_code, 
    created_at, updated_at, last_connected, is_active, location, latitude, longitude, altitude, 
    datalogger_model, datalogger_serial_number, program_name, modem_model, modem_serial_number,
    site_description, notes, installation_team, station_admin, station_admin_email, station_admin_phone, station_image 
    FROM stations WHERE id = ?`, [id]);
    if (result.length === 0 || result[0].values.length === 0)
        return null;
    const row = result[0].values[0];
    return {
        id: row[0],
        name: row[1],
        pakbus_address: row[2],
        connection_type: row[3],
        connection_config: row[4],
        security_code: row[5],
        created_at: row[6],
        updated_at: row[7],
        last_connected: row[8],
        is_active: row[9],
        location: row[10],
        latitude: row[11],
        longitude: row[12],
        altitude: row[13],
        datalogger_model: row[14],
        datalogger_serial_number: row[15],
        program_name: row[16],
        modem_model: row[17],
        modem_serial_number: row[18],
        site_description: row[19],
        notes: row[20],
        installation_team: row[21],
        station_admin: row[22],
        station_admin_email: row[23],
        station_admin_phone: row[24],
        station_image: row[25]
    };
}
function createStation(station) {
    if (!db)
        throw new Error('Database not initialized');
    db.run(`INSERT INTO stations (name, pakbus_address, connection_type, connection_config, security_code, latitude, longitude, altitude, location) 
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`, [
        station.name,
        station.pakbus_address,
        station.connection_type,
        station.connection_config,
        station.security_code || null,
        station.latitude || null,
        station.longitude || null,
        station.altitude || null,
        station.location || null
    ]);
    const result = db.exec('SELECT last_insert_rowid()');
    const id = result[0].values[0][0];
    saveDatabase();
    return id;
}
function updateStation(id, station) {
    if (!db)
        throw new Error('Database not initialized');
    const fields = [];
    const values = [];
    if (station.name !== undefined) {
        fields.push('name = ?');
        values.push(station.name);
    }
    if (station.pakbus_address !== undefined) {
        fields.push('pakbus_address = ?');
        values.push(station.pakbus_address);
    }
    if (station.connection_type !== undefined) {
        fields.push('connection_type = ?');
        values.push(station.connection_type);
    }
    if (station.connection_config !== undefined) {
        fields.push('connection_config = ?');
        values.push(station.connection_config);
    }
    if (station.security_code !== undefined) {
        fields.push('security_code = ?');
        values.push(station.security_code);
    }
    if (station.last_connected !== undefined) {
        fields.push('last_connected = ?');
        values.push(station.last_connected);
    }
    // Location fields
    if (station.location !== undefined) {
        fields.push('location = ?');
        values.push(station.location);
    }
    if (station.latitude !== undefined) {
        fields.push('latitude = ?');
        values.push(station.latitude);
    }
    if (station.longitude !== undefined) {
        fields.push('longitude = ?');
        values.push(station.longitude);
    }
    if (station.altitude !== undefined) {
        fields.push('altitude = ?');
        values.push(station.altitude);
    }
    // Equipment fields
    if (station.datalogger_model !== undefined) {
        fields.push('datalogger_model = ?');
        values.push(station.datalogger_model);
    }
    if (station.datalogger_serial_number !== undefined) {
        fields.push('datalogger_serial_number = ?');
        values.push(station.datalogger_serial_number);
    }
    if (station.program_name !== undefined) {
        fields.push('program_name = ?');
        values.push(station.program_name);
    }
    if (station.modem_model !== undefined) {
        fields.push('modem_model = ?');
        values.push(station.modem_model);
    }
    if (station.modem_serial_number !== undefined) {
        fields.push('modem_serial_number = ?');
        values.push(station.modem_serial_number);
    }
    // Description fields
    if (station.site_description !== undefined) {
        fields.push('site_description = ?');
        values.push(station.site_description);
    }
    if (station.notes !== undefined) {
        fields.push('notes = ?');
        values.push(station.notes);
    }
    // Personnel fields
    if (station.installation_team !== undefined) {
        fields.push('installation_team = ?');
        values.push(station.installation_team);
    }
    if (station.station_admin !== undefined) {
        fields.push('station_admin = ?');
        values.push(station.station_admin);
    }
    if (station.station_admin_email !== undefined) {
        fields.push('station_admin_email = ?');
        values.push(station.station_admin_email);
    }
    if (station.station_admin_phone !== undefined) {
        fields.push('station_admin_phone = ?');
        values.push(station.station_admin_phone);
    }
    // Station image
    if (station.station_image !== undefined) {
        fields.push('station_image = ?');
        values.push(station.station_image);
    }
    fields.push('updated_at = CURRENT_TIMESTAMP');
    values.push(id);
    db.run(`UPDATE stations SET ${fields.join(', ')} WHERE id = ?`, values);
    saveDatabase();
}
function deleteStation(id) {
    if (!db)
        throw new Error('Database not initialized');
    db.run('UPDATE stations SET is_active = 0 WHERE id = ?', [id]);
    saveDatabase();
}
function insertWeatherData(records) {
    if (!db || records.length === 0)
        return;
    const stmt = db.prepare(`INSERT INTO weather_data (station_id, table_name, record_number, timestamp, data) 
     VALUES (?, ?, ?, ?, ?)`);
    for (const record of records) {
        stmt.run([record.station_id, record.table_name, record.record_number || null, record.timestamp, record.data]);
    }
    stmt.free();
    saveDatabase();
}
function getWeatherData(stationId, tableName, startTime, endTime, limit) {
    if (!db)
        return [];
    // Use subquery to get latest entry for each unique record_number to deduplicate
    // This handles cases where the same record was imported multiple times
    let query = `
    SELECT wd.* FROM weather_data wd
    INNER JOIN (
      SELECT record_number, MAX(collected_at) as max_collected
      FROM weather_data 
      WHERE station_id = ? AND table_name = ?
      ${startTime ? 'AND timestamp >= ?' : ''}
      ${endTime ? 'AND timestamp <= ?' : ''}
      GROUP BY record_number
    ) latest ON wd.record_number = latest.record_number AND wd.collected_at = latest.max_collected
    WHERE wd.station_id = ? AND wd.table_name = ?
  `;
    const params = [stationId, tableName];
    if (startTime) {
        params.push(startTime);
    }
    if (endTime) {
        params.push(endTime);
    }
    // Add the outer WHERE params
    params.push(stationId, tableName);
    if (startTime) {
        query += ' AND wd.timestamp >= ?';
        params.push(startTime);
    }
    if (endTime) {
        query += ' AND wd.timestamp <= ?';
        params.push(endTime);
    }
    query += ' ORDER BY wd.timestamp DESC';
    if (limit) {
        query += ' LIMIT ?';
        params.push(limit);
    }
    const result = db.exec(query, params);
    if (result.length === 0)
        return [];
    return result[0].values.map((row) => ({
        id: row[0],
        station_id: row[1],
        table_name: row[2],
        record_number: row[3],
        timestamp: row[4],
        data: row[5],
        collected_at: row[6]
    }));
}
function getLatestWeatherData(stationId, tableName) {
    const records = getWeatherData(stationId, tableName, undefined, undefined, 1);
    return records.length > 0 ? records[0] : null;
}
// 
function getSetting(key) {
    if (!db)
        return null;
    const result = db.exec('SELECT value FROM settings WHERE key = ?', [key]);
    if (result.length === 0 || result[0].values.length === 0)
        return null;
    return result[0].values[0][0];
}
function setSetting(key, value) {
    if (!db)
        throw new Error('Database not initialized');
    db.run('INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)', [key, value]);
    saveDatabase();
}
function getAllSettings() {
    if (!db)
        return {};
    const result = db.exec('SELECT key, value FROM settings');
    if (result.length === 0)
        return {};
    const settings = {};
    for (const row of result[0].values) {
        settings[row[0]] = row[1];
    }
    return settings;
}
function createAlert(alert) {
    if (!db)
        throw new Error('Database not initialized');
    db.run(`INSERT INTO alerts (station_id, type, severity, message) VALUES (?, ?, ?, ?)`, [alert.station_id || null, alert.type, alert.severity, alert.message]);
    const result = db.exec('SELECT last_insert_rowid()');
    const id = result[0].values[0][0];
    saveDatabase();
    return id;
}
function getActiveAlerts(stationId) {
    if (!db)
        return [];
    let query = 'SELECT * FROM alerts WHERE is_acknowledged = 0';
    const params = [];
    if (stationId !== undefined) {
        query += ' AND station_id = ?';
        params.push(stationId);
    }
    query += ' ORDER BY created_at DESC';
    const result = db.exec(query, params);
    if (result.length === 0)
        return [];
    return result[0].values.map((row) => ({
        id: row[0],
        station_id: row[1],
        type: row[2],
        severity: row[3],
        message: row[4],
        is_acknowledged: row[5],
        acknowledged_at: row[6],
        created_at: row[7]
    }));
}
function acknowledgeAlert(id) {
    if (!db)
        throw new Error('Database not initialized');
    db.run('UPDATE alerts SET is_acknowledged = 1, acknowledged_at = CURRENT_TIMESTAMP WHERE id = ?', [id]);
    saveDatabase();
}
function getAllOrganizations() {
    if (!db)
        return [];
    const result = db.exec('SELECT * FROM organizations ORDER BY created_at DESC');
    if (result.length === 0)
        return [];
    return result[0].values.map((row) => ({
        id: row[0],
        name: row[1],
        slug: row[2],
        description: row[3],
        owner_id: row[4],
        created_at: row[5],
        updated_at: row[6]
    }));
}
function getOrganizationById(id) {
    if (!db)
        return null;
    const result = db.exec('SELECT * FROM organizations WHERE id = ?', [id]);
    if (result.length === 0 || result[0].values.length === 0)
        return null;
    const row = result[0].values[0];
    return {
        id: row[0],
        name: row[1],
        slug: row[2],
        description: row[3],
        owner_id: row[4],
        created_at: row[5],
        updated_at: row[6]
    };
}
function createOrganization(name, description, ownerId = 'local-user') {
    if (!db)
        throw new Error('Database not initialized');
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    db.run(`INSERT INTO organizations (name, slug, description, owner_id) VALUES (?, ?, ?, ?)`, [name, slug, description || null, ownerId]);
    const result = db.exec('SELECT last_insert_rowid()');
    const id = result[0].values[0][0];
    saveDatabase();
    return id;
}
function updateOrganization(id, data) {
    if (!db)
        throw new Error('Database not initialized');
    const updates = [];
    const params = [];
    if (data.name !== undefined) {
        updates.push('name = ?');
        params.push(data.name);
        updates.push('slug = ?');
        params.push(data.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, ''));
    }
    if (data.description !== undefined) {
        updates.push('description = ?');
        params.push(data.description);
    }
    if (data.logoUrl !== undefined) {
        updates.push('logo_url = ?');
        params.push(data.logoUrl);
    }
    if (updates.length === 0)
        return;
    updates.push('updated_at = CURRENT_TIMESTAMP');
    params.push(id);
    db.run(`UPDATE organizations SET ${updates.join(', ')} WHERE id = ?`, params);
    saveDatabase();
}
function deleteOrganization(id) {
    if (!db)
        throw new Error('Database not initialized');
    db.run('DELETE FROM organizations WHERE id = ?', [id]);
    saveDatabase();
}
function getOrganizationMembers(orgId) {
    if (!db)
        return [];
    const result = db.exec('SELECT * FROM organization_members WHERE organization_id = ?', [orgId]);
    if (result.length === 0)
        return [];
    return result[0].values.map((row) => ({
        id: row[0],
        organization_id: row[1],
        user_id: row[2],
        role: row[3],
        created_at: row[4]
    }));
}
function addOrganizationMember(orgId, userId, role = 'member') {
    if (!db)
        throw new Error('Database not initialized');
    db.run('INSERT INTO organization_members (organization_id, user_id, role) VALUES (?, ?, ?)', [orgId, userId, role]);
    const result = db.exec('SELECT last_insert_rowid()');
    const id = result[0].values[0][0];
    saveDatabase();
    return id;
}
function updateMemberRole(orgId, userId, role) {
    if (!db)
        throw new Error('Database not initialized');
    db.run('UPDATE organization_members SET role = ? WHERE organization_id = ? AND user_id = ?', [role, orgId, userId]);
    saveDatabase();
}
function removeOrganizationMember(orgId, userId) {
    if (!db)
        throw new Error('Database not initialized');
    db.run('DELETE FROM organization_members WHERE organization_id = ? AND user_id = ?', [orgId, userId]);
    saveDatabase();
}
function getOrganizationInvitations(orgId) {
    if (!db)
        return [];
    const result = db.exec('SELECT * FROM organization_invitations WHERE organization_id = ?', [orgId]);
    if (result.length === 0)
        return [];
    return result[0].values.map((row) => ({
        id: row[0],
        organization_id: row[1],
        email: row[2],
        role: row[3],
        token: row[4],
        expires_at: row[5],
        created_at: row[6]
    }));
}
function createOrganizationInvitation(orgId, email, role = 'member') {
    if (!db)
        throw new Error('Database not initialized');
    // Generate a cryptographically secure token
    const crypto = require('crypto');
    const token = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(); // 7 days
    db.run('INSERT INTO organization_invitations (organization_id, email, role, token, expires_at) VALUES (?, ?, ?, ?, ?)', [orgId, email, role, token, expiresAt]);
    saveDatabase();
    return token;
}
function createShare(share) {
    if (!db)
        throw new Error('Database not initialized');
    db.run(`INSERT INTO shares (station_id, share_token, name, email, access_level, password, expires_at, is_active, access_count, created_by)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [
        share.station_id,
        share.share_token,
        share.name || 'Shared Dashboard',
        share.email || null,
        share.access_level || 'viewer',
        share.password || null,
        share.expires_at || null,
        share.is_active !== undefined ? share.is_active : 1,
        share.access_count || 0,
        share.created_by || 'admin'
    ]);
    saveDatabase();
    return share.share_token;
}
function getShareByToken(token) {
    if (!db)
        return null;
    const result = db.exec('SELECT * FROM shares WHERE share_token = ?', [token]);
    if (result.length === 0 || result[0].values.length === 0)
        return null;
    const row = result[0].values[0];
    return {
        id: row[0],
        station_id: row[1],
        share_token: row[2],
        name: row[3],
        email: row[4],
        access_level: row[5],
        password: row[6],
        expires_at: row[7],
        is_active: row[8],
        last_accessed_at: row[9],
        access_count: row[10],
        created_by: row[11],
        created_at: row[12],
        updated_at: row[13]
    };
}
function getSharesByStation(stationId) {
    if (!db)
        return [];
    const result = db.exec('SELECT * FROM shares WHERE station_id = ? ORDER BY created_at DESC', [stationId]);
    if (result.length === 0)
        return [];
    return result[0].values.map((row) => ({
        id: row[0],
        station_id: row[1],
        share_token: row[2],
        name: row[3],
        email: row[4],
        access_level: row[5],
        password: row[6],
        expires_at: row[7],
        is_active: row[8],
        last_accessed_at: row[9],
        access_count: row[10],
        created_by: row[11],
        created_at: row[12],
        updated_at: row[13]
    }));
}
function updateShare(token, updates) {
    if (!db)
        throw new Error('Database not initialized');
    const fields = [];
    const values = [];
    if (updates.name !== undefined) {
        fields.push('name = ?');
        values.push(updates.name);
    }
    if (updates.email !== undefined) {
        fields.push('email = ?');
        values.push(updates.email);
    }
    if (updates.access_level !== undefined) {
        fields.push('access_level = ?');
        values.push(updates.access_level);
    }
    if (updates.password !== undefined) {
        fields.push('password = ?');
        values.push(updates.password);
    }
    if (updates.expires_at !== undefined) {
        fields.push('expires_at = ?');
        values.push(updates.expires_at);
    }
    if (updates.is_active !== undefined) {
        fields.push('is_active = ?');
        values.push(updates.is_active);
    }
    if (updates.last_accessed_at !== undefined) {
        fields.push('last_accessed_at = ?');
        values.push(updates.last_accessed_at);
    }
    if (updates.access_count !== undefined) {
        fields.push('access_count = ?');
        values.push(updates.access_count);
    }
    if (fields.length === 0)
        return;
    fields.push('updated_at = CURRENT_TIMESTAMP');
    values.push(token);
    db.run(`UPDATE shares SET ${fields.join(', ')} WHERE share_token = ?`, values);
    saveDatabase();
}
function deleteShare(token) {
    if (!db)
        throw new Error('Database not initialized');
    db.run('DELETE FROM shares WHERE share_token = ?', [token]);
    saveDatabase();
}
function createAlarm(alarm) {
    if (!db)
        throw new Error('Database not initialized');
    dbLog.info(`Creating alarm for station ${alarm.station_id}, parameter: ${alarm.parameter}`);
    db.run(`INSERT INTO alarms (station_id, parameter, condition, threshold, severity, enabled, email_notifications, email_recipients)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`, [
        alarm.station_id,
        alarm.parameter,
        alarm.condition,
        alarm.threshold,
        alarm.severity || 'warning',
        alarm.enabled !== false ? 1 : 0,
        alarm.email_notifications ? 1 : 0,
        alarm.email_recipients || null
    ]);
    saveDatabase();
    const result = db.exec('SELECT last_insert_rowid()');
    return result[0]?.values[0]?.[0] || 0;
}
function getAlarmsByStation(stationId) {
    if (!db)
        return [];
    const result = db.exec('SELECT * FROM alarms WHERE station_id = ? ORDER BY created_at DESC', [stationId]);
    if (result.length === 0)
        return [];
    return result[0].values.map((row) => ({
        id: row[0],
        station_id: row[1],
        parameter: row[2],
        condition: row[3],
        threshold: row[4],
        severity: row[5],
        enabled: row[6] === 1,
        email_notifications: row[7] === 1,
        email_recipients: row[8],
        last_triggered_at: row[9],
        trigger_count: row[10],
        created_at: row[11],
        updated_at: row[12]
    }));
}
function getAllAlarms() {
    if (!db)
        return [];
    const result = db.exec('SELECT * FROM alarms ORDER BY created_at DESC');
    if (result.length === 0)
        return [];
    return result[0].values.map((row) => ({
        id: row[0],
        station_id: row[1],
        parameter: row[2],
        condition: row[3],
        threshold: row[4],
        severity: row[5],
        enabled: row[6] === 1,
        email_notifications: row[7] === 1,
        email_recipients: row[8],
        last_triggered_at: row[9],
        trigger_count: row[10],
        created_at: row[11],
        updated_at: row[12]
    }));
}
function getAlarmById(id) {
    if (!db)
        return null;
    const result = db.exec('SELECT * FROM alarms WHERE id = ?', [id]);
    if (result.length === 0 || result[0].values.length === 0)
        return null;
    const row = result[0].values[0];
    return {
        id: row[0],
        station_id: row[1],
        parameter: row[2],
        condition: row[3],
        threshold: row[4],
        severity: row[5],
        enabled: row[6] === 1,
        email_notifications: row[7] === 1,
        email_recipients: row[8],
        last_triggered_at: row[9],
        trigger_count: row[10],
        created_at: row[11],
        updated_at: row[12]
    };
}
function updateAlarm(id, updates) {
    if (!db)
        throw new Error('Database not initialized');
    const fields = [];
    const values = [];
    if (updates.parameter !== undefined) {
        fields.push('parameter = ?');
        values.push(updates.parameter);
    }
    if (updates.condition !== undefined) {
        fields.push('condition = ?');
        values.push(updates.condition);
    }
    if (updates.threshold !== undefined) {
        fields.push('threshold = ?');
        values.push(updates.threshold);
    }
    if (updates.severity !== undefined) {
        fields.push('severity = ?');
        values.push(updates.severity);
    }
    if (updates.enabled !== undefined) {
        fields.push('enabled = ?');
        values.push(updates.enabled ? 1 : 0);
    }
    if (updates.email_notifications !== undefined) {
        fields.push('email_notifications = ?');
        values.push(updates.email_notifications ? 1 : 0);
    }
    if (updates.email_recipients !== undefined) {
        fields.push('email_recipients = ?');
        values.push(updates.email_recipients);
    }
    if (updates.last_triggered_at !== undefined) {
        fields.push('last_triggered_at = ?');
        values.push(updates.last_triggered_at);
    }
    if (updates.trigger_count !== undefined) {
        fields.push('trigger_count = ?');
        values.push(updates.trigger_count);
    }
    if (fields.length === 0)
        return;
    fields.push('updated_at = CURRENT_TIMESTAMP');
    values.push(id);
    db.run(`UPDATE alarms SET ${fields.join(', ')} WHERE id = ?`, values);
    saveDatabase();
    dbLog.info(`Updated alarm ${id}`);
}
function deleteAlarm(id) {
    if (!db)
        throw new Error('Database not initialized');
    db.run('DELETE FROM alarms WHERE id = ?', [id]);
    saveDatabase();
    dbLog.info(`Deleted alarm ${id}`);
}
function triggerAlarm(alarmId, triggeredValue, message) {
    if (!db)
        throw new Error('Database not initialized');
    const alarm = getAlarmById(alarmId);
    if (!alarm)
        throw new Error(`Alarm ${alarmId} not found`);
    // Record the alarm event
    db.run(`INSERT INTO alarm_events (alarm_id, station_id, triggered_value, message)
     VALUES (?, ?, ?, ?)`, [alarmId, alarm.station_id, triggeredValue, message || null]);
    // Update alarm trigger info
    db.run(`UPDATE alarms SET last_triggered_at = CURRENT_TIMESTAMP, trigger_count = trigger_count + 1 WHERE id = ?`, [alarmId]);
    saveDatabase();
    const result = db.exec('SELECT last_insert_rowid()');
    const eventId = result[0]?.values[0]?.[0] || 0;
    dbLog.warn(`Alarm ${alarmId} triggered with value ${triggeredValue}`);
    return eventId;
}
function getAlarmEvents(alarmId, stationId, limit = 100) {
    if (!db)
        return [];
    let query = 'SELECT * FROM alarm_events';
    const conditions = [];
    const params = [];
    if (alarmId !== undefined) {
        conditions.push('alarm_id = ?');
        params.push(alarmId);
    }
    if (stationId !== undefined) {
        conditions.push('station_id = ?');
        params.push(stationId);
    }
    if (conditions.length > 0) {
        query += ' WHERE ' + conditions.join(' AND ');
    }
    query += ' ORDER BY created_at DESC LIMIT ?';
    params.push(limit);
    const result = db.exec(query, params);
    if (result.length === 0)
        return [];
    return result[0].values.map((row) => ({
        id: row[0],
        alarm_id: row[1],
        station_id: row[2],
        triggered_value: row[3],
        message: row[4],
        acknowledged: row[5] === 1,
        acknowledged_by: row[6],
        acknowledged_at: row[7],
        created_at: row[8]
    }));
}
function acknowledgeAlarmEvent(eventId, acknowledgedBy) {
    if (!db)
        throw new Error('Database not initialized');
    db.run(`UPDATE alarm_events SET acknowledged = 1, acknowledged_by = ?, acknowledged_at = CURRENT_TIMESTAMP WHERE id = ?`, [acknowledgedBy, eventId]);
    saveDatabase();
    dbLog.info(`Alarm event ${eventId} acknowledged by ${acknowledgedBy}`);
}
function deleteAlarmEvent(eventId) {
    if (!db)
        throw new Error('Database not initialized');
    db.run('DELETE FROM alarm_events WHERE id = ?', [eventId]);
    saveDatabase();
    dbLog.info(`Deleted alarm event ${eventId}`);
}
function cleanupOldAlarmEvents(daysToKeep = 30) {
    if (!db)
        throw new Error('Database not initialized');
    const cutoff = new Date(Date.now() - daysToKeep * 24 * 60 * 60 * 1000).toISOString();
    db.run('DELETE FROM alarm_events WHERE created_at < ?', [cutoff]);
    saveDatabase();
    const countResult = db.exec('SELECT changes() as cnt');
    const count = countResult.length > 0 && countResult[0].values.length > 0 ? countResult[0].values[0][0] : 0;
    if (count > 0)
        dbLog.info(`Cleaned up ${count} alarm events older than ${daysToKeep} days`);
    return count;
}
function getAllDropboxConfigs() {
    if (!db)
        throw new Error('Database not initialized');
    const query = 'SELECT id, name, folder_path, file_pattern, station_id, sync_interval, enabled, last_sync_at, last_sync_status, last_sync_records, created_at, updated_at FROM dropbox_configs ORDER BY created_at ASC';
    const result = db.exec(query);
    if (result.length === 0)
        return [];
    return result[0].values.map((row) => ({
        id: row[0],
        name: row[1],
        folder_path: row[2],
        file_pattern: row[3],
        station_id: row[4],
        sync_interval: row[5],
        enabled: row[6],
        last_sync_at: row[7],
        last_sync_status: row[8],
        last_sync_records: row[9],
        created_at: row[10],
        updated_at: row[11]
    }));
}
function getDropboxConfigById(id) {
    if (!db)
        throw new Error('Database not initialized');
    const query = 'SELECT id, name, folder_path, file_pattern, station_id, sync_interval, enabled, last_sync_at, last_sync_status, last_sync_records, created_at, updated_at FROM dropbox_configs WHERE id = ?';
    const result = db.exec(query, [id]);
    if (result.length === 0 || result[0].values.length === 0)
        return null;
    const row = result[0].values[0];
    return {
        id: row[0],
        name: row[1],
        folder_path: row[2],
        file_pattern: row[3],
        station_id: row[4],
        sync_interval: row[5],
        enabled: row[6],
        last_sync_at: row[7],
        last_sync_status: row[8],
        last_sync_records: row[9],
        created_at: row[10],
        updated_at: row[11]
    };
}
function createDropboxConfig(name, folderPath, filePattern, stationId, syncInterval, enabled) {
    if (!db)
        throw new Error('Database not initialized');
    db.run(`INSERT INTO dropbox_configs (name, folder_path, file_pattern, station_id, sync_interval, enabled) VALUES (?, ?, ?, ?, ?, ?)`, [name, folderPath, filePattern, stationId, syncInterval, enabled ? 1 : 0]);
    saveDatabase();
    // Get the last inserted ID
    const result = db.exec('SELECT last_insert_rowid()');
    return result[0].values[0][0];
}
function updateDropboxConfig(id, updates) {
    if (!db)
        throw new Error('Database not initialized');
    const setClauses = [];
    const values = [];
    if (updates.name !== undefined) {
        setClauses.push('name = ?');
        values.push(updates.name);
    }
    if (updates.folder_path !== undefined) {
        setClauses.push('folder_path = ?');
        values.push(updates.folder_path);
    }
    if (updates.file_pattern !== undefined) {
        setClauses.push('file_pattern = ?');
        values.push(updates.file_pattern);
    }
    if (updates.station_id !== undefined) {
        setClauses.push('station_id = ?');
        values.push(updates.station_id);
    }
    if (updates.sync_interval !== undefined) {
        setClauses.push('sync_interval = ?');
        values.push(updates.sync_interval);
    }
    if (updates.enabled !== undefined) {
        setClauses.push('enabled = ?');
        values.push(updates.enabled ? 1 : 0);
    }
    setClauses.push('updated_at = ?');
    values.push(new Date().toISOString());
    values.push(id);
    db.run(`UPDATE dropbox_configs SET ${setClauses.join(', ')} WHERE id = ?`, values);
    saveDatabase();
}
function updateDropboxSyncStatus(id, status, recordsImported) {
    if (!db)
        throw new Error('Database not initialized');
    db.run('UPDATE dropbox_configs SET last_sync_at = ?, last_sync_status = ?, last_sync_records = ?, updated_at = ? WHERE id = ?', [new Date().toISOString(), status, recordsImported, new Date().toISOString(), id]);
    saveDatabase();
}
function deleteDropboxConfig(id) {
    if (!db)
        throw new Error('Database not initialized');
    db.run('DELETE FROM dropbox_configs WHERE id = ?', [id]);
    saveDatabase();
}
function getAllActiveUsers() {
    if (!db)
        return [];
    const query = 'SELECT * FROM users WHERE is_active = 1 ORDER BY email';
    const result = db.exec(query);
    if (result.length === 0)
        return [];
    return result[0].values.map((row) => ({
        id: row[0],
        email: row[1],
        first_name: row[2],
        last_name: row[3],
        password_hash: row[4],
        role: row[5],
        assigned_stations: row[6],
        is_active: row[7],
        last_login_at: row[8],
        created_at: row[9],
        updated_at: row[10]
    }));
}
function getUserByEmail(email) {
    if (!db)
        return null;
    const query = 'SELECT * FROM users WHERE email = ? AND is_active = 1';
    const result = db.exec(query, [email.toLowerCase()]);
    if (result.length === 0 || result[0].values.length === 0)
        return null;
    const row = result[0].values[0];
    return {
        id: row[0],
        email: row[1],
        first_name: row[2],
        last_name: row[3],
        password_hash: row[4],
        role: row[5],
        assigned_stations: row[6],
        is_active: row[7],
        last_login_at: row[8],
        created_at: row[9],
        updated_at: row[10]
    };
}
function createUser(email, firstName, lastName, passwordHash, role = 'user', assignedStations = []) {
    if (!db)
        throw new Error('Database not initialized');
    const stationsJson = assignedStations.length > 0 ? JSON.stringify(assignedStations) : null;
    db.run(`INSERT INTO users (email, first_name, last_name, password_hash, role, assigned_stations) VALUES (?, ?, ?, ?, ?, ?)`, [email.toLowerCase(), firstName, lastName, passwordHash, role, stationsJson]);
    saveDatabase();
    const result = db.exec('SELECT last_insert_rowid()');
    return result[0].values[0][0];
}
function updateUser(email, updates) {
    if (!db)
        throw new Error('Database not initialized');
    const setClauses = [];
    const values = [];
    if (updates.first_name !== undefined) {
        setClauses.push('first_name = ?');
        values.push(updates.first_name);
    }
    if (updates.last_name !== undefined) {
        setClauses.push('last_name = ?');
        values.push(updates.last_name);
    }
    if (updates.password_hash !== undefined) {
        setClauses.push('password_hash = ?');
        values.push(updates.password_hash);
    }
    if (updates.role !== undefined) {
        setClauses.push('role = ?');
        values.push(updates.role);
    }
    if (updates.assigned_stations !== undefined) {
        setClauses.push('assigned_stations = ?');
        values.push(updates.assigned_stations.length > 0 ? JSON.stringify(updates.assigned_stations) : null);
    }
    if (setClauses.length === 0)
        return;
    setClauses.push('updated_at = CURRENT_TIMESTAMP');
    values.push(email.toLowerCase());
    db.run(`UPDATE users SET ${setClauses.join(', ')} WHERE email = ?`, values);
    saveDatabase();
}
function updateUserLastLogin(email) {
    if (!db)
        throw new Error('Database not initialized');
    db.run('UPDATE users SET last_login_at = CURRENT_TIMESTAMP WHERE email = ?', [email.toLowerCase()]);
    saveDatabase();
}
function deleteUser(email) {
    if (!db)
        throw new Error('Database not initialized');
    // Soft delete - set is_active to 0
    db.run('UPDATE users SET is_active = 0, updated_at = CURRENT_TIMESTAMP WHERE email = ?', [email.toLowerCase()]);
    saveDatabase();
}
// Export database module
exports.default = {
    initDatabase,
    saveDatabase,
    closeDatabase,
    getDatabase,
    getAllStations,
    getStationById,
    createStation,
    updateStation,
    deleteStation,
    insertWeatherData,
    getWeatherData,
    getLatestWeatherData,
    getSetting,
    setSetting,
    getAllSettings,
    createAlert,
    getActiveAlerts,
    acknowledgeAlert,
    getAllOrganizations,
    getOrganizationById,
    createOrganization,
    updateOrganization,
    deleteOrganization,
    getOrganizationMembers,
    addOrganizationMember,
    updateMemberRole,
    removeOrganizationMember,
    getOrganizationInvitations,
    createOrganizationInvitation,
    // Share functions
    createShare,
    getShareByToken,
    getSharesByStation,
    updateShare,
    deleteShare,
    // Alarm functions (Issue #10 fix)
    createAlarm,
    getAlarmById,
    getAlarmsByStation,
    getAllAlarms,
    updateAlarm,
    deleteAlarm,
    triggerAlarm,
    getAlarmEvents,
    acknowledgeAlarmEvent,
    deleteAlarmEvent,
    cleanupOldAlarmEvents,
    // Dropbox config functions
    getAllDropboxConfigs,
    getDropboxConfigById,
    createDropboxConfig,
    updateDropboxConfig,
    updateDropboxSyncStatus,
    deleteDropboxConfig,
    // User management functions
    getAllActiveUsers,
    getUserByEmail,
    createUser,
    updateUser,
    updateUserLastLogin,
    deleteUser,
};
