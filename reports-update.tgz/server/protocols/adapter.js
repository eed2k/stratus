"use strict";
// Stratus Weather Server
// Created by Lukas Esterhuizen
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseProtocolAdapter = void 0;
exports.createProtocolAdapter = createProtocolAdapter;
/**
 * Protocol Adapter Interface
 * Common interface for all communication protocols to integrate with the connection manager
 *
 * CLOUD DEPLOYMENT NOTE:
 * All adapters use TCP/IP based connections for cloud deployment.
 * Serial/RS232 connections are not available in cloud environments.
 */
const events_1 = require("events");
/**
 * Base class for protocol adapters with common functionality
 */
class BaseProtocolAdapter extends events_1.EventEmitter {
    constructor(config) {
        super();
        this.status = { connected: false };
        this.reconnectTimer = null;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 10;
        this.reconnectDelay = 5000;
        this.config = config;
    }
    isConnected() {
        return this.status.connected;
    }
    getStatus() {
        return { ...this.status };
    }
    setConnected(connected) {
        const wasConnected = this.status.connected;
        this.status.connected = connected;
        if (connected) {
            this.status.lastConnected = new Date();
            this.status.lastError = undefined;
            this.reconnectAttempts = 0;
            if (!wasConnected) {
                this.emit("connected");
                this.emit("status", this.status);
            }
        }
        else {
            if (wasConnected) {
                this.emit("disconnected");
                this.emit("status", this.status);
                this.scheduleReconnect();
            }
        }
    }
    setError(error) {
        this.status.lastError = error.message;
        this.emit("error", error);
        this.emit("status", this.status);
    }
    scheduleReconnect() {
        if (this.reconnectTimer)
            return;
        if (this.reconnectAttempts >= this.maxReconnectAttempts) {
            this.emit("error", new Error("Max reconnect attempts reached"));
            return;
        }
        const delay = Math.min(this.reconnectDelay * Math.pow(2, this.reconnectAttempts), 60000 // Max 1 minute
        );
        this.reconnectTimer = setTimeout(async () => {
            this.reconnectTimer = null;
            this.reconnectAttempts++;
            try {
                await this.connect();
            }
            catch (error) {
                // Will schedule another reconnect via setConnected(false)
            }
        }, delay);
    }
    cancelReconnect() {
        if (this.reconnectTimer) {
            clearTimeout(this.reconnectTimer);
            this.reconnectTimer = null;
        }
    }
    normalizeData(raw) {
        const result = {
            stationId: this.config.stationId,
            timestamp: new Date(),
            temperature: raw.temperature ?? null,
            humidity: raw.humidity != null ? Math.min(100, Math.max(0, raw.humidity)) : null,
            pressure: raw.pressure ?? null,
            windSpeed: raw.windSpeed ?? null,
            windDirection: raw.windDirection ?? null,
            windGust: raw.windGust ?? null,
            rainfall: raw.rainfall ?? null,
            solarRadiation: raw.solarRadiation ?? null,
            dewPoint: raw.dewPoint ?? null,
            batteryVoltage: raw.batteryVoltage ?? null,
        };
        // Pass through any extra fields (pm10, pm25, soilTemperature, uvIndex, etc.)
        for (const [key, value] of Object.entries(raw)) {
            if (!(key in result) && value !== null && value !== undefined) {
                result[key] = value;
            }
        }
        return result;
    }
}
exports.BaseProtocolAdapter = BaseProtocolAdapter;
/**
 * Factory function to create appropriate protocol adapter
 * Campbell Scientific stations use HTTP/TCP or LoRa
 */
function createProtocolAdapter(config) {
    switch (config.protocol) {
        case "lora":
            const { LoRaAdapter } = require("./loraAdapter");
            return new LoRaAdapter(config);
        case "http":
        case "pakbus":
        default:
            const { HTTPAdapter } = require("./httpAdapter");
            return new HTTPAdapter(config);
    }
}
