"use strict";
// Stratus Weather Server
// Created by Lukas Esterhuizen
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoRaAdapter = void 0;
/**
 * LoRa Protocol Adapter
 * Wraps LoRaProtocol with IProtocolAdapter interface
 */
const adapter_1 = require("./adapter");
const lora_1 = require("./lora");
class LoRaAdapter extends adapter_1.BaseProtocolAdapter {
    constructor(config) {
        super(config);
        this.lastData = null;
        const loraConfig = {
            mode: "lorawan", // Only LoRaWAN mode supported in cloud deployment
            networkServer: config.host || "eu1.cloud.thethings.network",
            applicationId: config.apiKey?.split(":")[0],
            applicationKey: config.apiKey?.split(":")[1],
            deviceEUI: config.deviceEUI,
        };
        this.protocol = new lora_1.LoRaProtocol(loraConfig);
        this.setupEventHandlers();
    }
    setupEventHandlers() {
        this.protocol.on("connected", () => {
            this.setConnected(true);
        });
        this.protocol.on("disconnected", () => {
            this.setConnected(false);
        });
        this.protocol.on("error", (error) => {
            this.setError(error);
        });
        this.protocol.on("data", (data) => {
            this.lastData = this.normalizeData(data);
            this.emit("data", this.lastData);
        });
        this.protocol.on("message", (msg) => {
            // Update signal strength from message metadata
            if (msg.rssi) {
                this.status.signalStrength = msg.rssi;
                this.emit("status", this.status);
            }
        });
    }
    async connect() {
        try {
            const result = await this.protocol.connect();
            this.setConnected(result);
            return result;
        }
        catch (error) {
            this.setError(error);
            return false;
        }
    }
    async disconnect() {
        this.cancelReconnect();
        await this.protocol.disconnect();
        this.setConnected(false);
    }
    async readData() {
        // LoRa is push-based, return last received data
        return this.lastData;
    }
}
exports.LoRaAdapter = LoRaAdapter;
