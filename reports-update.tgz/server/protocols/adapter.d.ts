/**
 * Protocol Adapter Interface
 * Common interface for all communication protocols to integrate with the connection manager
 *
 * CLOUD DEPLOYMENT NOTE:
 * All adapters use TCP/IP based connections for cloud deployment.
 * Serial/RS232 connections are not available in cloud environments.
 */
import { EventEmitter } from "events";
export interface ProtocolConfig {
    stationId: number;
    protocol: "pakbus" | "lora" | "http";
    connectionType: "tcp" | "http" | "lora";
    host?: string;
    port?: number;
    timeout?: number;
    gatewayHost?: string;
    gatewayPort?: number;
    pakbusAddress?: number;
    deviceEUI?: string;
    apiKey?: string;
    apiEndpoint?: string;
    securityCode?: number;
}
export interface NormalizedWeatherData {
    stationId: number;
    timestamp: Date;
    temperature?: number | null;
    humidity?: number | null;
    pressure?: number | null;
    windSpeed?: number | null;
    windDirection?: number | null;
    windGust?: number | null;
    rainfall?: number | null;
    solarRadiation?: number | null;
    dewPoint?: number | null;
    batteryVoltage?: number | null;
    [key: string]: number | null | Date | undefined;
}
export interface ConnectionStatus {
    connected: boolean;
    lastConnected?: Date;
    lastError?: string;
    signalStrength?: number;
    latency?: number;
}
export interface IProtocolAdapter extends EventEmitter {
    connect(): Promise<boolean>;
    disconnect(): Promise<void>;
    isConnected(): boolean;
    getStatus(): ConnectionStatus;
    readData(): Promise<NormalizedWeatherData | null>;
}
/**
 * Base class for protocol adapters with common functionality
 */
export declare abstract class BaseProtocolAdapter extends EventEmitter implements IProtocolAdapter {
    protected config: ProtocolConfig;
    protected status: ConnectionStatus;
    protected reconnectTimer: ReturnType<typeof setTimeout> | null;
    protected reconnectAttempts: number;
    protected maxReconnectAttempts: number;
    protected reconnectDelay: number;
    constructor(config: ProtocolConfig);
    abstract connect(): Promise<boolean>;
    abstract disconnect(): Promise<void>;
    abstract readData(): Promise<NormalizedWeatherData | null>;
    isConnected(): boolean;
    getStatus(): ConnectionStatus;
    protected setConnected(connected: boolean): void;
    protected setError(error: Error): void;
    protected scheduleReconnect(): void;
    protected cancelReconnect(): void;
    protected normalizeData(raw: Record<string, number | null>): NormalizedWeatherData;
}
/**
 * Factory function to create appropriate protocol adapter
 * Campbell Scientific stations use HTTP/TCP or LoRa
 */
export declare function createProtocolAdapter(config: ProtocolConfig): IProtocolAdapter;
