/**
 * HTTP Protocol Adapter
 * Fetches weather data from REST APIs, cloud services, and direct IP endpoints
 * Supports: CampbellCloud, WeatherLink Cloud, RikaCloud, Arduino IoT, Blynk, direct HTTP
 */
import { BaseProtocolAdapter, ProtocolConfig, NormalizedWeatherData } from "./adapter";
export declare class HTTPAdapter extends BaseProtocolAdapter {
    private httpClient;
    private serviceType;
    private rikaSession;
    private rikaFarmPk;
    private arduinoAccessToken;
    private arduinoTokenExpiry;
    constructor(config: ProtocolConfig);
    private detectServiceType;
    private buildHeaders;
    connect(): Promise<boolean>;
    disconnect(): Promise<void>;
    readData(): Promise<NormalizedWeatherData | null>;
    /**
     * Read data from RikaCloud v2 API.
     * Uses session token in header, auto re-logins on 403/HTML response.
     */
    private readRikaCloudData;
    /**
     * Login to RikaCloud v2 API.
     * POST {account, password} to /rika/api/v2/login/account/
     * Returns a session token used in the 'session' header for all subsequent requests.
     * Also discovers the farm_pk needed for data queries.
     */
    private rikaCloudLogin;
    /**
     * Arduino IoT Cloud: OAuth2 client_credentials token exchange.
     * POST to https://api2.arduino.cc/iot/v1/clients/token
     */
    private arduinoGetAccessToken;
    /**
     * Read data from Arduino IoT Cloud.
     * GET /iot/v2/things/{thingId}/properties to fetch all property values.
     */
    private readArduinoIoTData;
    private buildEndpointUrl;
    private extractDataFromResponse;
    private parseCampbellCloudResponse;
    private parseWeatherLinkResponse;
    private parseRikaCloudResponse;
    private parseArduinoIoTResponse;
    private parseBlynkResponse;
    private parseThingSpeakResponse;
    private parseGenericResponse;
    private fahrenheitToCelsius;
}
