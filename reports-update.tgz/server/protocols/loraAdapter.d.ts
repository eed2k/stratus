/**
 * LoRa Protocol Adapter
 * Wraps LoRaProtocol with IProtocolAdapter interface
 */
import { BaseProtocolAdapter, ProtocolConfig, NormalizedWeatherData } from "./adapter";
export declare class LoRaAdapter extends BaseProtocolAdapter {
    private protocol;
    private lastData;
    constructor(config: ProtocolConfig);
    private setupEventHandlers;
    connect(): Promise<boolean>;
    disconnect(): Promise<void>;
    readData(): Promise<NormalizedWeatherData | null>;
}
