/**
 * Protocol Manager
 * Central orchestration layer for all protocol adapters
 * Manages connection lifecycle, polling, and data collection
 */
import { EventEmitter } from "events";
import { IProtocolAdapter, ProtocolConfig, NormalizedWeatherData, ConnectionStatus } from "./adapter";
export interface ManagedStation {
    stationId: number;
    adapter: IProtocolAdapter | null;
    config: ProtocolConfig;
    pollInterval: number;
    pollTimer: ReturnType<typeof setInterval> | null;
    isSimulation: boolean;
    lastData: NormalizedWeatherData | null;
}
export interface ProtocolManagerConfig {
    defaultPollInterval: number;
    enableSimulation: boolean;
}
declare class ProtocolManagerClass extends EventEmitter {
    private stations;
    private config;
    private initialized;
    constructor();
    initialize(): Promise<void>;
    private buildConfigFromStation;
    private mapProtocol;
    private mapConnectionType;
    registerStation(stationId: number, config: ProtocolConfig): Promise<void>;
    /**
     * Determine the appropriate poll interval for a station based on its type.
     * Rika Cloud API stations update every 30 minutes as standard.
     * Other API-based stations use the default 1-minute interval.
     */
    private getStationPollInterval;
    unregisterStation(stationId: number): Promise<void>;
    private requiresSimulation;
    private createAdapter;
    private setupAdapterEvents;
    private startPolling;
    private stopPolling;
    private pollStation;
    private handleIncomingData;
    getStationStatus(stationId: number): ConnectionStatus | null;
    getAllStationStatuses(): Map<number, ConnectionStatus>;
    testConnection(stationId: number): Promise<{
        success: boolean;
        message: string;
        isSimulation?: boolean;
    }>;
    getRegisteredStations(): number[];
    shutdown(): Promise<void>;
}
export declare const protocolManager: ProtocolManagerClass;
export {};
