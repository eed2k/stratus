/**
 * LoRa/LoRaWAN Protocol Implementation
 * Long Range, Low Power wireless communication for IoT weather stations
 *
 * CLOUD DEPLOYMENT NOTE:
 * This implementation connects to LoRaWAN network servers via MQTT over TCP/IP.
 * P2P mode is NOT supported in cloud deployment as it requires direct serial
 * connection to a local LoRa radio module.
 *
 * Supported modes:
 * - LoRaWAN: Connect to TTN, ChirpStack, or other network servers via MQTT
 */
import { EventEmitter } from "events";
export interface LoRaConfig {
    mode: "lorawan" | "lora-p2p";
    networkServer?: string;
    applicationId?: string;
    applicationKey?: string;
    deviceEUI?: string;
    appEUI?: string;
    appKey?: string;
    frequency?: number;
    spreadingFactor?: number;
    bandwidth?: number;
    codingRate?: string;
}
export interface LoRaMessage {
    deviceEUI: string;
    timestamp: Date;
    rssi: number;
    snr: number;
    port: number;
    payload: Buffer;
    decoded?: Record<string, number>;
}
export declare class LoRaProtocol extends EventEmitter {
    private config;
    private connected;
    private websocket;
    private mqttClient;
    constructor(config: LoRaConfig);
    connect(): Promise<boolean>;
    private connectLoRaWAN;
    private connectP2P;
    private handleLoRaWANMessage;
    handleSerialData(data: Buffer): void;
    private decodePayload;
    sendDownlink(deviceEUI: string, payload: Buffer, port?: number): Promise<boolean>;
    disconnect(): Promise<void>;
    isConnected(): boolean;
    getRadioConfig(): Record<string, any>;
}
export declare const LORA_FREQUENCY_PLANS: {
    EU868: {
        name: string;
        frequencies: number[];
        defaultFrequency: number;
    };
    US915: {
        name: string;
        frequencies: number[];
        defaultFrequency: number;
    };
    AU915: {
        name: string;
        frequencies: number[];
        defaultFrequency: number;
    };
    AS923: {
        name: string;
        frequencies: number[];
        defaultFrequency: number;
    };
};
