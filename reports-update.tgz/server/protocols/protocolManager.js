"use strict";
// Stratus Weather Server
// Created by Lukas Esterhuizen
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.protocolManager = void 0;
/**
 * Protocol Manager
 * Central orchestration layer for all protocol adapters
 * Manages connection lifecycle, polling, and data collection
 */
const events_1 = require("events");
const localStorage_1 = require("../localStorage");
class ProtocolManagerClass extends events_1.EventEmitter {
    constructor() {
        super();
        this.stations = new Map();
        this.initialized = false;
        this.config = {
            defaultPollInterval: 60000,
            enableSimulation: true,
        };
    }
    async initialize() {
        if (this.initialized)
            return;
        console.log("[ProtocolManager] Initializing...");
        try {
            const stations = await localStorage_1.storage.getStations();
            for (const station of stations) {
                // Skip demo stations and stations without valid connection config
                if (station.connectionType === 'demo')
                    continue;
                if (!station.isActive)
                    continue;
                // Skip stations that don't have a valid endpoint (import-only stations)
                const hasValidEndpoint = station.ipAddress || station.apiEndpoint ||
                    (station.connectionConfig && (station.connectionConfig.host || station.connectionConfig.apiEndpoint || station.connectionConfig.broker));
                if (!hasValidEndpoint) {
                    console.log(`[ProtocolManager] Skipping station ${station.id} (${station.name}) - no endpoint configured (import-only)`);
                    continue;
                }
                await this.registerStation(station.id, this.buildConfigFromStation(station));
            }
            this.initialized = true;
            console.log(`[ProtocolManager] Initialized with ${this.stations.size} stations`);
        }
        catch (error) {
            console.error("[ProtocolManager] Initialization error:", error);
        }
    }
    buildConfigFromStation(station) {
        if (!station) {
            console.warn(`[ProtocolManager] buildConfigFromStation called with undefined station`);
            return {
                stationId: 0,
                protocol: 'http',
                connectionType: 'http',
                timeout: 30000,
            };
        }
        let connectionConfig = {};
        if (station.connectionConfig) {
            try {
                connectionConfig = typeof station.connectionConfig === 'string'
                    ? JSON.parse(station.connectionConfig)
                    : station.connectionConfig;
            }
            catch (e) {
                console.warn(`[ProtocolManager] Invalid connectionConfig for station ${station.id}`);
                connectionConfig = {};
            }
        }
        return {
            stationId: station.id,
            protocol: this.mapProtocol(station.connectionType, station.stationType),
            connectionType: this.mapConnectionType(station.connectionType),
            host: station.ipAddress || connectionConfig.broker,
            port: station.port || connectionConfig.port,
            serialPort: station.serialPort,
            baudRate: station.baudRate,
            timeout: 30000,
            apiKey: station.apiKey,
            apiEndpoint: station.apiEndpoint || connectionConfig.topic,
            ...connectionConfig,
        };
    }
    mapProtocol(connectionType, stationType) {
        // Campbell Scientific stations use PakBus protocol via HTTP/TCP or LoRa
        const mappings = {
            'http': 'http',
            'ip': 'http',
            'wifi': 'http',
            'lora': 'lora',
            'tcp': 'http',
            '4g': 'http',
            'pakbus': 'pakbus',
            'campbellcloud': 'http',
        };
        return mappings[connectionType] || 'http';
    }
    mapConnectionType(connectionType) {
        // All Campbell connections are TCP/IP based (4G, WiFi, etc.) or LoRa
        const mappings = {
            'http': 'http',
            'ip': 'http',
            'wifi': 'http',
            'lora': 'lora',
            'tcp': 'tcp',
            '4g': 'http',
        };
        return mappings[connectionType] || 'http';
    }
    async registerStation(stationId, config) {
        if (this.stations.has(stationId)) {
            await this.unregisterStation(stationId);
        }
        const isSimulation = this.requiresSimulation(config);
        const adapter = await this.createAdapter(config, isSimulation);
        const managedStation = {
            stationId,
            adapter,
            config,
            pollInterval: this.getStationPollInterval(config),
            pollTimer: null,
            isSimulation,
            lastData: null,
        };
        this.stations.set(stationId, managedStation);
        if (adapter) {
            this.setupAdapterEvents(managedStation);
            await this.startPolling(stationId);
        }
        console.log(`[ProtocolManager] Registered station ${stationId} (simulation: ${isSimulation})`);
    }
    /**
     * Determine the appropriate poll interval for a station based on its type.
     * Rika Cloud API stations update every 30 minutes as standard.
     * Other API-based stations use the default 1-minute interval.
     */
    getStationPollInterval(config) {
        const endpoint = config.apiEndpoint?.toLowerCase() || '';
        const host = config.host?.toLowerCase() || '';
        // Rika Cloud API: 30-minute standard poll interval
        if (endpoint.includes('rika') || host.includes('rika')) {
            return 1800000; // 30 minutes
        }
        return this.config.defaultPollInterval;
    }
    async unregisterStation(stationId) {
        const station = this.stations.get(stationId);
        if (!station)
            return;
        this.stopPolling(stationId);
        if (station.adapter) {
            await station.adapter.disconnect();
        }
        this.stations.delete(stationId);
        console.log(`[ProtocolManager] Unregistered station ${stationId}`);
    }
    requiresSimulation(config) {
        // No hardware protocols require simulation in cloud deployment
        return false;
    }
    async createAdapter(config, isSimulation) {
        try {
            // Campbell Scientific setups use HTTP/TCP for 4G/cellular and LoRa for remote
            switch (config.connectionType) {
                case 'http':
                    const { HTTPAdapter } = await Promise.resolve().then(() => __importStar(require("./httpAdapter")));
                    return new HTTPAdapter(config);
                case 'lora':
                    const { LoRaAdapter } = await Promise.resolve().then(() => __importStar(require("./loraAdapter")));
                    return new LoRaAdapter(config);
                case 'tcp':
                    // TCP connections use HTTP adapter for Campbell stations
                    const { HTTPAdapter: TCPAdapter } = await Promise.resolve().then(() => __importStar(require("./httpAdapter")));
                    return new TCPAdapter(config);
                default:
                    const { HTTPAdapter: DefaultAdapter } = await Promise.resolve().then(() => __importStar(require("./httpAdapter")));
                    return new DefaultAdapter(config);
            }
        }
        catch (error) {
            console.error(`[ProtocolManager] Failed to create adapter for station ${config.stationId}:`, error);
            return null;
        }
    }
    setupAdapterEvents(station) {
        if (!station.adapter)
            return;
        station.adapter.on('connected', () => {
            console.log(`[ProtocolManager] Station ${station.stationId} connected`);
            this.emit('stationConnected', station.stationId);
        });
        station.adapter.on('disconnected', () => {
            console.log(`[ProtocolManager] Station ${station.stationId} disconnected`);
            this.emit('stationDisconnected', station.stationId);
        });
        station.adapter.on('data', (data) => {
            station.lastData = data;
            this.handleIncomingData(station.stationId, data);
        });
        station.adapter.on('error', (error) => {
            console.error(`[ProtocolManager] Station ${station.stationId} error:`, error.message);
            this.emit('stationError', station.stationId, error);
        });
    }
    async startPolling(stationId) {
        const station = this.stations.get(stationId);
        if (!station || !station.adapter)
            return;
        try {
            const connected = await station.adapter.connect();
            if (!connected) {
                console.warn(`[ProtocolManager] Failed initial connection for station ${stationId}`);
            }
        }
        catch (error) {
            console.error(`[ProtocolManager] Connection error for station ${stationId}:`, error);
        }
        station.pollTimer = setInterval(async () => {
            await this.pollStation(stationId);
        }, station.pollInterval);
        await this.pollStation(stationId);
    }
    stopPolling(stationId) {
        const station = this.stations.get(stationId);
        if (station?.pollTimer) {
            clearInterval(station.pollTimer);
            station.pollTimer = null;
        }
    }
    async pollStation(stationId) {
        const station = this.stations.get(stationId);
        if (!station?.adapter)
            return;
        try {
            const data = await station.adapter.readData();
            if (data) {
                station.lastData = data;
                await this.handleIncomingData(stationId, data);
            }
        }
        catch (error) {
            console.error(`[ProtocolManager] Poll error for station ${stationId}:`, error);
        }
    }
    async handleIncomingData(stationId, data) {
        try {
            // Build data object dynamically — include all non-null fields
            const weatherFields = {};
            for (const [key, value] of Object.entries(data)) {
                // Skip metadata fields, only include weather measurements
                if (key === 'stationId' || key === 'timestamp')
                    continue;
                if (value !== null && value !== undefined) {
                    weatherFields[key] = value;
                }
            }
            await localStorage_1.storage.insertWeatherData({
                stationId,
                timestamp: data.timestamp,
                tableName: 'weather',
                data: weatherFields
            });
            this.emit('dataReceived', stationId, data);
        }
        catch (error) {
            console.error(`[ProtocolManager] Failed to store data for station ${stationId}:`, error);
        }
    }
    getStationStatus(stationId) {
        const station = this.stations.get(stationId);
        if (!station?.adapter) {
            return { connected: false, lastError: 'No adapter configured' };
        }
        const status = station.adapter.getStatus();
        return { ...status, isSimulation: station.isSimulation };
    }
    getAllStationStatuses() {
        const statuses = new Map();
        for (const [id, station] of this.stations) {
            statuses.set(id, this.getStationStatus(id) || { connected: false });
        }
        return statuses;
    }
    async testConnection(stationId) {
        const station = this.stations.get(stationId);
        if (!station) {
            return { success: false, message: 'Station not registered' };
        }
        if (!station.adapter) {
            return { success: false, message: 'No adapter configured' };
        }
        try {
            const connected = await station.adapter.connect();
            if (connected) {
                const data = await station.adapter.readData();
                return {
                    success: true,
                    message: data ? 'Connected and received data' : 'Connected but no data available',
                    isSimulation: station.isSimulation
                };
            }
            return { success: false, message: 'Connection failed' };
        }
        catch (error) {
            return { success: false, message: error.message };
        }
    }
    getRegisteredStations() {
        return Array.from(this.stations.keys());
    }
    async shutdown() {
        console.log("[ProtocolManager] Shutting down...");
        for (const stationId of this.stations.keys()) {
            await this.unregisterStation(stationId);
        }
        this.initialized = false;
        console.log("[ProtocolManager] Shutdown complete");
    }
}
exports.protocolManager = new ProtocolManagerClass();
