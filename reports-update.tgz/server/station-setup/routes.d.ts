/**
 * Station Setup Routes
 * Handles all station setup and configuration endpoints for different protocols
 */
import type { Express } from "express";
export declare function registerStationSetupRoutes(app: Express): Promise<void>;
