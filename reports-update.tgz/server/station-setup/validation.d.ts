/**
 * Station Setup Validation
 * Validates connection configurations for all protocol types
 */
import { ProtocolConfig } from "../protocols/adapter";
export interface ValidationResult {
    valid: boolean;
    errors: string[];
    warnings?: string[];
}
export declare function validateHTTPConfig(config: any): ValidationResult;
export declare function validateMQTTConfig(config: any): ValidationResult;
export declare function validateLoRaConfig(config: any): ValidationResult;
export declare function validateSatelliteConfig(config: any): ValidationResult;
export declare function validateModbusConfig(config: any): ValidationResult;
export declare function validateDNP3Config(config: any): ValidationResult;
export declare function validateBLEConfig(config: any): ValidationResult;
export declare function validateGSMConfig(config: any): ValidationResult;
export declare function validateConnectionConfig(connectionType: string, config: any): ValidationResult;
export declare function buildProtocolConfig(stationId: number, connectionType: string, config: any): ProtocolConfig;
