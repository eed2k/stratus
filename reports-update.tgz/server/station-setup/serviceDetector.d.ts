/**
 * Service Type Detection & Auto-Configuration
 * For Campbell Scientific dataloggers
 */
export interface ServiceDetectionResult {
    provider: string;
    confidence: number;
    connectionType: string;
    suggestedConfig?: Record<string, any>;
    apiEndpoint?: string;
}
export declare class ServiceDetector {
    /**
     * Detect service provider from API endpoint or host
     * Focused on Campbell Scientific connections
     */
    static detectFromEndpoint(endpoint: string): ServiceDetectionResult | null;
    /**
     * Detect from API response structure
     * Looks for Campbell Scientific data patterns
     */
    static detectFromResponse(response: any): ServiceDetectionResult | null;
    /**
     * Test connection to a Campbell Scientific datalogger
     */
    static testConnection(connectionType: string, config: Record<string, any>, timeout?: number): Promise<{
        success: boolean;
        message?: string;
        error?: string;
    }>;
    /**
     * Test HTTP endpoint connectivity
     */
    static testEndpoint(url: string, apiKey?: string, timeout?: number): Promise<{
        success: boolean;
        error?: string;
    }>;
    /**
     * Get provider-specific configuration template
     * For Campbell Scientific connections (cloud deployment - TCP/IP only)
     */
    private static getProviderConfig;
    /**
     * Configure Campbell Scientific connection via PakBus
     */
    static configureCampbellConnection(connectionType: string, config: Record<string, any>): Promise<{
        success: boolean;
        message?: string;
        error?: string;
    }>;
}
