"use strict";
// Stratus Weather Server
// Created by Lukas Esterhuizen
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateHTTPConfig = validateHTTPConfig;
exports.validateMQTTConfig = validateMQTTConfig;
exports.validateLoRaConfig = validateLoRaConfig;
exports.validateSatelliteConfig = validateSatelliteConfig;
exports.validateModbusConfig = validateModbusConfig;
exports.validateDNP3Config = validateDNP3Config;
exports.validateBLEConfig = validateBLEConfig;
exports.validateGSMConfig = validateGSMConfig;
exports.validateConnectionConfig = validateConnectionConfig;
exports.buildProtocolConfig = buildProtocolConfig;
function validateHTTPConfig(config) {
    const errors = [];
    const warnings = [];
    if (!config.apiEndpoint && !config.host) {
        errors.push("Either apiEndpoint or host is required for HTTP connection");
    }
    if (!config.apiKey && config.apiEndpoint?.includes("cloud")) {
        warnings.push("API Key recommended for cloud endpoints");
    }
    if (config.port && (config.port < 1 || config.port > 65535)) {
        errors.push("Port must be between 1 and 65535");
    }
    return {
        valid: errors.length === 0,
        errors,
        warnings,
    };
}
function validateMQTTConfig(config) {
    const errors = [];
    const warnings = [];
    if (!config.broker && !config.host) {
        errors.push("[MQTT] Broker address is required for MQTT connection");
    }
    if (!config.topic && !config.apiEndpoint) {
        errors.push("[MQTT] Topic is required for MQTT subscription");
    }
    if (config.port && (config.port < 1 || config.port > 65535)) {
        errors.push("[MQTT] Port must be between 1 and 65535");
    }
    if (config.port && ![1883, 8883, 8084, 8085].includes(config.port)) {
        warnings.push(`[MQTT] Non-standard MQTT port ${config.port} detected`);
    }
    return {
        valid: errors.length === 0,
        errors,
        warnings,
    };
}
function validateLoRaConfig(config) {
    const errors = [];
    const warnings = [];
    if (!config.deviceEUI) {
        errors.push("[LoRa] Device EUI is required for LoRa connection");
    }
    else if (!/^[0-9A-Fa-f]{16}$/.test(config.deviceEUI)) {
        errors.push("[LoRa] Device EUI must be a valid 16-character hex string");
    }
    if (!config.appEUI) {
        warnings.push("[LoRa] App EUI recommended for LoRa configuration");
    }
    if (!config.apiKey) {
        warnings.push("API Key recommended for LoRa cloud integration");
    }
    return {
        valid: errors.length === 0,
        errors,
        warnings,
    };
}
function validateSatelliteConfig(config) {
    const errors = [];
    const warnings = [];
    if (!config.imei && !config.deviceId) {
        errors.push("IMEI or Device ID is required for satellite connection");
    }
    if (!config.apiKey) {
        warnings.push("API Key recommended for satellite integration");
    }
    if (!config.apiEndpoint) {
        warnings.push("API Endpoint recommended for satellite cloud service");
    }
    return {
        valid: errors.length === 0,
        errors,
        warnings,
    };
}
function validateModbusConfig(config) {
    const errors = [];
    const warnings = [];
    // Cloud deployment: Modbus via TCP/IP only
    if (!config.host) {
        errors.push("IP address/host is required for Modbus TCP connection");
    }
    if (!config.port) {
        warnings.push("Modbus port not specified, using default (502)");
    }
    if (config.slaveId && (config.slaveId < 1 || config.slaveId > 247)) {
        errors.push("Modbus Slave ID must be between 1 and 247");
    }
    return {
        valid: errors.length === 0,
        errors,
        warnings,
    };
}
function validateDNP3Config(config) {
    const errors = [];
    const warnings = [];
    if (!config.host) {
        errors.push("Host address is required for DNP3 connection");
    }
    if (!config.port) {
        errors.push("Port is required for DNP3 connection");
    }
    if (config.masterAddress === undefined) {
        errors.push("Master Address is required for DNP3");
    }
    if (config.outstationAddress === undefined) {
        errors.push("Outstation Address is required for DNP3");
    }
    return {
        valid: errors.length === 0,
        errors,
        warnings,
    };
}
function validateBLEConfig(config) {
    const errors = [];
    const warnings = [];
    if (!config.deviceAddress && !config.deviceId) {
        errors.push("Device Address or Device ID is required for BLE connection");
    }
    if (config.deviceAddress && !/^([0-9A-Fa-f]{2}:){5}([0-9A-Fa-f]{2})$/.test(config.deviceAddress)) {
        errors.push("Invalid BLE device address format (should be XX:XX:XX:XX:XX:XX)");
    }
    return {
        valid: errors.length === 0,
        errors,
        warnings,
    };
}
function validateGSMConfig(config) {
    const errors = [];
    const warnings = [];
    // Cloud deployment: GSM via TCP gateway only
    if (!config.host && !config.gatewayHost) {
        errors.push("Gateway host is required for GSM/cellular connection in cloud deployment");
    }
    if (!config.apiEndpoint && !config.gatewayPort) {
        warnings.push("API endpoint or gateway port recommended for GSM configuration");
    }
    return {
        valid: errors.length === 0,
        errors,
        warnings,
    };
}
function validateConnectionConfig(connectionType, config) {
    const typeMap = {
        http: validateHTTPConfig,
        ip: validateHTTPConfig,
        wifi: validateHTTPConfig,
        tcp: validateHTTPConfig,
        tcp_ip: validateHTTPConfig,
        http_post: (c) => ({ valid: true, errors: [] }), // HTTP POST is station-initiated, no validation needed
        dropbox: (c) => ({ valid: true, errors: [] }), // Dropbox sync is handled by external service
        import: (c) => ({ valid: true, errors: [] }), // File import doesn't need validation
        demo: (c) => ({ valid: true, errors: [] }), // Demo mode doesn't need validation
        mqtt: validateMQTTConfig,
        lora: validateLoRaConfig,
        satellite: validateSatelliteConfig,
        modbus: validateModbusConfig,
        dnp3: validateDNP3Config,
        ble: validateBLEConfig,
        gsm: validateGSMConfig,
        "4g": validateGSMConfig,
        pakbus: validateHTTPConfig,
        arduino_iot: validateHTTPConfig,
        rikacloud: validateHTTPConfig,
    };
    const validator = typeMap[connectionType.toLowerCase()];
    if (!validator) {
        // Return valid for unknown types - allow user to configure custom protocols
        console.warn(`Unknown connection type: ${connectionType}, allowing configuration`);
        return {
            valid: true,
            errors: [],
            warnings: [`Connection type "${connectionType}" is not a recognized type`],
        };
    }
    return validator(config);
}
function buildProtocolConfig(stationId, connectionType, config) {
    // Map connection types to protocol adapters
    // Campbell Scientific stations use PakBus via HTTP/TCP or LoRa
    const protocolMap = {
        http: "http",
        ip: "http",
        wifi: "http",
        tcp: "http",
        tcp_ip: "http",
        http_post: "http",
        dropbox: "http", // Dropbox sync uses HTTP internally
        lora: "lora",
        pakbus: "pakbus",
        gsm: "http",
        "4g": "http",
        mqtt: "mqtt",
        satellite: "satellite",
        modbus: "modbus",
        dnp3: "dnp3",
        demo: "http",
        rikacloud: "http",
        arduino_iot: "http",
    };
    const connectionTypeMap = {
        http: "http",
        ip: "http",
        wifi: "http",
        tcp: "tcp",
        tcp_ip: "tcp",
        http_post: "http",
        dropbox: "http",
        lora: "lora",
        gsm: "http",
        "4g": "http",
        mqtt: "mqtt",
        satellite: "satellite",
        modbus: "modbus",
        dnp3: "dnp3",
        demo: "http",
        rikacloud: "http",
        arduino_iot: "http",
    };
    return {
        stationId,
        protocol: protocolMap[connectionType] || "http",
        connectionType: connectionTypeMap[connectionType] || "http",
        ...config,
    };
}
