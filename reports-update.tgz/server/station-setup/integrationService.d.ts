export interface StationSetupPayload {
    name: string;
    description?: string;
    stationType: string;
    connectionType: string;
    ipAddress?: string;
    port?: number;
    gatewayHost?: string;
    gatewayPort?: number;
    apiKey?: string;
    apiEndpoint?: string;
    connectionConfig?: Record<string, any>;
    location?: string;
    isActive?: boolean;
}
export interface SetupResult {
    success: boolean;
    stationId?: number;
    message: string;
    errors?: string[];
}
export declare class StationIntegrationService {
    /**
     * Complete station setup workflow
     */
    static setupStation(payload: StationSetupPayload): Promise<SetupResult>;
    /**
     * Test connection without creating station
     */
    static testStationConnection(payload: Partial<StationSetupPayload>): Promise<{
        success: boolean;
        error?: string;
    }>;
    /**
     * Fetch stations from Campbell Cloud (not yet implemented)
     */
    static fetchCampbellStations(apiKey: string, organizationUid?: string, locationUid?: string): Promise<Array<{
        id: string;
        name: string;
        model: string;
    }>>;
    /**
     * Setup multiple stations from provider
     */
    static setupMultipleStations(provider: string, apiKey: string, basePayload: Partial<StationSetupPayload>): Promise<SetupResult[]>;
    /**
     * Update station connection
     */
    static updateStationConnection(stationId: number, payload: Partial<StationSetupPayload>): Promise<SetupResult>;
}
