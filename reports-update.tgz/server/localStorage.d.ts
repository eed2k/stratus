export interface WeatherStation {
    id: number;
    name: string;
    pakbusAddress: number;
    connectionType: string;
    connectionConfig: any;
    securityCode?: number;
    createdAt: Date;
    updatedAt: Date;
    lastConnected?: Date;
    isActive: boolean;
    stationType?: string;
    ipAddress?: string;
    port?: number;
    serialPort?: string;
    baudRate?: number;
    protocol?: string;
    dataTable?: string;
    pollInterval?: number;
    apiKey?: string;
    apiEndpoint?: string;
    description?: string;
    location?: string;
    provider?: string;
    latitude?: number;
    longitude?: number;
    altitude?: number;
    dataloggerModel?: string;
    dataloggerSerialNumber?: string;
    programName?: string;
    dataloggerProgramName?: string;
    modemModel?: string;
    modemSerialNumber?: string;
    siteDescription?: string;
    notes?: string;
    installationTeam?: string;
    stationAdmin?: string;
    stationAdminEmail?: string;
    stationAdminPhone?: string;
    stationImage?: string | null;
    ingestId?: string | null;
    windSpeedUnit?: string | null;
}
export interface WeatherData {
    id: number;
    stationId: number;
    tableName: string;
    recordNumber?: number;
    timestamp: Date;
    data?: Record<string, any>;
    collectedAt: Date;
    temperature?: number | null;
    humidity?: number | null;
    pressure?: number | null;
    windSpeed?: number | null;
    windDirection?: number | null;
    windGust?: number | null;
    rainfall?: number | null;
    solarRadiation?: number | null;
    dewPoint?: number | null;
    batteryVoltage?: number | null;
    pm10?: number | null;
    pm25?: number | null;
    soilTemperature?: number | null;
    soilMoisture?: number | null;
    uvIndex?: number | null;
    panelTemperature?: number | null;
    waterLevel?: number | null;
    temperatureSwitch?: number | null;
    levelSwitch?: number | null;
    temperatureSwitchOutlet?: number | null;
    levelSwitchStatus?: number | null;
    lightning?: number | null;
    lightningDistance?: number | null;
    lightningEnergy?: number | null;
    chargerVoltage?: number | null;
    windDirStdDev?: number | null;
    sdi12WindVector?: number | null;
    temperature8m?: number | null;
    deltaTemperature?: number | null;
    pumpSelectWell?: number | null;
    pumpSelectBore?: number | null;
    portStatusC1?: number | null;
    portStatusC2?: number | null;
    [key: string]: any;
}
export interface InsertWeatherData {
    stationId: number;
    tableName?: string;
    recordNumber?: number;
    timestamp: Date;
    data: Record<string, any>;
}
export interface InsertWeatherStation {
    name: string;
    pakbusAddress: number;
    connectionType: string;
    connectionConfig: any;
    securityCode?: number;
    stationType?: string;
    ipAddress?: string;
    port?: number;
    serialPort?: string;
    baudRate?: number;
    protocol?: string;
    dataTable?: string;
    pollInterval?: number;
    apiKey?: string;
    apiEndpoint?: string;
    description?: string;
    location?: string;
    provider?: string;
    isActive?: boolean;
    latitude?: number;
    longitude?: number;
    altitude?: number;
    installationTeam?: string;
    stationAdmin?: string;
    stationAdminEmail?: string;
    stationAdminPhone?: string;
    stationImage?: string | null;
}
export interface User {
    id: string;
    email: string;
    firstName?: string;
    lastName?: string;
    profileImageUrl?: string;
    role?: string;
    createdAt: Date;
}
export interface StationLog {
    id: number;
    stationId: number;
    logType: string;
    message: string;
    metadata?: any;
    createdAt: Date;
}
export interface Sensor {
    id: number;
    stationId: number;
    name: string;
    type: string;
    unit: string;
    minValue?: number;
    maxValue?: number;
    createdAt: Date;
}
export interface Alarm {
    id: number;
    stationId: number;
    name: string;
    parameter: string;
    condition: string;
    threshold: number;
    unit: string;
    severity: string;
    isEnabled: boolean;
    emailNotifications: boolean;
    emailRecipients?: string | null;
    lastTriggeredAt?: Date | null;
    triggerCount: number;
    staleMinutes?: number | null;
    createdAt: Date;
}
export interface Organization {
    id: number;
    name: string;
    slug?: string;
    description?: string;
    ownerId: string;
    logoUrl?: string | null;
    createdAt: Date;
}
/**
 * Database Storage Class
 * Provides a consistent interface for data access
 */
export declare class DatabaseStorage {
    private activeAlarms;
    getUser(id: string): Promise<User | undefined>;
    upsertUser(user: Partial<User>): Promise<User>;
    updateUser(userId: string, updates: Partial<User>): Promise<User>;
    getStation(id: number): Promise<WeatherStation | undefined>;
    getWeatherStation(id: number): Promise<WeatherStation | undefined>;
    getStationByIngestId(ingestId: string): Promise<WeatherStation | undefined>;
    private stationsCache;
    private stationsCacheTime;
    private static STATIONS_CACHE_TTL;
    getStations(): Promise<WeatherStation[]>;
    /** Invalidate stations cache (call after create/update/delete) */
    private invalidateStationsCache;
    createStation(station: InsertWeatherStation): Promise<WeatherStation>;
    updateStation(id: number, station: Partial<InsertWeatherStation>): Promise<WeatherStation | undefined>;
    deleteStation(id: number): Promise<boolean>;
    getLatestWeatherData(stationId: number, tableName?: string): Promise<WeatherData | undefined>;
    getWeatherDataRange(stationId: number, startTime: Date, endTime: Date, tableName?: string): Promise<WeatherData[]>;
    /**
     * Evaluate incoming weather data against configured alarm thresholds
     * Uses one-shot logic: only sends email on transition from normal→triggered.
     * When condition clears, alarm resets silently (no "back to normal" email).
     */
    private evaluateAlarms;
    insertWeatherData(data: InsertWeatherData): Promise<WeatherData>;
    createWeatherData(data: InsertWeatherData): Promise<WeatherData>;
    getStationLogs(stationId: number, limit?: number): Promise<StationLog[]>;
    /**
     * Batch insert multiple weather data records efficiently
     * Uses a single database transaction for all records
     */
    insertWeatherDataBatch(records: InsertWeatherData[]): Promise<number>;
    createStationLog(log: {
        stationId: number;
        logType: string;
        message: string;
        metadata?: any;
    }): Promise<StationLog>;
    getUserStations(userId: string): Promise<(any & {
        station: WeatherStation;
    })[]>;
    addUserStation(data: {
        userId: string;
        stationId: number;
        isDefault?: boolean;
    }): Promise<any>;
    removeUserStation(userId: string, stationId: number): Promise<boolean>;
    setDefaultStation(userId: string, stationId: number): Promise<boolean>;
    getUserPreferences(userId: string): Promise<any>;
    upsertUserPreferences(prefs: any): Promise<any>;
    getSensors(stationId: number): Promise<Sensor[]>;
    createSensor(sensor: any): Promise<Sensor>;
    updateSensor(id: number, data: any): Promise<Sensor | undefined>;
    deleteSensor(id: number): Promise<boolean>;
    getCalibrationRecords(sensorId: number): Promise<any[]>;
    getCalibrationsDue(stationId: number, daysAhead: number): Promise<any[]>;
    createCalibrationRecord(record: any): Promise<any>;
    getMaintenanceEvents(stationId: number, type?: string, start?: Date, end?: Date): Promise<any[]>;
    createMaintenanceEvent(event: any): Promise<any>;
    getAlarms(stationId: number): Promise<Alarm[]>;
    getAllAlarms(): Promise<Alarm[]>;
    getAlarm(alarmId: number): Promise<Alarm | undefined>;
    createAlarm(alarm: any): Promise<Alarm>;
    updateAlarm(id: number, data: any): Promise<Alarm | undefined>;
    deleteAlarm(id: number): Promise<boolean>;
    getActiveAlarmEvents(stationId?: number): Promise<any[]>;
    getAlarmEvents(alarmId?: number, stationId?: number, limit?: number): Promise<any[]>;
    triggerAlarm(alarmId: number, value: number, message?: string): Promise<number>;
    acknowledgeAlarmEvent(eventId: number, acknowledgedBy: string, notes?: string): Promise<any>;
    deleteAlarmEvent(eventId: number): Promise<void>;
    cleanupOldAlarmEvents(daysToKeep?: number): Promise<number>;
    private mapDbAlarm;
    getDataQualityFlags(stationId: number, start?: Date, end?: Date): Promise<any[]>;
    createDataQualityFlag(flag: any): Promise<any>;
    getConfigurationHistory(stationId: number): Promise<any[]>;
    getStationGroups(): Promise<any[]>;
    createStationGroup(group: any): Promise<any>;
    addStationToGroup(groupId: number, stationId: number): Promise<void>;
    removeStationFromGroup(groupId: number, stationId: number): Promise<void>;
    getOrganizations(): Promise<Organization[]>;
    getUserOrganizations(userId: string): Promise<Organization[]>;
    getOrganization(id: number): Promise<Organization | undefined>;
    createOrganization(orgData: any): Promise<Organization>;
    updateOrganization(id: number, data: any): Promise<Organization | undefined>;
    deleteOrganization(id: number): Promise<boolean>;
    getOrganizationMembers(orgId: number): Promise<any[]>;
    addOrganizationMember(data: any): Promise<any>;
    updateMemberRole(orgId: number, userId: string, role: string): Promise<any>;
    removeOrganizationMember(orgId: number, userId: string): Promise<boolean>;
    isOrganizationAdmin(orgId: number, userId: string): Promise<boolean>;
    isOrganizationMember(orgId: number, userId: string): Promise<boolean>;
    getOrganizationInvitations(orgId: number): Promise<any[]>;
    createInvitation(data: any): Promise<any>;
    getInvitationByToken(token: string): Promise<any>;
    acceptInvitation(token: string, userId: string): Promise<boolean>;
    getDropboxConfigs(): Promise<any[]>;
    getDropboxConfig(id: number): Promise<any | null>;
    createDropboxConfig(data: {
        name: string;
        folderPath: string;
        filePattern?: string;
        stationId?: number;
        syncInterval?: number;
        enabled?: boolean;
    }): Promise<any>;
    updateDropboxConfig(id: number, data: Partial<{
        name: string;
        folderPath: string;
        filePattern: string;
        stationId: number;
        syncInterval: number;
        enabled: boolean;
    }>): Promise<any>;
    updateDropboxSyncStatus(id: number, status: string, recordsImported: number): Promise<void>;
    deleteDropboxConfig(id: number): Promise<boolean>;
    private mapDbStation;
    /** Convert a pg REAL value (may arrive as string) to a proper number, or undefined */
    private toReal;
    private mapPgStation;
    private mapDbWeatherData;
    private mapPgWeatherData;
    getAllUsers(): Promise<any[]>;
    getUserByEmail(email: string): Promise<any | null>;
    createUser(data: {
        email: string;
        firstName: string;
        lastName?: string;
        passwordHash: string;
        role: 'admin' | 'user';
        assignedStations?: number[];
    }): Promise<any>;
    updateUserData(email: string, updates: {
        firstName?: string;
        lastName?: string;
        passwordHash?: string;
        role?: 'admin' | 'user';
        assignedStations?: number[];
    }): Promise<any>;
    deleteUserByEmail(email: string): Promise<boolean>;
    updateUserLastLogin(email: string): Promise<void>;
}
export declare const storage: DatabaseStorage;
