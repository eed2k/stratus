"use strict";
// Stratus Weather Server
// Created by Lukas Esterhuizen
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.broadcastWeatherData = broadcastWeatherData;
exports.registerRoutes = registerRoutes;
const ws_1 = require("ws");
const localStorage_1 = require("./localStorage");
const localAuth_1 = require("./localAuth");
const zod_1 = require("zod");
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const express_rate_limit_1 = __importDefault(require("express-rate-limit"));
const auditLogService_1 = require("./services/auditLogService");
// Helper function to safely parse integer parameters with NaN validation
function parseIntSafe(value, paramName) {
    if (value === undefined || value === '') {
        return { value: null, error: `Missing required parameter: ${paramName}` };
    }
    const parsed = parseInt(value, 10);
    if (isNaN(parsed)) {
        return { value: null, error: `Invalid ${paramName}: must be a valid integer` };
    }
    return { value: parsed, error: null };
}
// Rate limiter for public ingest endpoint
const ingestRateLimiter = (0, express_rate_limit_1.default)({
    windowMs: 1 * 60 * 1000, // 1 minute window
    max: 60, // Max 60 requests per minute per IP
    message: { success: false, message: 'Too many requests, please try again later' },
    standardHeaders: true,
    legacyHeaders: false,
});
// Local schema definitions for validation
// Enhanced for Campbell Scientific and WMO compliance
// Supported connection types for Campbell Scientific dataloggers:
// - dropbox: Dropbox sync for cellular modems uploading to cloud
// - http_post: HTTP POST from station to server (datalogger pushes data)
// - tcp_ip, tcp: Direct TCP/IP connection to datalogger (ethernet/WiFi)
// - ip, wifi, http: HTTP-based polling (server pulls from datalogger API)
// - lora: LoRaWAN long-range radio
// - gsm, 4g: Cellular network via GSM/4G modem
// - mqtt: MQTT publish/subscribe messaging
// - satellite: Satellite data communication (Iridium, Inmarsat)
// - modbus: Modbus TCP protocol
// - dnp3: DNP3 SCADA protocol
const VALID_CONNECTION_TYPES = [
    'dropbox', 'http_post', 'tcp_ip', 'tcp', 'ip', 'wifi', 'http',
    'lora', 'gsm', '4g', 'mqtt', 'satellite', 'modbus', 'dnp3', 'pakbus', 'demo', 'rikacloud', 'arduino_iot'
];
const insertWeatherStationSchema = zod_1.z.object({
    name: zod_1.z.string().min(1, "Station name is required").max(100, "Station name too long"),
    pakbusAddress: zod_1.z.number()
        .int("PakBus address must be an integer")
        .min(1, "PakBus address must be at least 1")
        .max(4094, "PakBus address must be at most 4094")
        .optional()
        .default(1),
    connectionType: zod_1.z.enum(VALID_CONNECTION_TYPES, {
        errorMap: () => ({ message: `Invalid connection type. Must be one of: ${VALID_CONNECTION_TYPES.join(', ')}` })
    }),
    connectionConfig: zod_1.z.union([
        zod_1.z.string(), // Allow JSON string
        zod_1.z.object({
            host: zod_1.z.string().optional(),
            port: zod_1.z.number().int().min(1).max(65535).optional(),
            apn: zod_1.z.string().optional(),
            gatewayHost: zod_1.z.string().optional(),
            gatewayPort: zod_1.z.number().int().min(1).max(65535).optional(),
            timeout: zod_1.z.number().int().min(1000).max(300000).optional(), // 1s to 5min
            retryAttempts: zod_1.z.number().int().min(0).max(10).optional(),
            retryDelay: zod_1.z.number().int().min(1000).max(60000).optional(), // 1s to 1min
            folderPath: zod_1.z.string().optional(), // Dropbox folder path
            syncInterval: zod_1.z.number().optional(), // Dropbox sync interval
            apiEndpoint: zod_1.z.string().optional(), // HTTP POST endpoint
            apiKey: zod_1.z.string().optional(), // API key for HTTP POST
            broker: zod_1.z.string().optional(), // MQTT broker
            topic: zod_1.z.string().optional(), // MQTT topic
            frequency: zod_1.z.string().optional(), // LoRa frequency
        }).passthrough()
    ]).optional(),
    securityCode: zod_1.z.number()
        .int("Security code must be an integer")
        .min(0, "Security code must be at least 0")
        .max(65535, "Security code must be at most 65535")
        .optional()
        .default(0),
    // WMO-compliant metadata fields
    latitude: zod_1.z.number()
        .min(-90, "Latitude must be between -90 and 90")
        .max(90, "Latitude must be between -90 and 90")
        .optional()
        .nullable(),
    longitude: zod_1.z.number()
        .min(-180, "Longitude must be between -180 and 180")
        .max(180, "Longitude must be between -180 and 180")
        .optional()
        .nullable(),
    altitude: zod_1.z.number()
        .min(-500, "Altitude must be at least -500m (Dead Sea level)")
        .max(9000, "Altitude must be at most 9000m (above Everest)")
        .optional()
        .nullable(),
    timezone: zod_1.z.string().optional(),
    location: zod_1.z.string().max(200, "Location description too long").optional().nullable(),
    // Additional fields sent by client
    stationType: zod_1.z.string().optional(),
    ipAddress: zod_1.z.string().optional().nullable(),
    port: zod_1.z.number().optional().nullable(),
    apiKey: zod_1.z.string().optional().nullable(),
    apiEndpoint: zod_1.z.string().optional().nullable(),
    pollInterval: zod_1.z.number().optional(),
    protocol: zod_1.z.string().optional(),
    dataTable: zod_1.z.string().optional(),
    dataloggerModel: zod_1.z.string().optional().nullable(),
    dataloggerSerialNumber: zod_1.z.string().optional().nullable(),
    dataloggerProgramName: zod_1.z.string().optional().nullable(),
    modemModel: zod_1.z.string().optional().nullable(),
    modemSerialNumber: zod_1.z.string().optional().nullable(),
    modemPhoneNumber: zod_1.z.string().optional().nullable(),
    simCardNumber: zod_1.z.string().optional().nullable(),
    notes: zod_1.z.string().optional().nullable(),
    siteDescription: zod_1.z.string().optional().nullable(),
    lastCalibrationDate: zod_1.z.any().optional().nullable(),
    nextCalibrationDate: zod_1.z.any().optional().nullable(),
}).passthrough();
const insertWeatherDataSchema = zod_1.z.object({
    stationId: zod_1.z.number(),
    tableName: zod_1.z.string().optional(),
    recordNumber: zod_1.z.number().optional(),
    timestamp: zod_1.z.coerce.date(),
    data: zod_1.z.record(zod_1.z.any())
});
const insertUserPreferencesSchema = zod_1.z.object({
    userId: zod_1.z.string(),
    temperatureUnit: zod_1.z.string().optional(),
    windSpeedUnit: zod_1.z.string().optional(),
    pressureUnit: zod_1.z.string().optional(),
    precipitationUnit: zod_1.z.string().optional(),
    theme: zod_1.z.string().optional(),
    emailNotifications: zod_1.z.boolean().optional(),
    pushNotifications: zod_1.z.boolean().optional(),
    tempHighAlert: zod_1.z.number().optional(),
    windHighAlert: zod_1.z.number().optional(),
    units: zod_1.z.string().optional(),
    timezone: zod_1.z.string().optional(),
    serverAddress: zod_1.z.string().optional(),
});
const insertStationLogSchema = zod_1.z.object({
    stationId: zod_1.z.number(),
    logType: zod_1.z.string(),
    message: zod_1.z.string(),
    metadata: zod_1.z.any().optional()
});
const insertOrganizationSchema = zod_1.z.object({
    name: zod_1.z.string(),
    description: zod_1.z.string().optional().nullable(),
    ownerId: zod_1.z.string(),
    slug: zod_1.z.string().optional()
});
const insertOrganizationMemberSchema = zod_1.z.object({
    organizationId: zod_1.z.number(),
    userId: zod_1.z.string(),
    role: zod_1.z.string()
});
const insertOrganizationInvitationSchema = zod_1.z.object({
    organizationId: zod_1.z.number(),
    email: zod_1.z.string(),
    role: zod_1.z.string()
});
// Alarm validation schema
const insertAlarmSchema = zod_1.z.object({
    stationId: zod_1.z.number(),
    name: zod_1.z.string().min(1, "Alarm name is required"),
    parameter: zod_1.z.string().min(1, "Parameter is required"),
    condition: zod_1.z.enum(['above', 'below', 'equals', 'not_equals', 'change', 'stale', 'no_charge'], {
        errorMap: () => ({ message: "Condition must be one of: above, below, equals, not_equals, change, stale, no_charge" })
    }),
    threshold: zod_1.z.number({
        required_error: "Threshold is required",
        invalid_type_error: "Threshold must be a number"
    }),
    staleMinutes: zod_1.z.number().int().min(5).max(10080).optional(), // 5 min to 7 days
    unit: zod_1.z.string().optional().default(''),
    enabled: zod_1.z.boolean().optional().default(true),
    notifyEmail: zod_1.z.boolean().optional().default(true),
    notifyPush: zod_1.z.boolean().optional().default(false)
});
// Map storage Alarm to client-expected format
function mapAlarmToClient(alarm) {
    return {
        id: alarm.id,
        stationId: alarm.stationId,
        name: alarm.name || alarm.parameter || '',
        parameter: alarm.parameter || '',
        condition: alarm.condition,
        threshold: alarm.threshold,
        staleMinutes: alarm.staleMinutes ?? alarm.stale_minutes ?? null,
        unit: alarm.unit || '',
        enabled: alarm.isEnabled !== undefined ? alarm.isEnabled : (alarm.enabled !== false),
        notifyEmail: alarm.emailNotifications !== undefined ? alarm.emailNotifications : (alarm.notifyEmail !== false),
        notifyPush: false,
        lastTriggered: alarm.lastTriggeredAt ? alarm.lastTriggeredAt.toISOString?.() || alarm.lastTriggeredAt : null,
        triggerCount: alarm.triggerCount || 0,
    };
}
const nanoid_1 = require("nanoid");
const routes_1 = require("./campbell/routes");
const dataCollectionService_1 = require("./campbell/dataCollectionService");
const protocolManager_1 = require("./protocols/protocolManager");
const routes_2 = require("./station-setup/routes");
const routes_3 = __importDefault(require("./shares/routes"));
const routes_4 = __importDefault(require("./compliance/routes"));
const clientRoutes_1 = __importDefault(require("./clientRoutes"));
const fileWatcherRoutes_1 = __importDefault(require("./services/fileWatcherRoutes"));
const fileWatcherService_1 = require("./services/fileWatcherService");
const dropboxSyncRoutes_1 = __importDefault(require("./services/dropboxSyncRoutes"));
const dropboxSyncService_1 = require("./services/dropboxSyncService");
const reportRoutes_1 = __importDefault(require("./services/reportRoutes"));
const postgres = __importStar(require("./db-postgres"));
const db = __importStar(require("./db"));
const usePostgres = postgres.isPostgresEnabled();
const stalenessMonitorService_1 = require("./services/stalenessMonitorService");
const weeklyDigestService_1 = require("./services/weeklyDigestService");
const DEMO_MODE = process.env.VITE_DEMO_MODE === 'true';
const optionalAuth = (req, res, next) => {
    if (DEMO_MODE) {
        // In demo mode, allow read-only access without auth
        // Write operations (POST/PUT/PATCH/DELETE) still require authentication
        if (req.method === 'GET' || req.method === 'HEAD' || req.method === 'OPTIONS') {
            return next();
        }
        return (0, localAuth_1.isAuthenticated)(req, res, next);
    }
    return (0, localAuth_1.isAuthenticated)(req, res, next);
};
// Store connected WebSocket clients by station ID
const stationClients = new Map();
function broadcastWeatherData(stationId, data) {
    const clients = stationClients.get(stationId);
    if (clients) {
        const message = JSON.stringify({ type: "weather_update", stationId, data });
        clients.forEach((client) => {
            if (client.readyState === ws_1.WebSocket.OPEN) {
                client.send(message);
            }
        });
    }
}
// Wire up WebSocket broadcaster for Dropbox sync service
(0, dropboxSyncService_1.setWeatherDataBroadcaster)(broadcastWeatherData);
async function registerRoutes(httpServer, app) {
    // Setup authentication
    await (0, localAuth_1.setupAuth)(app);
    // Register Campbell Scientific routes
    (0, routes_1.registerCampbellRoutes)(app);
    // Register station setup routes
    await (0, routes_2.registerStationSetupRoutes)(app);
    // Register share routes
    app.use('/api', routes_3.default);
    // Register compliance routes (GDPR, ISO 17025, ISO 19157)
    app.use('/api/compliance', routes_4.default);
    // Register client dashboard routes (for external client applications)
    app.use('/api/client', clientRoutes_1.default);
    // Register file watcher routes (local file sync)
    app.use('/api/file-watcher', localAuth_1.isAuthenticated, localAuth_1.isAdmin, fileWatcherRoutes_1.default);
    // Register Dropbox sync routes (admin-only)
    app.use('/api/dropbox-sync', localAuth_1.isAuthenticated, localAuth_1.isAdmin, dropboxSyncRoutes_1.default);
    // Reports portal (separate password-cookie auth — see reportRoutes.ts)
    app.use('/api/reports', reportRoutes_1.default);
    // ── Staleness Monitor API routes ──────────────────────────────────────
    // GET /api/staleness/status - Check current staleness status of all stations
    app.get('/api/staleness/status', localAuth_1.isAuthenticated, localAuth_1.isAdmin, async (_req, res) => {
        try {
            const result = await (0, stalenessMonitorService_1.triggerStalenessCheck)();
            res.json({ success: true, ...result });
        }
        catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    });
    // POST /api/staleness/test-email - Send a test staleness alert email
    app.post('/api/staleness/test-email', localAuth_1.isAuthenticated, localAuth_1.isAdmin, async (req, res) => {
        try {
            const { email } = req.body || {};
            const sent = await (0, stalenessMonitorService_1.sendTestStalenessAlert)(email);
            if (sent) {
                res.json({ success: true, message: 'Test staleness alert email sent successfully' });
            }
            else {
                res.status(500).json({ success: false, message: 'Failed to send test email. Check MailerSend configuration.' });
            }
        }
        catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    });
    // POST /api/digest/run-now - Manually trigger the weekly digest email (admin only)
    app.post('/api/digest/run-now', localAuth_1.isAuthenticated, localAuth_1.isAdmin, async (_req, res) => {
        try {
            const sent = await (0, weeklyDigestService_1.runDigestNow)();
            if (sent) {
                res.json({ success: true, message: 'Weekly digest email sent.' });
            }
            else {
                res.status(500).json({ success: false, message: 'Failed to send digest. Check MailerSend configuration and server logs.' });
            }
        }
        catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    });
    // ── Database Backup API routes (admin only) ────────────────────────────
    // POST /api/backup/create - Trigger a manual backup
    app.post('/api/backup/create', localAuth_1.isAuthenticated, localAuth_1.isAdmin, async (_req, res) => {
        try {
            const { execSync } = await Promise.resolve().then(() => __importStar(require('child_process')));
            const backupDir = '/root/stratus/backups/daily';
            const date = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
            const filename = `stratus_backup_manual_${date}.sql.gz`;
            // Create backup directory if needed
            execSync(`mkdir -p ${backupDir}`);
            // Run pg_dump via docker exec
            execSync(`docker exec stratus-postgres pg_dump -U stratus -d stratus --clean --if-exists --no-owner --no-privileges | gzip > ${backupDir}/${filename}`, { timeout: 60000 });
            const stats = fs_1.default.statSync(`${backupDir}/${filename}`);
            const sizeMB = (stats.size / 1024 / 1024).toFixed(2);
            console.log(`[Backup] Manual backup created: ${filename} (${sizeMB} MB)`);
            res.json({ success: true, filename, size: `${sizeMB} MB`, timestamp: new Date().toISOString() });
        }
        catch (error) {
            console.error('[Backup] Manual backup failed:', error.message);
            res.status(500).json({ success: false, message: error.message });
        }
    });
    // GET /api/backup/list - List available backups
    app.get('/api/backup/list', localAuth_1.isAuthenticated, localAuth_1.isAdmin, async (_req, res) => {
        try {
            const backupBase = '/root/stratus/backups';
            const categories = ['daily', 'weekly', 'pre-deploy'];
            const backups = [];
            for (const cat of categories) {
                const dir = `${backupBase}/${cat}`;
                if (fs_1.default.existsSync(dir)) {
                    const files = fs_1.default.readdirSync(dir).filter(f => f.endsWith('.sql.gz')).sort().reverse();
                    for (const file of files) {
                        const stats = fs_1.default.statSync(`${dir}/${file}`);
                        backups.push({
                            category: cat,
                            filename: file,
                            size: `${(stats.size / 1024 / 1024).toFixed(2)} MB`,
                            date: stats.mtime.toISOString(),
                        });
                    }
                }
            }
            res.json({ success: true, backups, total: backups.length });
        }
        catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    });
    // GET /api/backup/status - Get backup system status
    app.get('/api/backup/status', localAuth_1.isAuthenticated, localAuth_1.isAdmin, async (_req, res) => {
        try {
            const backupBase = '/root/stratus/backups';
            const categories = ['daily', 'weekly', 'pre-deploy'];
            let latestBackup = null;
            let latestDate = null;
            let totalBackups = 0;
            let totalSize = 0;
            for (const cat of categories) {
                const dir = `${backupBase}/${cat}`;
                if (fs_1.default.existsSync(dir)) {
                    const files = fs_1.default.readdirSync(dir).filter(f => f.endsWith('.sql.gz'));
                    totalBackups += files.length;
                    for (const file of files) {
                        const stats = fs_1.default.statSync(`${dir}/${file}`);
                        totalSize += stats.size;
                        if (!latestDate || stats.mtime > latestDate) {
                            latestDate = stats.mtime;
                            latestBackup = `${cat}/${file}`;
                        }
                    }
                }
            }
            const cronInstalled = fs_1.default.existsSync('/etc/cron.d/stratus-backup') ||
                (() => { try {
                    const { execSync } = require('child_process');
                    return execSync('crontab -l 2>/dev/null').toString().includes('backup.sh');
                }
                catch {
                    return false;
                } })();
            res.json({
                success: true,
                cronScheduled: cronInstalled,
                latestBackup,
                latestDate: latestDate?.toISOString() || null,
                totalBackups,
                totalSize: `${(totalSize / 1024 / 1024).toFixed(2)} MB`,
            });
        }
        catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    });
    // Initialise file watcher service
    await fileWatcherService_1.fileWatcherService.initialize();
    // Initialise Dropbox sync with configuration from environment or DB
    // This auto-syncs .dat files from Dropbox folder every hour
    let DROPBOX_ACCESS_TOKEN = process.env.DROPBOX_ACCESS_TOKEN || '';
    let DROPBOX_FOLDER_PATH = process.env.DROPBOX_FOLDER_PATH || '';
    // Station ID is optional - if not provided, will auto-create based on folder name
    const DROPBOX_STATION_ID_STR = process.env.DROPBOX_STATION_ID;
    let DROPBOX_STATION_ID = DROPBOX_STATION_ID_STR ? parseInt(DROPBOX_STATION_ID_STR, 10) : 0; // 0 means auto-detect/create
    const DROPBOX_SYNC_INTERVAL = parseInt(process.env.DROPBOX_SYNC_INTERVAL || '3600000', 10); // Default 1 hour
    // OAuth 2.0 refresh token support for 24/7 deployment
    let DROPBOX_REFRESH_TOKEN = process.env.DROPBOX_REFRESH_TOKEN || '';
    let DROPBOX_APP_KEY = process.env.DROPBOX_APP_KEY || '';
    let DROPBOX_APP_SECRET = process.env.DROPBOX_APP_SECRET || '';
    // Restore Dropbox credentials from database if not set via environment
    if (!DROPBOX_REFRESH_TOKEN || !DROPBOX_APP_KEY) {
        try {
            const dbCreds = usePostgres
                ? await postgres.getSetting('dropbox_credentials')
                : db.getSetting('dropbox_credentials');
            if (dbCreds) {
                const parsed = JSON.parse(dbCreds);
                if (!DROPBOX_APP_KEY && parsed.appKey) {
                    DROPBOX_APP_KEY = parsed.appKey;
                    process.env.DROPBOX_APP_KEY = parsed.appKey;
                }
                if (!DROPBOX_APP_SECRET && parsed.appSecret) {
                    DROPBOX_APP_SECRET = parsed.appSecret;
                    process.env.DROPBOX_APP_SECRET = parsed.appSecret;
                }
                if (!DROPBOX_REFRESH_TOKEN && parsed.refreshToken) {
                    DROPBOX_REFRESH_TOKEN = parsed.refreshToken;
                    process.env.DROPBOX_REFRESH_TOKEN = parsed.refreshToken;
                }
                console.log('[Routes] Dropbox credentials restored from database');
            }
        }
        catch (err) {
            console.warn('[Routes] Could not restore Dropbox credentials from DB:', err.message);
        }
    }
    if (DROPBOX_ACCESS_TOKEN || DROPBOX_REFRESH_TOKEN) {
        dropboxSyncService_1.dropboxSyncService.configure({
            accessToken: DROPBOX_ACCESS_TOKEN,
            folderPath: DROPBOX_FOLDER_PATH,
            stationId: DROPBOX_STATION_ID,
            syncInterval: DROPBOX_SYNC_INTERVAL,
            enabled: true,
            // Include refresh token config for automatic token renewal
            refreshToken: DROPBOX_REFRESH_TOKEN || undefined,
            appKey: DROPBOX_APP_KEY || undefined,
            appSecret: DROPBOX_APP_SECRET || undefined,
        });
        const stationInfo = DROPBOX_STATION_ID > 0 ? `station=${DROPBOX_STATION_ID}` : 'station=auto-detect';
        const refreshInfo = DROPBOX_REFRESH_TOKEN ? ', refresh_token=configured' : ', refresh_token=none (short-lived token only)';
        console.log(`[Routes] Dropbox sync configured: folder=${DROPBOX_FOLDER_PATH}, ${stationInfo}, interval=${DROPBOX_SYNC_INTERVAL}ms${refreshInfo}`);
    }
    // Public health check endpoint with CORS for external clients
    app.get('/api/health', (req, res) => {
        // Set CORS headers for cross-origin access
        const origin = req.headers.origin;
        if (origin) {
            res.header('Access-Control-Allow-Origin', origin);
        }
        else {
            res.header('Access-Control-Allow-Origin', '*');
        }
        res.header('Access-Control-Allow-Methods', 'GET, OPTIONS');
        res.header('Access-Control-Allow-Headers', 'Content-Type');
        res.json({ status: 'ok', timestamp: new Date().toISOString(), server: 'stratus' });
    });
    // Initialise data collection service
    try {
        await dataCollectionService_1.dataCollectionService.initialize();
        console.log('Campbell Scientific data collection service initialized');
    }
    catch (error) {
        console.error('Failed to initialize data collection service:', error);
    }
    // Initialise Protocol Manager for all station types
    try {
        await protocolManager_1.protocolManager.initialize();
        console.log('Protocol Manager initialized');
    }
    catch (error) {
        console.error('Failed to initialize Protocol Manager:', error);
    }
    // Protocol Manager API endpoints
    app.get("/api/protocols/status", optionalAuth, async (req, res) => {
        try {
            const statuses = {};
            const allStatuses = protocolManager_1.protocolManager.getAllStationStatuses();
            for (const [id, status] of allStatuses) {
                statuses[id] = status;
            }
            res.json(statuses);
        }
        catch (error) {
            res.status(500).json({ message: error.message });
        }
    });
    app.get("/api/protocols/status/:stationId", optionalAuth, async (req, res) => {
        try {
            const { value: stationId, error } = parseIntSafe(req.params.stationId, 'stationId');
            if (error || stationId === null) {
                return res.status(400).json({ message: error });
            }
            const status = protocolManager_1.protocolManager.getStationStatus(stationId);
            if (!status) {
                return res.status(404).json({ message: "Station not found" });
            }
            res.json(status);
        }
        catch (error) {
            res.status(500).json({ message: error.message });
        }
    });
    app.post("/api/protocols/test/:stationId", optionalAuth, async (req, res) => {
        try {
            const { value: stationId, error } = parseIntSafe(req.params.stationId, 'stationId');
            if (error || stationId === null) {
                return res.status(400).json({ success: false, message: error });
            }
            const result = await protocolManager_1.protocolManager.testConnection(stationId);
            res.json(result);
        }
        catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    });
    app.post("/api/protocols/reconnect/:stationId", optionalAuth, async (req, res) => {
        try {
            const { value: stationId, error } = parseIntSafe(req.params.stationId, 'stationId');
            if (error || stationId === null) {
                return res.status(400).json({ message: error });
            }
            const station = await localStorage_1.storage.getWeatherStation(stationId);
            if (!station) {
                return res.status(404).json({ message: "Station not found" });
            }
            // Re-register station to force reconnection
            await protocolManager_1.protocolManager.unregisterStation(stationId);
            let connectionConfig = {};
            if (station.connectionConfig) {
                try {
                    connectionConfig = typeof station.connectionConfig === 'string'
                        ? JSON.parse(station.connectionConfig)
                        : station.connectionConfig;
                }
                catch (e) {
                    connectionConfig = {};
                }
            }
            // Map connection type to protocol
            const protocolMap = {
                'mqtt': 'mqtt', 'http': 'http', 'ip': 'http', 'wifi': 'http',
                'tcp': 'http', 'tcp_ip': 'http', 'lora': 'lora', 'serial': 'modbus',
                'satellite': 'satellite', 'dropbox': 'http', 'http_post': 'http',
                'gsm': 'http', '4g': 'http', 'pakbus': 'pakbus', 'rikacloud': 'http',
                'arduino_iot': 'http',
            };
            await protocolManager_1.protocolManager.registerStation(stationId, {
                stationId,
                protocol: (protocolMap[station.connectionType || ''] || 'http'),
                connectionType: station.connectionType || 'http',
                host: station.ipAddress || connectionConfig.broker,
                port: station.port || connectionConfig.port,
                apiKey: station.apiKey || undefined,
                apiEndpoint: station.apiEndpoint || connectionConfig.topic,
                ...connectionConfig,
            });
            res.json({ success: true, message: "Station reconnected" });
        }
        catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    });
    // Station cleanup endpoint - remove demo and duplicate stations
    app.post("/api/stations/cleanup", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const stations = await localStorage_1.storage.getStations();
            const deleted = [];
            const kept = [];
            const seenNames = new Set();
            for (const station of stations) {
                // Delete demo stations
                if (station.name?.toLowerCase().includes('demo') ||
                    station.connectionType === 'demo') {
                    await localStorage_1.storage.deleteStation(station.id);
                    deleted.push(station.id);
                    continue;
                }
                // Delete duplicates (keep first occurrence)
                const normalizedName = station.name?.toLowerCase().trim();
                if (seenNames.has(normalizedName)) {
                    await localStorage_1.storage.deleteStation(station.id);
                    deleted.push(station.id);
                }
                else {
                    seenNames.add(normalizedName);
                    kept.push({ id: station.id, name: station.name });
                }
            }
            res.json({
                message: `Cleanup complete: deleted ${deleted.length} stations, kept ${kept.length}`,
                deleted,
                kept
            });
        }
        catch (error) {
            console.error("Error cleaning up stations:", error);
            res.status(500).json({ message: error.message });
        }
    });
    // NOTE: Export functionality has been disabled
    // If you need to re-enable exports, uncomment the PDF and CSV export endpoints below
    // Setup WebSocket server for real-time updates
    const wss = new ws_1.WebSocketServer({ server: httpServer, path: "/ws" });
    wss.on("connection", (ws) => {
        let subscribedStations = [];
        ws.on("message", (message) => {
            try {
                // Limit WebSocket message size to 4KB to prevent abuse
                const msgStr = message.toString();
                if (msgStr.length > 4096) {
                    ws.send(JSON.stringify({ type: "error", message: "Message too large" }));
                    return;
                }
                const data = JSON.parse(msgStr);
                if (data.type === "subscribe" && typeof data.stationId === "number") {
                    const stationId = data.stationId;
                    if (!stationClients.has(stationId)) {
                        stationClients.set(stationId, new Set());
                    }
                    stationClients.get(stationId).add(ws);
                    subscribedStations.push(stationId);
                    ws.send(JSON.stringify({ type: "subscribed", stationId }));
                }
                if (data.type === "unsubscribe" && typeof data.stationId === "number") {
                    const stationId = data.stationId;
                    const clients = stationClients.get(stationId);
                    if (clients) {
                        clients.delete(ws);
                        if (clients.size === 0) {
                            stationClients.delete(stationId);
                        }
                    }
                    subscribedStations = subscribedStations.filter((id) => id !== stationId);
                    ws.send(JSON.stringify({ type: "unsubscribed", stationId }));
                }
            }
            catch (error) {
                console.error("WebSocket message error:", error);
            }
        });
        ws.on("close", () => {
            // Clean up subscriptions when client disconnects
            subscribedStations.forEach((stationId) => {
                const clients = stationClients.get(stationId);
                if (clients) {
                    clients.delete(ws);
                    if (clients.size === 0) {
                        stationClients.delete(stationId);
                    }
                }
            });
        });
        ws.send(JSON.stringify({ type: "connected" }));
    });
    // Auth routes
    app.get("/api/auth/user", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const userId = (0, localAuth_1.getUserId)(req);
            const user = await localStorage_1.storage.getUser(userId);
            res.json(user);
        }
        catch (error) {
            console.error("Error fetching user:", error);
            res.status(500).json({ message: "Failed to fetch user" });
        }
    });
    // Update user profile
    app.patch("/api/auth/user", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const userId = (0, localAuth_1.getUserId)(req);
            const { firstName, lastName, email } = req.body;
            const updates = {};
            if (firstName !== undefined)
                updates.firstName = firstName;
            if (lastName !== undefined)
                updates.lastName = lastName;
            if (email !== undefined)
                updates.email = email;
            const user = await localStorage_1.storage.updateUser(userId, updates);
            res.json(user);
        }
        catch (error) {
            console.error("Error updating user:", error);
            res.status(500).json({ message: "Failed to update user" });
        }
    });
    // 
    // Get all users (admin only)
    app.get("/api/users", localAuth_1.isAuthenticated, localAuth_1.isAdmin, async (req, res) => {
        try {
            const users = await localStorage_1.storage.getAllUsers();
            // Remove password hashes and hide system admin from response
            const sanitizedUsers = users
                .filter(u => u.email.trim().toLowerCase() !== 'admin@stratusweather.co.za')
                .map(({ passwordHash, ...user }) => user);
            res.json(sanitizedUsers);
        }
        catch (error) {
            console.error("Error fetching users:", error);
            res.status(500).json({ message: "Failed to fetch users" });
        }
    });
    // Get user by email
    app.get("/api/users/:email", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const user = await localStorage_1.storage.getUserByEmail(req.params.email);
            if (!user) {
                return res.status(404).json({ message: "User not found" });
            }
            // Remove password hash from response
            const { passwordHash, ...sanitizedUser } = user;
            res.json(sanitizedUser);
        }
        catch (error) {
            console.error("Error fetching user:", error);
            res.status(500).json({ message: "Failed to fetch user" });
        }
    });
    // Create new user (admin only)
    app.post("/api/users", localAuth_1.isAuthenticated, localAuth_1.isAdmin, async (req, res) => {
        try {
            const { email, firstName, lastName, password, role, assignedStations, sendInvitation, customMessage } = req.body;
            // Validate required fields
            if (!email || !firstName) {
                return res.status(400).json({ message: "Missing required fields: email, firstName" });
            }
            // Check if user already exists
            const existing = await localStorage_1.storage.getUserByEmail(email);
            if (existing) {
                return res.status(409).json({ message: "User with this email already exists" });
            }
            // Hash password with bcrypt - never accept pre-hashed passwords from client
            const bcrypt = require('bcryptjs');
            let finalPasswordHash;
            // If sendInvitation is true, create user without password and send invitation email
            if (sendInvitation === true) {
                // Create user with a temporary placeholder password (will be set via invitation)
                const tempHash = await bcrypt.hash(require('crypto').randomBytes(32).toString('hex'), 10);
                finalPasswordHash = tempHash;
            }
            else {
                // Traditional flow - password required
                if (!password) {
                    return res.status(400).json({ message: "Missing required field: password (or set sendInvitation: true)" });
                }
                finalPasswordHash = await bcrypt.hash(password, 10);
            }
            const user = await localStorage_1.storage.createUser({
                email,
                firstName,
                lastName,
                passwordHash: finalPasswordHash,
                role: role || 'user',
                assignedStations: assignedStations || []
            });
            // Log audit event
            await auditLogService_1.auditLog.log(auditLogService_1.AUDIT_ACTIONS.USER_CREATE, 'users', {
                userId: (0, localAuth_1.getUserId)(req),
                userEmail: email,
                details: { newUserEmail: email, role: user.role, invitationSent: sendInvitation === true },
                ip: req.ip,
                userAgent: req.headers['user-agent']
            });
            // Send invitation email if requested
            if (sendInvitation === true) {
                try {
                    const postgres = require('./db-postgres');
                    const invitedBy = (0, localAuth_1.getUserId)(req);
                    const token = await postgres.createUserInvitationToken(email, invitedBy, customMessage);
                    const { sendUserInvitationEmail } = require('./services/emailService');
                    const emailSent = await sendUserInvitationEmail(email, {
                        firstName,
                        inviterName: invitedBy,
                        setupToken: token,
                        customMessage
                    });
                    if (!emailSent) {
                        console.error(`[Routes] Failed to send invitation email to ${email}`);
                    }
                    else {
                        console.log(`[Routes] Invitation email sent to ${email}`);
                    }
                }
                catch (emailError) {
                    console.error('[Routes] Error sending invitation email:', emailError);
                    // Don't fail the request - user was created, email just failed
                }
            }
            // Remove password hash from response
            const { passwordHash: _, ...sanitizedUser } = user;
            res.status(201).json({
                ...sanitizedUser,
                invitationSent: sendInvitation === true
            });
        }
        catch (error) {
            console.error("Error creating user:", error);
            res.status(500).json({ message: "Failed to create user" });
        }
    });
    // Resend invitation email to a user (admin only)
    app.post("/api/users/:email/resend-invitation", localAuth_1.isAuthenticated, localAuth_1.isAdmin, async (req, res) => {
        try {
            const { email } = req.params;
            const { customMessage } = req.body;
            // Check if user exists
            const user = await localStorage_1.storage.getUserByEmail(email);
            if (!user) {
                return res.status(404).json({ message: "User not found" });
            }
            // Create new invitation token and send email
            const postgres = require('./db-postgres');
            const invitedBy = (0, localAuth_1.getUserId)(req);
            const token = await postgres.createUserInvitationToken(email, invitedBy, customMessage);
            const { sendUserInvitationEmail } = require('./services/emailService');
            const emailSent = await sendUserInvitationEmail(email, {
                firstName: user.firstName || 'User',
                inviterName: invitedBy,
                setupToken: token,
                customMessage
            });
            if (!emailSent) {
                return res.status(500).json({ message: "Failed to send invitation email" });
            }
            // Log audit event
            await auditLogService_1.auditLog.log(auditLogService_1.AUDIT_ACTIONS.USER_UPDATE, 'users', {
                userId: (0, localAuth_1.getUserId)(req),
                userEmail: email,
                details: { action: 'resend_invitation' },
                ip: req.ip,
                userAgent: req.headers['user-agent']
            });
            res.json({ success: true, message: "Invitation email sent successfully" });
        }
        catch (error) {
            console.error("Error resending invitation:", error);
            res.status(500).json({ message: "Failed to resend invitation" });
        }
    });
    // Update user (admin only)
    app.patch("/api/users/:email", localAuth_1.isAuthenticated, localAuth_1.isAdmin, async (req, res) => {
        try {
            const { firstName, lastName, password, role, assignedStations } = req.body;
            const updates = {};
            if (firstName !== undefined)
                updates.firstName = firstName;
            if (lastName !== undefined)
                updates.lastName = lastName;
            // Handle password update - always hash server-side, never accept pre-hashed
            if (password) {
                const bcrypt = require('bcryptjs');
                updates.passwordHash = await bcrypt.hash(password, 10);
            }
            if (role !== undefined)
                updates.role = role;
            if (assignedStations !== undefined)
                updates.assignedStations = assignedStations;
            const user = await localStorage_1.storage.updateUserData(req.params.email, updates);
            if (!user) {
                return res.status(404).json({ message: "User not found" });
            }
            // Log audit event
            await auditLogService_1.auditLog.log(auditLogService_1.AUDIT_ACTIONS.USER_UPDATE, 'users', {
                userId: (0, localAuth_1.getUserId)(req),
                userEmail: req.params.email,
                details: { updates: Object.keys(updates) },
                ip: req.ip,
                userAgent: req.headers['user-agent']
            });
            // Remove password hash from response
            const { passwordHash: _, ...sanitizedUser } = user;
            res.json(sanitizedUser);
        }
        catch (error) {
            console.error("Error updating user:", error);
            res.status(500).json({ message: "Failed to update user" });
        }
    });
    // Delete user (admin only)
    app.delete("/api/users/:email", localAuth_1.isAuthenticated, localAuth_1.isAdmin, async (req, res) => {
        try {
            await localStorage_1.storage.deleteUserByEmail(req.params.email);
            // Log audit event
            await auditLogService_1.auditLog.log(auditLogService_1.AUDIT_ACTIONS.USER_DELETE, 'users', {
                userId: (0, localAuth_1.getUserId)(req),
                userEmail: req.params.email,
                details: { deletedUserEmail: req.params.email },
                ip: req.ip,
                userAgent: req.headers['user-agent']
            });
            res.json({ success: true, message: "User deleted successfully" });
        }
        catch (error) {
            console.error("Error deleting user:", error);
            res.status(500).json({ message: "Failed to delete user" });
        }
    });
    // Weather Stations routes (demo mode bypasses auth)
    app.get("/api/stations", optionalAuth, async (req, res) => {
        try {
            const stations = await localStorage_1.storage.getStations();
            res.json(stations);
        }
        catch (error) {
            console.error("Error fetching stations:", error);
            res.status(500).json({ message: "Failed to fetch stations" });
        }
    });
    app.get("/api/stations/:id", optionalAuth, async (req, res) => {
        try {
            const { value: stationId, error } = parseIntSafe(req.params.id, 'id');
            if (error || stationId === null) {
                return res.status(400).json({ message: error });
            }
            const station = await localStorage_1.storage.getStation(stationId);
            if (!station) {
                return res.status(404).json({ message: "Station not found" });
            }
            res.json(station);
        }
        catch (error) {
            console.error("Error fetching station:", error);
            res.status(500).json({ message: "Failed to fetch station" });
        }
    });
    app.post("/api/stations", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const parsed = insertWeatherStationSchema.safeParse(req.body);
            if (!parsed.success) {
                return res.status(400).json({ message: "Invalid station data", errors: parsed.error.errors });
            }
            // Set default station image (Stratus logo) if none provided
            const stationData = parsed.data;
            if (!stationData.stationImage) {
                stationData.stationImage = 'data:image/svg+xml;base64,' + Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" fill="none"><circle cx="16" cy="16" r="15" fill="#1e3a5f"/><circle cx="16" cy="16" r="5" fill="white"/></svg>').toString('base64');
            }
            const station = await localStorage_1.storage.createStation(stationData);
            // Auto-register with Protocol Manager if not demo
            if (station.connectionType !== 'demo' && station.isActive) {
                try {
                    let connectionConfig = {};
                    if (station.connectionConfig) {
                        try {
                            connectionConfig = typeof station.connectionConfig === 'string'
                                ? JSON.parse(station.connectionConfig)
                                : station.connectionConfig;
                        }
                        catch (e) {
                            connectionConfig = {};
                        }
                    }
                    // Handle Dropbox sync configuration
                    const isDropboxStation = station.connectionType === 'dropbox' ||
                        (connectionConfig.importSource === 'dropbox') ||
                        (connectionConfig.type === 'import-only' && connectionConfig.importSource === 'dropbox');
                    if (isDropboxStation) {
                        const DROPBOX_ACCESS_TOKEN = process.env.DROPBOX_ACCESS_TOKEN || '';
                        const DROPBOX_REFRESH_TOKEN = process.env.DROPBOX_REFRESH_TOKEN || '';
                        const DROPBOX_APP_KEY = process.env.DROPBOX_APP_KEY || '';
                        const DROPBOX_APP_SECRET = process.env.DROPBOX_APP_SECRET || '';
                        if (DROPBOX_ACCESS_TOKEN || DROPBOX_REFRESH_TOKEN) {
                            const folderPath = connectionConfig.folderPath || '';
                            const filePattern = connectionConfig.filePattern || '';
                            const syncInterval = parseInt(connectionConfig.syncInterval) || 3600;
                            // Do NOT call dropboxSyncService.configure() here — it overwrites the main
                            // singleton config (Hopefield), breaking existing sync. Instead, only create a
                            // dropbox_configs DB entry so syncDbConfigs() picks up this new station.
                            console.log(`[Routes] Creating DB-only Dropbox config for station ${station.id} (not overwriting main sync config)`);
                            // Auto-create dropbox_configs entry so syncDbConfigs() picks up this station
                            try {
                                await localStorage_1.storage.createDropboxConfig({
                                    name: station.name || `Station ${station.id} Sync`,
                                    folderPath: folderPath,
                                    filePattern: filePattern || undefined,
                                    stationId: station.id,
                                    syncInterval: syncInterval * 1000,
                                    enabled: true,
                                });
                                console.log(`[Routes] Dropbox config created for station ${station.id}: folder=${folderPath}, pattern=${filePattern || '*'}, interval=${syncInterval}s`);
                                // Reinitialise sync service to pick up new config & trigger immediate sync
                                await dropboxSyncService_1.dropboxSyncService.reinitialize();
                                setTimeout(async () => {
                                    try {
                                        console.log(`[Routes] Auto-triggering sync for new Dropbox station ${station.id}...`);
                                        await dropboxSyncService_1.dropboxSyncService.syncNow();
                                    }
                                    catch (err) {
                                        console.error(`[Routes] Auto-sync after station creation failed:`, err.message);
                                    }
                                }, 1000);
                            }
                            catch (dbErr) {
                                console.warn(`[Routes] Could not create dropbox_configs entry: ${dbErr.message}`);
                            }
                        }
                        else {
                            console.warn(`[Routes] Station ${station.id} configured for Dropbox but no access token in environment`);
                        }
                    }
                    const protocolMap = {
                        'mqtt': 'mqtt', 'http': 'http', 'ip': 'http', 'wifi': 'http',
                        'tcp': 'http', 'tcp_ip': 'http', 'lora': 'lora', 'serial': 'modbus',
                        'satellite': 'satellite', 'dropbox': 'http', 'http_post': 'http',
                        'gsm': 'http', '4g': 'http', 'pakbus': 'pakbus', 'rikacloud': 'http',
                        'arduino_iot': 'http',
                    };
                    await protocolManager_1.protocolManager.registerStation(station.id, {
                        stationId: station.id,
                        protocol: (protocolMap[station.connectionType || ''] || 'http'),
                        connectionType: station.connectionType || 'http',
                        host: station.ipAddress || connectionConfig.broker,
                        port: station.port || connectionConfig.port,
                        apiKey: station.apiKey || undefined,
                        apiEndpoint: station.apiEndpoint || connectionConfig.topic,
                        ...connectionConfig,
                    });
                }
                catch (regError) {
                    console.warn(`Failed to register station ${station.id} with Protocol Manager:`, regError);
                }
            }
            // Log station creation
            await auditLogService_1.auditLog.log(auditLogService_1.AUDIT_ACTIONS.STATION_CREATE, 'stations', {
                userId: (0, localAuth_1.getUserId)(req),
                resourceId: station.id,
                details: { name: station.name, connectionType: station.connectionType },
                ip: req.ip || req.socket.remoteAddress,
                status: 'success'
            });
            res.status(201).json(station);
        }
        catch (error) {
            console.error("Error creating station:", error);
            res.status(500).json({ message: "Failed to create station" });
        }
    });
    app.patch("/api/stations/:id", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const { value: stationId, error } = parseIntSafe(req.params.id, 'id');
            if (error || stationId === null) {
                return res.status(400).json({ message: error });
            }
            // Whitelist allowed fields to prevent injection of unexpected properties
            const allowedFields = ['name', 'location', 'latitude', 'longitude', 'altitude', 'isActive',
                'connectionType', 'connectionConfig', 'ipAddress', 'port', 'protocol',
                'pakbusAddress', 'securityCode', 'dataloggerModel', 'dataloggerSerialNumber',
                'dataloggerProgramName', 'siteDescription', 'notes', 'modemModel', 'modemSerialNumber',
                'lastCalibrationDate', 'nextCalibrationDate', 'stationImage', 'stationType'];
            const sanitizedBody = {};
            for (const key of allowedFields) {
                if (req.body[key] !== undefined) {
                    sanitizedBody[key] = req.body[key];
                }
            }
            const station = await localStorage_1.storage.updateStation(stationId, sanitizedBody);
            if (!station) {
                return res.status(404).json({ message: "Station not found" });
            }
            // Re-register with Protocol Manager if connection settings changed
            if (station.connectionType !== 'demo') {
                try {
                    await protocolManager_1.protocolManager.unregisterStation(station.id);
                    if (station.isActive) {
                        let connectionConfig = {};
                        if (station.connectionConfig) {
                            try {
                                connectionConfig = typeof station.connectionConfig === 'string'
                                    ? JSON.parse(station.connectionConfig)
                                    : station.connectionConfig;
                            }
                            catch (e) {
                                connectionConfig = {};
                            }
                        }
                        // Handle Dropbox sync configuration updates
                        // Use DB-only approach (like the POST/create route) to avoid overwriting
                        // the main singleton sync config (e.g. Hopefield)
                        if (station.connectionType === 'dropbox') {
                            const folderPath = connectionConfig.folderPath || '';
                            const filePattern = connectionConfig.filePattern || '';
                            const syncInterval = parseInt(connectionConfig.syncInterval) || 3600;
                            try {
                                // Update or create the dropbox_configs DB entry
                                const existingConfigs = await localStorage_1.storage.getDropboxConfigs();
                                const existing = existingConfigs.find((c) => c.stationId === station.id);
                                if (existing) {
                                    await localStorage_1.storage.updateDropboxConfig(existing.id, {
                                        folderPath,
                                        filePattern,
                                        syncInterval: syncInterval * 1000,
                                        enabled: true,
                                    });
                                    console.log(`[Routes] Dropbox config updated for station ${station.id}: folder=${folderPath}, pattern=${filePattern || '*'}, interval=${syncInterval}s`);
                                }
                                else {
                                    await localStorage_1.storage.createDropboxConfig({
                                        name: station.name || `Station ${station.id}`,
                                        folderPath,
                                        filePattern,
                                        stationId: station.id,
                                        syncInterval: syncInterval * 1000,
                                        enabled: true,
                                    });
                                    console.log(`[Routes] Dropbox config created for station ${station.id}: folder=${folderPath}, pattern=${filePattern || '*'}, interval=${syncInterval}s`);
                                }
                                // Reinitialise sync service to pick up DB changes
                                await dropboxSyncService_1.dropboxSyncService.reinitialize();
                            }
                            catch (dbErr) {
                                console.warn(`[Routes] Could not update dropbox_configs entry: ${dbErr.message}`);
                            }
                        }
                        const protocolMap = {
                            'mqtt': 'mqtt', 'http': 'http', 'ip': 'http', 'wifi': 'http',
                            'tcp': 'http', 'tcp_ip': 'http', 'lora': 'lora', 'serial': 'modbus',
                            'satellite': 'satellite', 'dropbox': 'http', 'http_post': 'http',
                            'gsm': 'http', '4g': 'http', 'pakbus': 'pakbus', 'rikacloud': 'http',
                            'arduino_iot': 'http',
                        };
                        await protocolManager_1.protocolManager.registerStation(station.id, {
                            stationId: station.id,
                            protocol: (protocolMap[station.connectionType || ''] || 'http'),
                            connectionType: station.connectionType || 'http',
                            host: station.ipAddress || connectionConfig.broker,
                            port: station.port || connectionConfig.port,
                            apiKey: station.apiKey || undefined,
                            apiEndpoint: station.apiEndpoint || connectionConfig.topic,
                            ...connectionConfig,
                        });
                    }
                }
                catch (regError) {
                    console.warn(`Failed to update station ${station.id} in Protocol Manager:`, regError);
                }
            }
            res.json(station);
        }
        catch (error) {
            console.error("Error updating station:", error);
            res.status(500).json({ message: "Failed to update station" });
        }
    });
    // Dashboard config - GET (read config for a station)
    app.get("/api/stations/:stationId/dashboard-config", optionalAuth, async (req, res) => {
        try {
            const { value: stationId, error } = parseIntSafe(req.params.stationId, 'stationId');
            if (error || stationId === null) {
                return res.status(400).json({ message: error });
            }
            if (usePostgres) {
                const result = await postgres.query('SELECT dashboard_config FROM stations WHERE id = $1', [stationId]);
                if (result.rows.length === 0)
                    return res.status(404).json({ message: 'Station not found' });
                res.json(result.rows[0].dashboard_config || null);
            }
            else {
                const station = await localStorage_1.storage.getStation(stationId);
                if (!station)
                    return res.status(404).json({ message: 'Station not found' });
                const config = station.dashboardConfig;
                res.json(config ? JSON.parse(config) : null);
            }
        }
        catch (error) {
            console.error("Error fetching dashboard config:", error);
            res.status(500).json({ message: "Failed to fetch dashboard config" });
        }
    });
    // Dashboard config - PUT (save config for a station, admin only)
    app.put("/api/stations/:stationId/dashboard-config", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const { value: stationId, error } = parseIntSafe(req.params.stationId, 'stationId');
            if (error || stationId === null) {
                return res.status(400).json({ message: error });
            }
            const config = req.body;
            if (usePostgres) {
                await postgres.query('UPDATE stations SET dashboard_config = $1 WHERE id = $2', [JSON.stringify(config), stationId]);
            }
            else {
                const db = (await Promise.resolve().then(() => __importStar(require('./db')))).getDatabase();
                if (db)
                    db.run('UPDATE stations SET dashboard_config = ? WHERE id = ?', [JSON.stringify(config), stationId]);
            }
            res.json({ success: true });
        }
        catch (error) {
            console.error("Error saving dashboard config:", error);
            res.status(500).json({ message: "Failed to save dashboard config" });
        }
    });
    app.delete("/api/stations/:id", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const { value: stationId, error } = parseIntSafe(req.params.id, 'id');
            if (error || stationId === null) {
                return res.status(400).json({ message: error });
            }
            // Unregister from Protocol Manager first
            try {
                await protocolManager_1.protocolManager.unregisterStation(stationId);
            }
            catch (regError) {
                console.warn(`Failed to unregister station ${stationId} from Protocol Manager:`, regError);
            }
            const deleted = await localStorage_1.storage.deleteStation(stationId);
            if (!deleted) {
                return res.status(404).json({ message: "Station not found" });
            }
            // Reinitialise sync service so it drops references to deleted station/configs
            try {
                await dropboxSyncService_1.dropboxSyncService.reinitialize();
            }
            catch (syncErr) {
                console.warn(`Failed to reinitialise sync service after deleting station ${stationId}:`, syncErr);
            }
            // Log station deletion
            await auditLogService_1.auditLog.log(auditLogService_1.AUDIT_ACTIONS.STATION_DELETE, 'stations', {
                userId: (0, localAuth_1.getUserId)(req),
                resourceId: stationId,
                ip: req.ip || req.socket.remoteAddress,
                status: 'success'
            });
            res.status(204).send();
        }
        catch (error) {
            console.error("Error deleting station:", error);
            res.status(500).json({ message: "Failed to delete station" });
        }
    });
    // Station image upload endpoint
    app.post("/api/stations/:id/image", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const { value: stationId, error } = parseIntSafe(req.params.id, 'id');
            if (error || stationId === null) {
                return res.status(400).json({ message: error });
            }
            const { image } = req.body;
            if (!image || typeof image !== 'string') {
                return res.status(400).json({ message: "Image data is required" });
            }
            // Validate that it's a valid base64 image
            const base64Regex = /^data:image\/(png|jpeg|jpg|gif|webp);base64,/;
            if (!base64Regex.test(image)) {
                return res.status(400).json({ message: "Invalid image format. Must be base64 encoded image." });
            }
            // Check image size (max 5MB after base64 encoding)
            const base64Data = image.split(',')[1];
            const imageSizeBytes = (base64Data.length * 3) / 4;
            if (imageSizeBytes > 5 * 1024 * 1024) {
                return res.status(400).json({ message: "Image too large. Maximum size is 5MB." });
            }
            const station = await localStorage_1.storage.updateStation(stationId, { stationImage: image });
            if (!station) {
                return res.status(404).json({ message: "Station not found" });
            }
            res.json({ success: true, message: "Station image updated" });
        }
        catch (error) {
            console.error("Error uploading station image:", error);
            res.status(500).json({ message: "Failed to upload station image" });
        }
    });
    // Delete station image endpoint
    app.delete("/api/stations/:id/image", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const { value: stationId, error } = parseIntSafe(req.params.id, 'id');
            if (error || stationId === null) {
                return res.status(400).json({ message: error });
            }
            const station = await localStorage_1.storage.updateStation(stationId, { stationImage: null });
            if (!station) {
                return res.status(404).json({ message: "Station not found" });
            }
            res.json({ success: true, message: "Station image removed" });
        }
        catch (error) {
            console.error("Error removing station image:", error);
            res.status(500).json({ message: "Failed to remove station image" });
        }
    });
    // User-Station routes
    app.get("/api/user/stations", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const userId = (0, localAuth_1.getUserId)(req);
            const stations = await localStorage_1.storage.getUserStations(userId);
            res.json(stations);
        }
        catch (error) {
            console.error("Error fetching user stations:", error);
            res.status(500).json({ message: "Failed to fetch user stations" });
        }
    });
    app.post("/api/user/stations", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const userId = (0, localAuth_1.getUserId)(req);
            const { stationId, isDefault } = req.body;
            const result = await localStorage_1.storage.addUserStation({
                userId,
                stationId
            });
            res.status(201).json(result);
        }
        catch (error) {
            console.error("Error adding user station:", error);
            res.status(500).json({ message: "Failed to add station" });
        }
    });
    app.delete("/api/user/stations/:stationId", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const userId = (0, localAuth_1.getUserId)(req);
            const { value: stationId, error } = parseIntSafe(req.params.stationId, 'stationId');
            if (error || stationId === null) {
                return res.status(400).json({ message: error });
            }
            const deleted = await localStorage_1.storage.removeUserStation(userId, stationId);
            if (!deleted) {
                return res.status(404).json({ message: "User station not found" });
            }
            res.status(204).send();
        }
        catch (error) {
            console.error("Error removing user station:", error);
            res.status(500).json({ message: "Failed to remove station" });
        }
    });
    app.patch("/api/user/stations/:stationId/default", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const userId = (0, localAuth_1.getUserId)(req);
            const { value: stationId, error } = parseIntSafe(req.params.stationId, 'stationId');
            if (error || stationId === null) {
                return res.status(400).json({ message: error });
            }
            const success = await localStorage_1.storage.setDefaultStation(userId, stationId);
            if (!success) {
                return res.status(404).json({ message: "User station not found" });
            }
            res.json({ success: true });
        }
        catch (error) {
            console.error("Error setting default station:", error);
            res.status(500).json({ message: "Failed to set default station" });
        }
    });
    // Weather Data routes (demo mode bypasses auth)
    app.get("/api/stations/:stationId/data/range", optionalAuth, async (req, res) => {
        try {
            const { value: stationId, error } = parseIntSafe(req.params.stationId, 'stationId');
            if (error || stationId === null) {
                return res.status(400).json({ message: error });
            }
            const result = await postgres.query('SELECT MIN(timestamp) as earliest, MAX(timestamp) as latest, COUNT(*) as count FROM weather_data WHERE station_id = $1', [stationId]);
            const row = result.rows[0];
            res.json({
                earliest: row.earliest,
                latest: row.latest,
                count: parseInt(row.count),
            });
        }
        catch (error) {
            console.error("Error fetching data range:", error);
            res.status(500).json({ message: "Failed to fetch data range" });
        }
    });
    // Rainfall yearly totals - auto-detects incremental vs cumulative loggers.
    //
    // CRBasic stations using PulseCount + Totalize (the standard pattern, e.g.
    //   PulseCount(Rain,1,12,2,0,0.1,0.0)
    //   Totalize(1,Rain,FP2,False)
    // ) emit INCREMENTAL rainfall: each row = mm of rain during that scan/output
    // interval. The correct yearly total is SUM(rainfall).
    //
    // Some loggers (older Vaisala WXT, Davis ISS reporting "rain accumulator",
    // RIKA cloud feeds) emit CUMULATIVE rainfall (running total). For those
    // SUM is wrong; the correct total is sum of positive deltas between
    // consecutive readings (handles midnight/monthly resets too).
    app.get("/api/stations/:stationId/data/rainfall-yearly", optionalAuth, async (req, res) => {
        try {
            const { value: stationId, error } = parseIntSafe(req.params.stationId, 'stationId');
            if (error || stationId === null) {
                return res.status(400).json({ message: error });
            }
            // Per-station rainfall offset (e.g. RIKA cumulative-since-erection).
            // Apply the SAME transform the client applies via mapToWeatherData so
            // monthly (client-side) and yearly (server-side) totals correlate.
            const { STATION_RAINFALL_OFFSETS } = await Promise.resolve().then(() => __importStar(require('./config/stationRainfallOffsets')));
            const rainfallOffset = STATION_RAINFALL_OFFSETS[stationId] || 0;
            // Rainfall field names in order of preference (stored in JSONB data column).
            // Incremental field names (*_Tot from CRBasic Totalize) are listed first.
            const rainfallFields = [
                "data->>'Rain_mm_Tot'", "data->>'Rain_Tot'", "data->>'Precip_Tot'",
                "data->>'Rain_1_Tot'", "data->>'Rain_Tot_1'",
                "data->>'rainfall'", "data->>'Rain_mm'", "data->>'Precip'",
                "data->>'Rain'", "data->>'Rainfall'"
            ];
            const coalesce = rainfallFields.join(', ');
            // Apply offset+clamp inline; for stations with no offset this is a no-op.
            const rainfallExpr = rainfallOffset > 0
                ? `GREATEST(0, COALESCE(${coalesce})::numeric - ${rainfallOffset})`
                : `COALESCE(${coalesce})::numeric`;
            const result = await postgres.query(`
        WITH rainfall_readings AS (
          SELECT
            EXTRACT(YEAR FROM timestamp) AS year,
            timestamp,
            ${rainfallExpr} AS rainfall_val,
            LAG(${rainfallExpr}) OVER (
              PARTITION BY EXTRACT(YEAR FROM timestamp)
              ORDER BY timestamp
            ) AS prev_val
          FROM weather_data
          WHERE station_id = $1
            AND COALESCE(${coalesce}) IS NOT NULL
        )
        SELECT
          year,
          COUNT(*) AS readings,
          MAX(rainfall_val) AS max_val,
          MIN(rainfall_val) AS min_val,
          -- Incremental sum: cap each individual reading to 100 mm (sane per-period max)
          SUM(CASE WHEN rainfall_val > 0 AND rainfall_val < 100 THEN rainfall_val ELSE 0 END) AS sum_total,
          -- Cumulative-handling: positive deltas only, capped to 100 mm per step (handles resets and spikes)
          SUM(CASE
            WHEN prev_val IS NOT NULL AND rainfall_val >= prev_val
              AND (rainfall_val - prev_val) < 100
            THEN rainfall_val - prev_val
            ELSE 0
          END) AS delta_sum,
          -- Distribution stats used to discriminate incremental vs cumulative
          COUNT(CASE WHEN rainfall_val = 0 THEN 1 END) AS zero_count,
          COUNT(CASE WHEN rainfall_val > 0 AND rainfall_val < 100 THEN 1 END) AS positive_count,
          AVG(CASE WHEN rainfall_val > 0 AND rainfall_val < 100 THEN rainfall_val END) AS mean_positive,
          COUNT(CASE WHEN prev_val IS NOT NULL AND rainfall_val > prev_val + 0.01 THEN 1 END) AS increase_count,
          COUNT(CASE WHEN prev_val IS NOT NULL AND rainfall_val < prev_val - 0.5 THEN 1 END) AS reset_count
        FROM rainfall_readings
        GROUP BY year
        HAVING COUNT(*) >= 2
        ORDER BY year DESC
        LIMIT 6
      `, [stationId]);
            const currentYear = new Date().getFullYear();
            const yearlyTotals = result.rows.map((row) => {
                const year = parseInt(row.year);
                const readings = parseInt(row.readings);
                const sumTotal = parseFloat(row.sum_total) || 0;
                const deltaSum = parseFloat(row.delta_sum) || 0;
                const resetCount = parseInt(row.reset_count) || 0;
                const maxVal = parseFloat(row.max_val) || 0;
                const zeroCount = parseInt(row.zero_count) || 0;
                const positiveCount = parseInt(row.positive_count) || 0;
                const increaseCount = parseInt(row.increase_count) || 0;
                const meanPositive = parseFloat(row.mean_positive) || 0;
                // Discriminate logger type using distribution shape:
                //  - INCREMENTAL (CRBasic Totalize / tipping bucket): most readings
                //    are 0 mm (no rain in scan), positive readings are small (mean < 20mm),
                //    values do not trend upward across the year.
                //  - CUMULATIVE (running total since session/midnight): values
                //    increase monotonically until a reset, max value is typically large.
                const zeroFraction = readings > 0 ? zeroCount / readings : 0;
                const increaseFraction = readings > 0 ? increaseCount / readings : 0;
                let total;
                let mode;
                if (zeroFraction >= 0.30 && meanPositive < 20 && maxVal < 100) {
                    mode = 'incremental';
                    total = sumTotal;
                }
                else if (increaseFraction >= 0.40 || maxVal >= 50 || resetCount > 0) {
                    mode = 'cumulative';
                    total = deltaSum;
                }
                else if (positiveCount === 0) {
                    mode = 'incremental';
                    total = 0;
                }
                else {
                    // Ambiguous; pick the smaller (more conservative) value to avoid
                    // gross over-reporting from misclassification.
                    mode = sumTotal <= deltaSum ? 'incremental' : 'cumulative';
                    total = Math.min(sumTotal, deltaSum);
                }
                // Final sanity clamp: cap unrealistic annual rainfall to 5000 mm
                // (highest recorded annual rainfall on Earth is ~12000 mm; 5000 mm
                // is a safe upper bound for almost all weather stations).
                if (total > 5000)
                    total = Math.min(deltaSum, sumTotal);
                if (total > 5000)
                    total = 0;
                return {
                    year,
                    total: Math.round(Math.max(0, total) * 10) / 10,
                    readings,
                    resetCount,
                    mode,
                    isCurrent: year === currentYear,
                };
            });
            res.json(yearlyTotals);
        }
        catch (error) {
            console.error("Error fetching rainfall yearly totals:", error);
            res.status(500).json({ message: "Failed to fetch rainfall data" });
        }
    });
    app.get("/api/stations/:stationId/data/latest", optionalAuth, async (req, res) => {
        try {
            const { value: stationId, error } = parseIntSafe(req.params.stationId, 'stationId');
            if (error || stationId === null) {
                return res.status(400).json({ message: error });
            }
            const data = await localStorage_1.storage.getLatestWeatherData(stationId);
            if (!data) {
                return res.status(404).json({ message: "No weather data found" });
            }
            res.json(data);
        }
        catch (error) {
            console.error("Error fetching latest weather data:", error);
            res.status(500).json({ message: "Failed to fetch weather data" });
        }
    });
    app.get("/api/stations/:stationId/data", optionalAuth, async (req, res) => {
        try {
            const { value: stationId, error } = parseIntSafe(req.params.stationId, 'stationId');
            if (error || stationId === null) {
                return res.status(400).json({ message: error });
            }
            const { startTime, endTime, limit } = req.query;
            if (!startTime || !endTime) {
                return res.status(400).json({ message: "startTime and endTime are required" });
            }
            let data = await localStorage_1.storage.getWeatherDataRange(stationId, new Date(startTime), new Date(endTime));
            const rawCount = data.length;
            // Server-side downsampling: if >maxPoints records, thin to evenly-spaced points
            // This prevents huge payloads while still providing sufficient chart resolution
            const maxPoints = limit ? parseInt(limit) : 500;
            if (data.length > maxPoints) {
                const step = data.length / maxPoints;
                const sampled = [];
                for (let i = 0; i < data.length; i += step) {
                    sampled.push(data[Math.floor(i)]);
                }
                // Always include the very last (most recent) record
                if (sampled[sampled.length - 1] !== data[data.length - 1]) {
                    sampled.push(data[data.length - 1]);
                }
                data = sampled;
            }
            // Log data pipeline info for debugging chart range issues
            const firstTs = data.length > 0 ? data[0].timestamp : null;
            const lastTs = data.length > 0 ? data[data.length - 1].timestamp : null;
            console.log(`[data] station=${stationId} raw=${rawCount} sent=${data.length} maxPts=${maxPoints} range=${firstTs}..${lastTs}`);
            res.json(data);
        }
        catch (error) {
            console.error("Error fetching weather data:", error);
            res.status(500).json({ message: "Failed to fetch weather data" });
        }
    });
    app.post("/api/stations/:stationId/data", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const { value: stationId, error } = parseIntSafe(req.params.stationId, 'stationId');
            if (error || stationId === null) {
                return res.status(400).json({ message: error });
            }
            const parsed = insertWeatherDataSchema.safeParse({
                ...req.body,
                stationId,
                timestamp: new Date(req.body.timestamp),
            });
            if (!parsed.success) {
                return res.status(400).json({ message: "Invalid weather data", errors: parsed.error.errors });
            }
            const data = await localStorage_1.storage.insertWeatherData({
                stationId,
                timestamp: parsed.data.timestamp,
                tableName: parsed.data.tableName || 'manual',
                data: parsed.data.data || {}
            });
            // Broadcast weather data update to all subscribed clients
            broadcastWeatherData(stationId, data);
            res.status(201).json(data);
        }
        catch (error) {
            console.error("Error inserting weather data:", error);
            res.status(500).json({ message: "Failed to insert weather data" });
        }
    });
    // PUBLIC DATA INGEST ENDPOINT FOR DATALOGGERS
    // This endpoint allows Campbell Scientific dataloggers and other devices to
    // POST weather data without authentication (uses station ID + optional API key)
    // 
    // POST /api/ingest/:stationId
    // Headers:
    //   Content-Type: application/json
    //   X-API-Key: optional API key for additional security
    // Body:
    //   { "data": { "temperature": 22.5, "humidity": 65, ... }, "timestamp": "ISO8601" }
    // Accepts both numeric station IDs and alphanumeric ingest IDs (e.g., "ST64ART3")
    app.post("/api/ingest/:stationId", ingestRateLimiter, async (req, res) => {
        try {
            const paramId = req.params.stationId;
            let station = null;
            let stationId = 0;
            // Try numeric ID first, then alphanumeric ingest ID
            const numericId = parseInt(paramId, 10);
            if (!isNaN(numericId) && String(numericId) === paramId) {
                station = await localStorage_1.storage.getStation(numericId);
                if (station) {
                    stationId = numericId;
                }
            }
            // If not found by numeric ID, try ingest ID
            if (!station) {
                station = await localStorage_1.storage.getStationByIngestId(paramId.toUpperCase());
                if (station) {
                    stationId = station.id;
                }
            }
            if (!station) {
                return res.status(404).json({
                    success: false,
                    message: "Station not found",
                    stationId: paramId
                });
            }
            // Optional API key validation (if station has apiKey configured)
            const providedKey = req.headers['x-api-key'];
            const stationConfig = station.connectionConfig;
            if (stationConfig?.apiKey && stationConfig.apiKey !== providedKey) {
                return res.status(401).json({
                    success: false,
                    message: "Invalid API key"
                });
            }
            // Parse and validate data
            const { data, timestamp, source } = req.body;
            if (!data || typeof data !== 'object') {
                return res.status(400).json({
                    success: false,
                    message: "Missing or invalid 'data' object"
                });
            }
            // Insert weather data
            const weatherData = await localStorage_1.storage.insertWeatherData({
                stationId,
                timestamp: timestamp ? new Date(timestamp) : new Date(),
                tableName: source || 'datalogger',
                data
            });
            // Broadcast to connected WebSocket clients
            broadcastWeatherData(stationId, weatherData);
            res.status(201).json({
                success: true,
                message: "Data received",
                id: weatherData.id,
                timestamp: weatherData.timestamp
            });
        }
        catch (error) {
            console.error("Error ingesting weather data:", error);
            res.status(500).json({
                success: false,
                message: "Failed to ingest weather data"
            });
        }
    });
    // File import endpoint for Campbell Scientific data files
    app.post("/api/stations/:stationId/import", optionalAuth, async (req, res) => {
        try {
            const { value: stationId, error } = parseIntSafe(req.params.stationId, 'stationId');
            if (error || stationId === null) {
                return res.status(400).json({ message: error });
            }
            const { content, filename } = req.body;
            if (!content) {
                return res.status(400).json({ message: "File content is required" });
            }
            const { parseDataFile, mapToWeatherData: _mapToWeatherData } = await Promise.resolve().then(() => __importStar(require("./parsers/campbellScientific")));
            const mapToWeatherData = _mapToWeatherData;
            const parsed = parseDataFile(content);
            if (parsed.errors.length > 0 && parsed.records.length === 0) {
                return res.status(400).json({
                    message: "Failed to parse file",
                    errors: parsed.errors
                });
            }
            // Import records into the database
            let importedCount = 0;
            const importErrors = [];
            for (const record of parsed.records) {
                try {
                    const weatherData = mapToWeatherData(record, parsed.units, parsed.headers);
                    // Only insert if we have some valid data
                    if (Object.values(weatherData).some(v => v !== null)) {
                        await localStorage_1.storage.insertWeatherData({
                            stationId,
                            timestamp: record.timestamp,
                            tableName: 'import',
                            data: {
                                temperature: weatherData.temperature ?? undefined,
                                humidity: weatherData.humidity ?? undefined,
                                pressure: weatherData.pressure ?? undefined,
                                windSpeed: weatherData.windSpeed ?? undefined,
                                windDirection: weatherData.windDirection ?? undefined,
                                windGust: weatherData.windGust ?? undefined,
                                solarRadiation: weatherData.solarRadiation ?? undefined,
                                rainfall: weatherData.rainfall ?? undefined,
                                dewPoint: weatherData.dewPoint ?? undefined,
                                soilTemperature: weatherData.soilTemperature ?? undefined,
                                soilMoisture: weatherData.soilMoisture ?? undefined,
                                batteryVoltage: weatherData.batteryVoltage ?? undefined,
                                panelTemperature: weatherData.panelTemperature ?? undefined,
                            }
                        });
                        importedCount++;
                    }
                }
                catch (err) {
                    importErrors.push(`Record ${record.recordNumber}: ${err.message}`);
                }
            }
            res.json({
                message: "File imported successfully",
                format: parsed.format,
                stationName: parsed.stationName,
                tableName: parsed.tableName,
                totalRecords: parsed.records.length,
                importedRecords: importedCount,
                errors: [...parsed.errors, ...importErrors],
            });
        }
        catch (error) {
            console.error("Error importing data file:", error);
            res.status(500).json({ message: "Failed to import file", error: error.message });
        }
    });
    // User Preferences routes
    app.get("/api/user/preferences", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const userId = (0, localAuth_1.getUserId)(req);
            const prefs = await localStorage_1.storage.getUserPreferences(userId);
            res.json(prefs || {});
        }
        catch (error) {
            console.error("Error fetching user preferences:", error);
            res.status(500).json({ message: "Failed to fetch preferences" });
        }
    });
    app.put("/api/user/preferences", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const userId = (0, localAuth_1.getUserId)(req);
            const parsed = insertUserPreferencesSchema.safeParse({
                ...req.body,
                userId,
            });
            if (!parsed.success) {
                return res.status(400).json({ message: "Invalid preferences", errors: parsed.error.errors });
            }
            const prefs = await localStorage_1.storage.upsertUserPreferences(parsed.data);
            res.json(prefs);
        }
        catch (error) {
            console.error("Error updating user preferences:", error);
            res.status(500).json({ message: "Failed to update preferences" });
        }
    });
    // NOTE: Station PATCH route is defined above with isAuthenticated middleware
    // Removed duplicate route here to avoid route conflict
    // Sensors routes
    app.get("/api/stations/:stationId/sensors", optionalAuth, async (req, res) => {
        try {
            const { value: stationId, error } = parseIntSafe(req.params.stationId, 'stationId');
            if (error || stationId === null) {
                return res.status(400).json({ message: error });
            }
            const sensors = await localStorage_1.storage.getSensors(stationId);
            res.json(sensors);
        }
        catch (error) {
            console.error("Error fetching sensors:", error);
            res.status(500).json({ message: "Failed to fetch sensors" });
        }
    });
    app.post("/api/stations/:stationId/sensors", optionalAuth, async (req, res) => {
        try {
            const { value: stationId, error } = parseIntSafe(req.params.stationId, 'stationId');
            if (error || stationId === null) {
                return res.status(400).json({ message: error });
            }
            const sensor = await localStorage_1.storage.createSensor({
                ...req.body,
                stationId,
            });
            res.status(201).json(sensor);
        }
        catch (error) {
            console.error("Error creating sensor:", error);
            res.status(500).json({ message: "Failed to create sensor" });
        }
    });
    // Station Logs routes
    app.get("/api/stations/:stationId/logs", optionalAuth, async (req, res) => {
        try {
            const { value: stationId, error } = parseIntSafe(req.params.stationId, 'stationId');
            if (error || stationId === null) {
                return res.status(400).json({ message: error });
            }
            const limit = req.query.limit ? parseInt(req.query.limit, 10) : 50;
            const logs = await localStorage_1.storage.getStationLogs(stationId, isNaN(limit) ? 50 : limit);
            res.json(logs);
        }
        catch (error) {
            console.error("Error fetching station logs:", error);
            res.status(500).json({ message: "Failed to fetch station logs" });
        }
    });
    app.post("/api/stations/:stationId/logs", optionalAuth, async (req, res) => {
        try {
            const { value: stationId, error } = parseIntSafe(req.params.stationId, 'stationId');
            if (error || stationId === null) {
                return res.status(400).json({ message: error });
            }
            const parsed = insertStationLogSchema.safeParse({
                ...req.body,
                stationId,
            });
            if (!parsed.success) {
                return res.status(400).json({ message: "Invalid log entry", errors: parsed.error.errors });
            }
            const log = await localStorage_1.storage.createStationLog({
                stationId,
                logType: parsed.data.logType || 'info',
                message: parsed.data.message || '',
                metadata: parsed.data.metadata
            });
            res.status(201).json(log);
        }
        catch (error) {
            console.error("Error creating station log:", error);
            res.status(500).json({ message: "Failed to create station log" });
        }
    });
    // Helper to check if user is admin of an organization
    async function isOrgAdmin(orgId, userId) {
        return await localStorage_1.storage.isOrganizationAdmin(orgId, userId);
    }
    // Helper to check if user is member of an organization
    async function isOrgMember(orgId, userId) {
        return await localStorage_1.storage.isOrganizationMember(orgId, userId);
    }
    // Organization routes
    app.get("/api/organizations", optionalAuth, async (req, res) => {
        try {
            if (DEMO_MODE) {
                const orgs = await localStorage_1.storage.getOrganizations();
                return res.json(orgs);
            }
            const userId = (0, localAuth_1.getUserId)(req);
            const orgs = await localStorage_1.storage.getUserOrganizations(userId);
            res.json(orgs);
        }
        catch (error) {
            console.error("Error fetching organizations:", error);
            res.status(500).json({ message: "Failed to fetch organisations" });
        }
    });
    app.get("/api/organizations/:id", optionalAuth, async (req, res) => {
        try {
            const { value: orgId, error } = parseIntSafe(req.params.id, 'id');
            if (error || orgId === null) {
                return res.status(400).json({ message: error });
            }
            const org = await localStorage_1.storage.getOrganization(orgId);
            if (!org) {
                return res.status(404).json({ message: "Organisation not found" });
            }
            // Check membership unless demo mode
            if (!DEMO_MODE) {
                const userId = (0, localAuth_1.getUserId)(req);
                if (!(await isOrgMember(orgId, userId))) {
                    return res.status(403).json({ message: "Access denied" });
                }
            }
            res.json(org);
        }
        catch (error) {
            console.error("Error fetching organization:", error);
            res.status(500).json({ message: "Failed to fetch organisation" });
        }
    });
    app.post("/api/organizations", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const userId = (0, localAuth_1.getUserId)(req);
            const { name, description } = req.body;
            if (!name || typeof name !== 'string' || name.trim().length === 0) {
                return res.status(400).json({ message: "Organisation name is required" });
            }
            const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
            const parsed = insertOrganizationSchema.safeParse({
                name: name.trim(),
                description: description?.trim() || null,
                ownerId: userId,
                slug,
            });
            if (!parsed.success) {
                return res.status(400).json({ message: "Invalid organisation data", errors: parsed.error.errors });
            }
            const org = await localStorage_1.storage.createOrganization(parsed.data);
            // Add owner as admin member
            await localStorage_1.storage.addOrganizationMember({
                organizationId: org.id,
                userId,
                role: "admin",
                status: "active",
            });
            res.status(201).json(org);
        }
        catch (error) {
            console.error("Error creating organization:", error);
            res.status(500).json({ message: "Failed to create organisation" });
        }
    });
    app.patch("/api/organizations/:id", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const userId = (0, localAuth_1.getUserId)(req);
            const { value: orgId, error } = parseIntSafe(req.params.id, 'id');
            if (error || orgId === null) {
                return res.status(400).json({ message: error });
            }
            // Only admins can update organization
            if (!(await isOrgAdmin(orgId, userId))) {
                return res.status(403).json({ message: "Only organisation admins can update organisation" });
            }
            // Only allow updating specific fields
            const { name, description, logoUrl } = req.body;
            const updateData = {};
            if (name)
                updateData.name = name.trim();
            if (description !== undefined)
                updateData.description = description?.trim() || null;
            if (logoUrl !== undefined)
                updateData.logoUrl = logoUrl || null;
            const org = await localStorage_1.storage.updateOrganization(orgId, updateData);
            if (!org) {
                return res.status(404).json({ message: "Organisation not found" });
            }
            res.json(org);
        }
        catch (error) {
            console.error("Error updating organization:", error);
            res.status(500).json({ message: "Failed to update organisation" });
        }
    });
    app.delete("/api/organizations/:id", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const userId = (0, localAuth_1.getUserId)(req);
            const { value: orgId, error } = parseIntSafe(req.params.id, 'id');
            if (error || orgId === null) {
                return res.status(400).json({ message: error });
            }
            // Only owner can delete organization
            const org = await localStorage_1.storage.getOrganization(orgId);
            if (!org) {
                return res.status(404).json({ message: "Organisation not found" });
            }
            if (org.ownerId !== userId) {
                return res.status(403).json({ message: "Only the organisation owner can delete it" });
            }
            await localStorage_1.storage.deleteOrganization(orgId);
            res.status(204).send();
        }
        catch (error) {
            console.error("Error deleting organization:", error);
            res.status(500).json({ message: "Failed to delete organisation" });
        }
    });
    // Organization Members routes
    app.get("/api/organizations/:orgId/members", optionalAuth, async (req, res) => {
        try {
            const { value: orgId, error } = parseIntSafe(req.params.orgId, 'orgId');
            if (error || orgId === null) {
                return res.status(400).json({ message: error });
            }
            // Check membership unless demo mode
            if (!DEMO_MODE) {
                const userId = (0, localAuth_1.getUserId)(req);
                if (!(await isOrgMember(orgId, userId))) {
                    return res.status(403).json({ message: "Access denied" });
                }
            }
            const members = await localStorage_1.storage.getOrganizationMembers(orgId);
            res.json(members);
        }
        catch (error) {
            console.error("Error fetching organization members:", error);
            res.status(500).json({ message: "Failed to fetch members" });
        }
    });
    app.post("/api/organizations/:orgId/members", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const userId = (0, localAuth_1.getUserId)(req);
            const { value: orgId, error } = parseIntSafe(req.params.orgId, 'orgId');
            if (error || orgId === null) {
                return res.status(400).json({ message: error });
            }
            // Only admins can add members directly
            if (!(await isOrgAdmin(orgId, userId))) {
                return res.status(403).json({ message: "Only organisation admins can add members" });
            }
            const { userId: targetUserId, role } = req.body;
            if (!targetUserId || !['admin', 'member', 'viewer'].includes(role)) {
                return res.status(400).json({ message: "Invalid member data" });
            }
            const member = await localStorage_1.storage.addOrganizationMember({
                organizationId: orgId,
                userId: targetUserId,
                role,
                status: "active",
                invitedBy: userId,
            });
            res.status(201).json(member);
        }
        catch (error) {
            console.error("Error adding organization member:", error);
            res.status(500).json({ message: "Failed to add member" });
        }
    });
    app.patch("/api/organizations/:orgId/members/:userId/role", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const currentUserId = (0, localAuth_1.getUserId)(req);
            const { value: orgId, error } = parseIntSafe(req.params.orgId, 'orgId');
            if (error || orgId === null) {
                return res.status(400).json({ message: error });
            }
            const targetUserId = req.params.userId;
            // Only admins can update roles
            if (!(await isOrgAdmin(orgId, currentUserId))) {
                return res.status(403).json({ message: "Only organisation admins can update roles" });
            }
            const { role } = req.body;
            if (!['admin', 'member', 'viewer'].includes(role)) {
                return res.status(400).json({ message: "Invalid role. Must be admin, member, or viewer" });
            }
            const member = await localStorage_1.storage.updateMemberRole(orgId, targetUserId, role);
            if (!member) {
                return res.status(404).json({ message: "Member not found" });
            }
            res.json(member);
        }
        catch (error) {
            console.error("Error updating member role:", error);
            res.status(500).json({ message: "Failed to update member role" });
        }
    });
    app.delete("/api/organizations/:orgId/members/:userId", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const currentUserId = (0, localAuth_1.getUserId)(req);
            const { value: orgId, error } = parseIntSafe(req.params.orgId, 'orgId');
            if (error || orgId === null) {
                return res.status(400).json({ message: error });
            }
            const targetUserId = req.params.userId;
            // Only admins can remove members (or user can remove themselves)
            if (targetUserId !== currentUserId && !(await isOrgAdmin(orgId, currentUserId))) {
                return res.status(403).json({ message: "Only organisation admins can remove members" });
            }
            // Prevent owner from being removed
            const org = await localStorage_1.storage.getOrganization(orgId);
            if (org && org.ownerId === targetUserId) {
                return res.status(400).json({ message: "Cannot remove the organisation owner" });
            }
            const removed = await localStorage_1.storage.removeOrganizationMember(orgId, targetUserId);
            if (!removed) {
                return res.status(404).json({ message: "Member not found" });
            }
            res.status(204).send();
        }
        catch (error) {
            console.error("Error removing organization member:", error);
            res.status(500).json({ message: "Failed to remove member" });
        }
    });
    // Organization Invitations routes
    app.get("/api/organizations/:orgId/invitations", optionalAuth, async (req, res) => {
        try {
            const { value: orgId, error } = parseIntSafe(req.params.orgId, 'orgId');
            if (error || orgId === null) {
                return res.status(400).json({ message: error });
            }
            // Check membership unless demo mode
            if (!DEMO_MODE) {
                const userId = (0, localAuth_1.getUserId)(req);
                if (!(await isOrgMember(orgId, userId))) {
                    return res.status(403).json({ message: "Access denied" });
                }
            }
            const invitations = await localStorage_1.storage.getOrganizationInvitations(orgId);
            res.json(invitations);
        }
        catch (error) {
            console.error("Error fetching invitations:", error);
            res.status(500).json({ message: "Failed to fetch invitations" });
        }
    });
    app.post("/api/organizations/:orgId/invitations", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const userId = (0, localAuth_1.getUserId)(req);
            const { value: orgId, error } = parseIntSafe(req.params.orgId, 'orgId');
            if (error || orgId === null) {
                return res.status(400).json({ message: error });
            }
            // Only admins can create invitations
            if (!(await isOrgAdmin(orgId, userId))) {
                return res.status(403).json({ message: "Only organisation admins can send invitations" });
            }
            const { email, role } = req.body;
            if (!email || typeof email !== 'string' || !email.includes('@')) {
                return res.status(400).json({ message: "Valid email address is required" });
            }
            const validRole = ['admin', 'member', 'viewer'].includes(role) ? role : 'member';
            const token = (0, nanoid_1.nanoid)(32);
            const expiresAt = new Date();
            expiresAt.setDate(expiresAt.getDate() + 7); // Expires in 7 days
            const invitation = await localStorage_1.storage.createInvitation({
                organizationId: orgId,
                email: email.toLowerCase().trim(),
                role: validRole,
                token,
                invitedBy: userId,
                expiresAt,
            });
            res.status(201).json(invitation);
        }
        catch (error) {
            console.error("Error creating invitation:", error);
            res.status(500).json({ message: "Failed to create invitation" });
        }
    });
    app.get("/api/invitations/:token", async (req, res) => {
        try {
            const invitation = await localStorage_1.storage.getInvitationByToken(req.params.token);
            if (!invitation) {
                return res.status(404).json({ message: "Invitation not found" });
            }
            if (invitation.acceptedAt) {
                return res.status(400).json({ message: "Invitation already accepted" });
            }
            if (new Date() > invitation.expiresAt) {
                return res.status(400).json({ message: "Invitation expired" });
            }
            const org = await localStorage_1.storage.getOrganization(invitation.organizationId);
            res.json({ invitation, organization: org });
        }
        catch (error) {
            console.error("Error fetching invitation:", error);
            res.status(500).json({ message: "Failed to fetch invitation" });
        }
    });
    app.post("/api/invitations/:token/accept", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const userId = (0, localAuth_1.getUserId)(req);
            const accepted = await localStorage_1.storage.acceptInvitation(req.params.token, userId);
            if (!accepted) {
                return res.status(400).json({ message: "Failed to accept invitation" });
            }
            res.json({ message: "Invitation accepted successfully" });
        }
        catch (error) {
            console.error("Error accepting invitation:", error);
            res.status(500).json({ message: "Failed to accept invitation" });
        }
    });
    // Alarms now use persistent database storage (Issue #10 fix)
    // The storage layer wraps db.ts alarm functions
    // Alarms routes
    app.get("/api/alarms", optionalAuth, async (req, res) => {
        try {
            const stationId = req.query.stationId ? parseInt(req.query.stationId, 10) : undefined;
            let userAlarms;
            if (stationId && !isNaN(stationId)) {
                userAlarms = await localStorage_1.storage.getAlarms(stationId);
            }
            else {
                userAlarms = await localStorage_1.storage.getAllAlarms();
            }
            res.json(userAlarms.map(mapAlarmToClient));
        }
        catch (error) {
            console.error("Error fetching alarms:", error);
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            res.status(500).json({ message: "Failed to fetch alarms", details: errorMessage });
        }
    });
    app.post("/api/alarms", optionalAuth, async (req, res) => {
        try {
            // Validate alarm data using Zod schema
            const parsed = insertAlarmSchema.safeParse(req.body);
            if (!parsed.success) {
                return res.status(400).json({
                    message: "Invalid alarm data",
                    errors: parsed.error.errors
                });
            }
            const { stationId, name, parameter, condition, threshold, staleMinutes, unit, enabled, notifyEmail, notifyPush } = parsed.data;
            // Get the current user's email for notifications
            let emailRecipients = null;
            if (notifyEmail && req.user) {
                emailRecipients = req.user.email || null;
            }
            const alarm = await localStorage_1.storage.createAlarm({
                stationId,
                name: name || parameter,
                parameter,
                condition,
                threshold,
                staleMinutes: condition === 'stale' ? (staleMinutes || 120) : undefined,
                unit: unit || '',
                severity: 'warning',
                isEnabled: enabled !== false,
                emailNotifications: notifyEmail !== false,
                emailRecipients,
            });
            res.status(201).json(mapAlarmToClient(alarm));
        }
        catch (error) {
            console.error("Error creating alarm:", error);
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            res.status(500).json({ message: "Failed to create alarm", details: errorMessage });
        }
    });
    app.patch("/api/alarms/:id", optionalAuth, async (req, res) => {
        try {
            const { value: alarmId, error } = parseIntSafe(req.params.id, 'id');
            if (error || alarmId === null) {
                return res.status(400).json({ message: error });
            }
            const existingAlarm = await localStorage_1.storage.getAlarm(alarmId);
            if (!existingAlarm) {
                return res.status(404).json({ message: `Alarm with id ${alarmId} not found` });
            }
            const updated = await localStorage_1.storage.updateAlarm(alarmId, req.body);
            res.json(updated ? mapAlarmToClient(updated) : null);
        }
        catch (error) {
            console.error("Error updating alarm:", error);
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            res.status(500).json({ message: "Failed to update alarm", details: errorMessage });
        }
    });
    app.delete("/api/alarms/:id", optionalAuth, async (req, res) => {
        try {
            const { value: alarmId, error } = parseIntSafe(req.params.id, 'id');
            if (error || alarmId === null) {
                return res.status(400).json({ message: error });
            }
            const existingAlarm = await localStorage_1.storage.getAlarm(alarmId);
            if (!existingAlarm) {
                return res.status(404).json({ message: `Alarm with id ${alarmId} not found` });
            }
            await localStorage_1.storage.deleteAlarm(alarmId);
            res.status(204).send();
        }
        catch (error) {
            console.error("Error deleting alarm:", error);
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            res.status(500).json({ message: "Failed to delete alarm", details: errorMessage });
        }
    });
    // Alarm events routes
    app.get("/api/alarm-events", optionalAuth, async (req, res) => {
        try {
            const stationId = req.query.stationId ? parseInt(req.query.stationId, 10) : undefined;
            const alarmId = req.query.alarmId ? parseInt(req.query.alarmId, 10) : undefined;
            const limit = req.query.limit ? parseInt(req.query.limit, 10) : 100;
            const events = await localStorage_1.storage.getAlarmEvents(alarmId, stationId, limit);
            res.json(events);
        }
        catch (error) {
            console.error("Error fetching alarm events:", error);
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            res.status(500).json({ message: "Failed to fetch alarm events", details: errorMessage });
        }
    });
    app.post("/api/alarm-events/:id/acknowledge", optionalAuth, async (req, res) => {
        try {
            const { value: eventId, error } = parseIntSafe(req.params.id, 'id');
            if (error || eventId === null) {
                return res.status(400).json({ message: error });
            }
            const userId = DEMO_MODE ? "demo" : (0, localAuth_1.getUserId)(req);
            const result = await localStorage_1.storage.acknowledgeAlarmEvent(eventId, userId, req.body.notes);
            res.json(result);
        }
        catch (error) {
            console.error("Error acknowledging alarm event:", error);
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            res.status(500).json({ message: "Failed to acknowledge alarm event", details: errorMessage });
        }
    });
    // Delete a single alarm event
    app.delete("/api/alarm-events/:id", optionalAuth, async (req, res) => {
        try {
            const { value: eventId, error } = parseIntSafe(req.params.id, 'id');
            if (error || eventId === null) {
                return res.status(400).json({ message: error });
            }
            await localStorage_1.storage.deleteAlarmEvent(eventId);
            res.json({ success: true, message: "Alarm event deleted" });
        }
        catch (error) {
            console.error("Error deleting alarm event:", error);
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            res.status(500).json({ message: "Failed to delete alarm event", details: errorMessage });
        }
    });
    // Cleanup alarm events older than 30 days
    app.post("/api/alarm-events/cleanup", optionalAuth, async (req, res) => {
        try {
            const days = req.body.days || 30;
            const count = await localStorage_1.storage.cleanupOldAlarmEvents(days);
            res.json({ success: true, deleted: count, message: `Cleaned up ${count} events older than ${days} days` });
        }
        catch (error) {
            console.error("Error cleaning up alarm events:", error);
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            res.status(500).json({ message: "Failed to cleanup alarm events", details: errorMessage });
        }
    });
    // Documentation download routes
    const docsDir = path_1.default.join(__dirname, '..', 'docs');
    app.get("/api/docs", async (req, res) => {
        try {
            const docs = [
                {
                    id: 'user-guide',
                    name: 'Stratus Weather Server - Complete User Guide',
                    filename: 'Stratus-Complete-User-Guide.pdf',
                    description: 'Complete guide covering features, capabilities, station setup, and configuration'
                }
            ];
            // Check which PDFs exist
            const availableDocs = docs.map(doc => {
                const filePath = path_1.default.join(docsDir, doc.filename);
                const exists = fs_1.default.existsSync(filePath);
                let size = 0;
                if (exists) {
                    const stats = fs_1.default.statSync(filePath);
                    size = stats.size;
                }
                return { ...doc, available: exists, size };
            });
            res.json(availableDocs);
        }
        catch (error) {
            console.error("Error listing documentation:", error);
            res.status(500).json({ message: "Failed to list documentation" });
        }
    });
    app.get("/api/docs/:docId/download", async (req, res) => {
        try {
            const { docId } = req.params;
            const docMap = {
                'user-guide': 'Stratus-Complete-User-Guide.pdf'
            };
            const filename = docMap[docId];
            if (!filename) {
                return res.status(404).json({ message: "Document not found" });
            }
            const filePath = path_1.default.join(docsDir, filename);
            if (!fs_1.default.existsSync(filePath)) {
                return res.status(404).json({
                    message: "PDF not generated yet. Run 'npm run docs:pdf' to generate documentation."
                });
            }
            res.setHeader('Content-Type', 'application/pdf');
            res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
            const fileStream = fs_1.default.createReadStream(filePath);
            fileStream.pipe(res);
        }
        catch (error) {
            console.error("Error downloading documentation:", error);
            res.status(500).json({ message: "Failed to download documentation" });
        }
    });
    // Audit Log API Routes (Admin Only)
    /**
     * GET /api/audit-logs
     * Retrieve audit logs for admin review
     */
    app.get("/api/audit-logs", localAuth_1.isAuthenticated, localAuth_1.isAdmin, async (req, res) => {
        try {
            const { action, userId, resource, startDate, endDate, status, limit } = req.query;
            const logs = await auditLogService_1.auditLog.searchLogs({
                action: action,
                userId: userId,
                resource: resource,
                startDate: startDate,
                endDate: endDate,
                status: status,
            }, limit ? parseInt(limit, 10) : 500);
            res.json(logs);
        }
        catch (error) {
            console.error("Error fetching audit logs:", error);
            res.status(500).json({ message: "Failed to fetch audit logs" });
        }
    });
    /**
     * GET /api/audit-logs/recent
     * Get recent audit logs from memory (faster for dashboards)
     */
    app.get("/api/audit-logs/recent", localAuth_1.isAuthenticated, localAuth_1.isAdmin, async (req, res) => {
        try {
            const limit = req.query.limit ? parseInt(req.query.limit, 10) : 100;
            const logs = auditLogService_1.auditLog.getRecentLogs(limit);
            res.json(logs);
        }
        catch (error) {
            console.error("Error fetching recent audit logs:", error);
            res.status(500).json({ message: "Failed to fetch recent audit logs" });
        }
    });
    /**
     * GET /api/audit-logs/user/:userId
     * Get audit logs for a specific user
     */
    app.get("/api/audit-logs/user/:userId", localAuth_1.isAuthenticated, localAuth_1.isAdmin, async (req, res) => {
        try {
            const { userId } = req.params;
            const days = req.query.days ? parseInt(req.query.days, 10) : 30;
            const logs = await auditLogService_1.auditLog.getLogsForUser(userId, days);
            res.json(logs);
        }
        catch (error) {
            console.error("Error fetching user audit logs:", error);
            res.status(500).json({ message: "Failed to fetch user audit logs" });
        }
    });
    // Public Embed/Widget API (CORS enabled, read-only)
    // These endpoints provide READ-ONLY access to weather data
    // They do NOT expose any admin functions, user accounts, or configuration
    // Rate limiter for embed API to prevent abuse
    const embedRateLimiter = (0, express_rate_limit_1.default)({
        windowMs: 1 * 60 * 1000, // 1 minute
        max: 120, // 120 requests per minute per IP
        message: { success: false, message: 'Too many requests, please try again later' },
        standardHeaders: true,
        legacyHeaders: false,
    });
    // Middleware to set CORS headers and validate embed access
    const embedCorsMiddleware = (req, res, next) => {
        // Allow all origins for widget embedding
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Embed-Key');
        // Block access to sensitive headers that could expose internal info
        res.removeHeader('X-Powered-By');
        next();
    };
    /**
     * GET /api/embed/stations
     * Public endpoint to get list of stations for embedding
     * Returns ONLY public station info (no config, credentials, or admin data)
     */
    app.get("/api/embed/stations", embedRateLimiter, embedCorsMiddleware, async (req, res) => {
        try {
            const stations = await localStorage_1.storage.getStations();
            // Return minimal public data
            const publicStations = stations.map((s) => ({
                id: s.id,
                name: s.name,
                latitude: s.latitude,
                longitude: s.longitude,
                altitude: s.altitude,
                status: s.isActive ? 'online' : 'offline'
            }));
            res.json(publicStations);
        }
        catch (error) {
            console.error("Error fetching embed stations:", error);
            res.status(500).json({ message: "Failed to fetch stations" });
        }
    });
    /**
     * GET /api/embed/station/:id
     * Public endpoint to get station details and latest data for embedding
     * Returns ONLY weather data - no configuration, credentials, or admin info
     */
    app.get("/api/embed/station/:id", embedRateLimiter, embedCorsMiddleware, async (req, res) => {
        try {
            const stationId = parseInt(req.params.id, 10);
            if (isNaN(stationId)) {
                return res.status(400).json({ message: "Invalid station ID" });
            }
            const station = await localStorage_1.storage.getStation(stationId);
            if (!station) {
                return res.status(404).json({ message: "Station not found" });
            }
            // Get latest weather data (last 24 hours)
            const now = new Date();
            const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000);
            const weatherData = await localStorage_1.storage.getWeatherDataRange(stationId, yesterday, now);
            // Get latest record
            const latest = weatherData.length > 0 ? weatherData[weatherData.length - 1] : null;
            res.json({
                station: {
                    id: station.id,
                    name: station.name,
                    latitude: station.latitude,
                    longitude: station.longitude,
                    altitude: station.altitude,
                    status: station.isActive ? 'online' : 'offline'
                },
                latest: latest ? {
                    timestamp: latest.timestamp,
                    temperature: latest.temperature,
                    humidity: latest.humidity,
                    pressure: latest.pressure,
                    windSpeed: latest.windSpeed,
                    windDirection: latest.windDirection,
                    rainfall: latest.rainfall,
                    solarRadiation: latest.solarRadiation,
                    batteryVoltage: latest.batteryVoltage
                } : null,
                recordCount: weatherData.length
            });
        }
        catch (error) {
            console.error("Error fetching embed station:", error);
            res.status(500).json({ message: "Failed to fetch station data" });
        }
    });
    /**
     * GET /api/embed/station/:id/data
     * Public endpoint to get weather data for a station (for charts)
     * Returns ONLY historical weather readings - no admin data
     */
    app.get("/api/embed/station/:id/data", embedRateLimiter, embedCorsMiddleware, async (req, res) => {
        try {
            const stationId = parseInt(req.params.id, 10);
            if (isNaN(stationId)) {
                return res.status(400).json({ message: "Invalid station ID" });
            }
            const hours = parseInt(req.query.hours, 10) || 24;
            const station = await localStorage_1.storage.getStation(stationId);
            if (!station) {
                return res.status(404).json({ message: "Station not found" });
            }
            const now = new Date();
            const start = new Date(now.getTime() - hours * 60 * 60 * 1000);
            const weatherData = await localStorage_1.storage.getWeatherDataRange(stationId, start, now);
            // Return minimal data for charts
            const chartData = weatherData.map((d) => ({
                t: d.timestamp,
                temp: d.temperature,
                hum: d.humidity,
                pres: d.pressure,
                wind: d.windSpeed,
                windDir: d.windDirection,
                rain: d.rainfall,
                solar: d.solarRadiation,
                batt: d.batteryVoltage
            }));
            res.json({
                stationId,
                stationName: station.name,
                data: chartData
            });
        }
        catch (error) {
            console.error("Error fetching embed data:", error);
            res.status(500).json({ message: "Failed to fetch weather data" });
        }
    });
    /**
     * GET /api/embed/widget.js
     * Serve the embeddable widget JavaScript
     * This widget can ONLY display weather data - it cannot access admin functions
     */
    app.get("/api/embed/widget.js", embedRateLimiter, (req, res) => {
        res.setHeader('Content-Type', 'application/javascript');
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Cache-Control', 'public, max-age=3600');
        const widgetScript = `
/**
 * Stratus Weather Widget
 * Embed weather station data on any website
 * Usage: <div id="stratus-widget" data-station="1" data-server="https://your-stratus-server.com"></div>
 *        <script src="https://your-stratus-server.com/api/embed/widget.js"></script>
 */
(function() {
  'use strict';
  
  const StratusWidget = {
    version: '1.3.1',
    
    styles: \`
      .stratus-widget {
        font-family: Arial, Helvetica, sans-serif;
        background: #ffffff;
        border: 1px solid #e5e7eb;
        border-radius: 8px;
        padding: 16px;
        max-width: 400px;
        color: #000000;
      }
      .stratus-widget-dark {
        background: #1f2937;
        border-color: #374151;
        color: #ffffff;
      }
      .stratus-widget-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 12px;
        padding-bottom: 12px;
        border-bottom: 1px solid #e5e7eb;
      }
      .stratus-widget-dark .stratus-widget-header {
        border-bottom-color: #374151;
      }
      .stratus-widget-title {
        font-size: 16px;
        font-weight: 600;
        margin: 0;
      }
      .stratus-widget-status {
        font-size: 12px;
        padding: 2px 8px;
        border-radius: 9999px;
        background: #dcfce7;
        color: #166534;
      }
      .stratus-widget-status.offline {
        background: #fee2e2;
        color: #991b1b;
      }
      .stratus-widget-dark .stratus-widget-status {
        background: #166534;
        color: #dcfce7;
      }
      .stratus-widget-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 12px;
      }
      .stratus-widget-item {
        padding: 8px;
        background: #f9fafb;
        border-radius: 6px;
      }
      .stratus-widget-dark .stratus-widget-item {
        background: #374151;
      }
      .stratus-widget-label {
        font-size: 11px;
        color: #6b7280;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 4px;
      }
      .stratus-widget-dark .stratus-widget-label {
        color: #9ca3af;
      }
      .stratus-widget-value {
        font-size: 20px;
        font-weight: 600;
      }
      .stratus-widget-unit {
        font-size: 12px;
        font-weight: 400;
        color: #6b7280;
      }
      .stratus-widget-dark .stratus-widget-unit {
        color: #9ca3af;
      }
      .stratus-widget-footer {
        margin-top: 12px;
        padding-top: 12px;
        border-top: 1px solid #e5e7eb;
        font-size: 11px;
        color: #6b7280;
        display: flex;
        justify-content: space-between;
      }
      .stratus-widget-dark .stratus-widget-footer {
        border-top-color: #374151;
        color: #9ca3af;
      }
      .stratus-widget-error {
        padding: 16px;
        text-align: center;
        color: #991b1b;
      }
      .stratus-widget-loading {
        padding: 32px;
        text-align: center;
        color: #6b7280;
      }
    \`,
    
    formatValue: function(value, decimals) {
      if (value === null || value === undefined) return '--';
      return Number(value).toFixed(decimals || 1);
    },
    
    formatTimestamp: function(ts) {
      if (!ts) return '--';
      const date = new Date(ts);
      return date.toLocaleString();
    },
    
    getWindDirection: function(deg) {
      if (deg === null || deg === undefined) return '--';
      const dirs = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'];
      return dirs[Math.round(deg / 22.5) % 16];
    },
    
    render: function(container, data, options) {
      const dark = options.theme === 'dark';
      const latest = data.latest || {};
      
      container.innerHTML = \`
        <div class="stratus-widget \${dark ? 'stratus-widget-dark' : ''}">
          <div class="stratus-widget-header">
            <h3 class="stratus-widget-title">\${data.station?.name || 'Weather Station'}</h3>
            <span class="stratus-widget-status \${data.station?.status !== 'online' ? 'offline' : ''}">\${data.station?.status || 'Unknown'}</span>
          </div>
          <div class="stratus-widget-grid">
            <div class="stratus-widget-item">
              <div class="stratus-widget-label">Temperature</div>
              <div class="stratus-widget-value">\${this.formatValue(latest.temperature)}<span class="stratus-widget-unit">°C</span></div>
            </div>
            <div class="stratus-widget-item">
              <div class="stratus-widget-label">Humidity</div>
              <div class="stratus-widget-value">\${this.formatValue(latest.humidity, 0)}<span class="stratus-widget-unit">%</span></div>
            </div>
            <div class="stratus-widget-item">
              <div class="stratus-widget-label">Pressure</div>
              <div class="stratus-widget-value">\${this.formatValue(latest.pressure, 0)}<span class="stratus-widget-unit">hPa</span></div>
            </div>
            <div class="stratus-widget-item">
              <div class="stratus-widget-label">Wind</div>
              <div class="stratus-widget-value">\${this.formatValue(latest.windSpeed)}<span class="stratus-widget-unit">m/s \${this.getWindDirection(latest.windDirection)}</span></div>
            </div>
            \${options.showRain !== false ? \`
            <div class="stratus-widget-item">
              <div class="stratus-widget-label">Rainfall</div>
              <div class="stratus-widget-value">\${this.formatValue(latest.rainfall)}<span class="stratus-widget-unit">mm</span></div>
            </div>
            \` : ''}
            \${options.showSolar !== false && latest.solarRadiation !== undefined ? \`
            <div class="stratus-widget-item">
              <div class="stratus-widget-label">Solar</div>
              <div class="stratus-widget-value">\${this.formatValue(latest.solarRadiation, 0)}<span class="stratus-widget-unit">W/m²</span></div>
            </div>
            \` : ''}
          </div>
          <div class="stratus-widget-footer">
            <span>Updated: \${this.formatTimestamp(latest.timestamp)}</span>
            <span>Powered by Stratus</span>
          </div>
        </div>
      \`;
    },
    
    renderError: function(container, message) {
      container.innerHTML = \`
        <div class="stratus-widget">
          <div class="stratus-widget-error">\${message}</div>
        </div>
      \`;
    },
    
    renderLoading: function(container) {
      container.innerHTML = \`
        <div class="stratus-widget">
          <div class="stratus-widget-loading">Loading weather data...</div>
        </div>
      \`;
    },
    
    init: function(container, options) {
      const self = this;
      options = options || {};
      
      // Inject styles if not already done
      if (!document.getElementById('stratus-widget-styles')) {
        const styleEl = document.createElement('style');
        styleEl.id = 'stratus-widget-styles';
        styleEl.textContent = this.styles;
        document.head.appendChild(styleEl);
      }
      
      this.renderLoading(container);
      
      const server = options.server || container.dataset.server || window.location.origin;
      const stationId = options.station || container.dataset.station;
      
      if (!stationId) {
        this.renderError(container, 'No station ID specified');
        return;
      }
      
      fetch(server + '/api/embed/station/' + stationId)
        .then(function(res) {
          if (!res.ok) throw new Error('Failed to fetch data');
          return res.json();
        })
        .then(function(data) {
          self.render(container, data, options);
          
          // Auto-refresh every 5 minutes
          if (options.autoRefresh !== false) {
            setInterval(function() {
              fetch(server + '/api/embed/station/' + stationId)
                .then(function(res) { return res.json(); })
                .then(function(data) { self.render(container, data, options); })
                .catch(function() {});
            }, (options.refreshInterval || 300) * 1000);
          }
        })
        .catch(function(err) {
          self.renderError(container, 'Unable to load weather data');
        });
    }
  };
  
  // Auto-Initialise widgets on page load
  function initWidgets() {
    var widgets = document.querySelectorAll('[data-stratus-widget], #stratus-widget, .stratus-widget-container');
    widgets.forEach(function(el) {
      StratusWidget.init(el, {
        theme: el.dataset.theme,
        showRain: el.dataset.showRain !== 'false',
        showSolar: el.dataset.showSolar !== 'false'
      });
    });
  }
  
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initWidgets);
  } else {
    initWidgets();
  }
  
  // Expose globally for manual Initialisation
  window.StratusWidget = StratusWidget;
})();
`;
        res.send(widgetScript);
    });
    // Handle OPTIONS for CORS preflight on embed endpoints
    app.options("/api/embed/*", embedCorsMiddleware, (req, res) => {
        res.status(204).send();
    });
    return httpServer;
}
