/**
 * Local Authentication Module
 * Multi-user authentication with database-backed user storage
 *
 * Features:
 * - Database-backed user authentication
 * - Secure password hashing with bcrypt
 * - Session management
 * - Role-based access control (admin/user)
 * - Rate limiting on authentication endpoints
 */
import type { Express, Request, RequestHandler } from 'express';
/**
 * Setup authentication middleware
 */
export declare function setupAuth(app: Express): Promise<void>;
/**
 * Middleware to check if user is authenticated
 */
export declare const isAuthenticated: RequestHandler;
/**
 * Middleware to check if user is admin
 */
export declare const isAdmin: RequestHandler;
/**
 * Get user email from request
 */
export declare function getUserId(req: Request): string;
/**
 * Get user from request
 */
export declare function getUser(req: Request): any;
/**
 * Check if user can access a station
 */
export declare function canAccessStation(req: Request, stationId: number): boolean;
declare const _default: {
    setupAuth: typeof setupAuth;
    isAuthenticated: RequestHandler<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
    isAdmin: RequestHandler<import("express-serve-static-core").ParamsDictionary, any, any, import("qs").ParsedQs, Record<string, any>>;
    getUserId: typeof getUserId;
    getUser: typeof getUser;
    canAccessStation: typeof canAccessStation;
};
export default _default;
