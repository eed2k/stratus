/**
 * PostgreSQL Database Adapter for Stratus Weather Server
 *
 * This module provides PostgreSQL connectivity for cloud deployments.
 * Designed to work with Vultr Managed PostgreSQL or any PostgreSQL server.
 *
 * Environment Variables:
 * - DATABASE_URL: PostgreSQL connection string (required for PostgreSQL mode)
 *   Format: postgresql://user:password@host:port/database?sslmode=require
 *
 * If DATABASE_URL is not set, the application falls back to SQLite (server/db.ts)
 */
import { Pool, PoolClient, QueryResult, QueryResultRow } from 'pg';
/**
 * Check if PostgreSQL mode is enabled
 */
export declare function isPostgresEnabled(): boolean;
/**
 * Get the PostgreSQL connection URL
 */
export declare function getDatabaseUrl(): string | undefined;
/**
 * Initialise PostgreSQL connection pool
 */
export declare function initPostgresDatabase(): Promise<void>;
/**
 * Get the connection pool
 */
export declare function getPool(): Pool | null;
/**
 * Execute a raw query
 */
export declare function query(text: string, params?: any[]): Promise<QueryResult<QueryResultRow>>;
/**
 * Get a client from the pool for transactions
 */
export declare function getClient(): Promise<PoolClient>;
/**
 * Close the database connection
 */
export declare function closePostgresDatabase(): Promise<void>;
export interface Station {
    id?: number;
    name: string;
    pakbusAddress: number;
    connectionType: string;
    connectionConfig: any;
    securityCode?: number | null;
    createdAt?: string;
    updatedAt?: string;
    lastConnected?: string | null;
    isActive?: boolean;
    latitude?: number | null;
    longitude?: number | null;
    altitude?: number | null;
    location?: string | null;
    dataloggerModel?: string | null;
    dataloggerSerialNumber?: string | null;
    programName?: string | null;
    modemModel?: string | null;
    modemSerialNumber?: string | null;
    siteDescription?: string | null;
    notes?: string | null;
    stationImage?: string | null;
    protocol?: string;
    stationType?: string;
    ingestId?: string | null;
    windSpeedUnit?: string | null;
}
/**
 * Get all stations
 */
export declare function getAllStations(): Promise<Station[]>;
/**
 * Get station by ID
 */
export declare function getStationById(id: number): Promise<Station | null>;
/**
 * Create a new station
 */
export declare function createStation(station: Station): Promise<number>;
/**
 * Get a station by its unique ingest ID (for HTTP POST ingestion)
 */
export declare function getStationByIngestId(ingestId: string): Promise<Station | null>;
/**
 * Update a station
 */
export declare function updateStation(id: number, updates: Partial<Station>): Promise<void>;
/**
 * Delete a station
 */
export declare function deleteStation(id: number): Promise<void>;
export interface WeatherRecord {
    id?: number;
    stationId: number;
    tableName: string;
    recordNumber?: number | null;
    timestamp: string;
    data: any;
    collectedAt?: string;
    mppt_solar_voltage?: number | null;
    mppt_solar_current?: number | null;
    mppt_solar_power?: number | null;
    mppt_load_voltage?: number | null;
    mppt_load_current?: number | null;
    mppt_battery_voltage?: number | null;
    mppt_charger_state?: number | null;
    mppt_absi_avg?: number | null;
}
/**
 * Insert weather data records
 */
export declare function insertWeatherData(records: WeatherRecord[]): Promise<number>;
/**
 * Get weather data for a station
 */
export declare function getWeatherData(stationId: number, options?: {
    tableName?: string;
    startTime?: string;
    endTime?: string;
    limit?: number;
    offset?: number;
}): Promise<{
    records: WeatherRecord[];
    total: number;
}>;
/**
 * Get latest weather data for a station (optionally filtered by table name)
 */
export declare function getLatestWeatherData(stationId: number, tableName?: string): Promise<WeatherRecord | null>;
/**
 * Get distinct table names for a station (for multi-table merge)
 */
export declare function getDistinctTableNames(stationId: number): Promise<string[]>;
export interface User {
    id?: number;
    email: string;
    firstName: string;
    lastName?: string | null;
    passwordHash: string;
    role?: string;
    assignedStations?: string | null;
    isActive?: boolean;
    lastLoginAt?: string | null;
    createdAt?: string;
    updatedAt?: string;
}
/**
 * Get user by email
 */
export declare function getUserByEmail(email: string): Promise<User | null>;
/**
 * Create a user
 */
export declare function createUser(user: User): Promise<number>;
/**
 * Update user last login
 */
export declare function updateUserLastLogin(userId: number): Promise<void>;
export interface DropboxConfig {
    id?: number;
    name: string;
    folderPath: string;
    filePattern?: string | null;
    stationId?: number | null;
    syncInterval?: number;
    enabled?: boolean;
    lastSyncAt?: string | null;
    lastSyncStatus?: string | null;
    lastSyncRecords?: number;
    createdAt?: string;
    updatedAt?: string;
}
/**
 * Get all Dropbox configs
 */
export declare function getAllDropboxConfigs(): Promise<DropboxConfig[]>;
/**
 * Update Dropbox config sync status
 */
export declare function updateDropboxConfigSyncStatus(id: number, status: string, recordCount: number): Promise<void>;
/**
 * Get a single Dropbox config by ID
 */
export declare function getDropboxConfigById(id: number): Promise<DropboxConfig | null>;
/**
 * Create a new Dropbox config
 */
export declare function createDropboxConfig(name: string, folderPath: string, filePattern: string | null, stationId: number | null, syncInterval: number, enabled: boolean): Promise<number>;
/**
 * Update an existing Dropbox config
 */
export declare function updateDropboxConfig(id: number, data: {
    name?: string;
    folder_path?: string;
    file_pattern?: string | null;
    station_id?: number | null;
    sync_interval?: number;
    enabled?: boolean;
}): Promise<void>;
/**
 * Delete a Dropbox config
 */
export declare function deleteDropboxConfig(id: number): Promise<void>;
/**
 * Create a password reset token
 */
export declare function createPasswordResetToken(email: string): Promise<string>;
/**
 * Validate a password reset token
 */
export declare function validatePasswordResetToken(token: string): Promise<string | null>;
/**
 * Mark a password reset token as used
 */
export declare function markPasswordResetTokenUsed(token: string): Promise<void>;
/**
 * Create a user invitation token
 */
export declare function createUserInvitationToken(email: string, invitedBy?: string, customMessage?: string): Promise<string>;
/**
 * Validate a user invitation token
 */
export declare function validateUserInvitationToken(token: string): Promise<{
    email: string;
    invitedBy?: string;
    customMessage?: string;
} | null>;
/**
 * Mark a user invitation token as used
 */
export declare function markUserInvitationTokenUsed(token: string): Promise<void>;
/**
 * Get all active users
 */
export declare function getAllUsers(): Promise<User[]>;
/**
 * Delete user by email
 */
export declare function deleteUserByEmail(email: string): Promise<boolean>;
/**
 * Update user data by email (admin path)
 */
export declare function updateUserDataByEmail(email: string, updates: {
    firstName?: string;
    lastName?: string;
    passwordHash?: string;
    role?: string;
    assignedStations?: number[];
}): Promise<any>;
/**
 * Update user password hash
 */
export declare function updateUserPassword(email: string, passwordHash: string): Promise<void>;
/**
 * Update user profile (firstName, lastName, email)
 */
export declare function updateUserProfile(userId: number, updates: {
    firstName?: string;
    lastName?: string;
    email?: string;
}): Promise<any>;
/**
 * Get a setting by key
 */
export declare function getSetting(key: string): Promise<string | null>;
/**
 * Set a setting value
 */
export declare function setSetting(key: string, value: string): Promise<void>;
/**
 * Get all settings
 */
export declare function getAllSettings(): Promise<Record<string, string>>;
export interface UserPreferences {
    userId: number;
    temperatureUnit: string;
    windSpeedUnit: string;
    pressureUnit: string;
    precipitationUnit: string;
    theme: string;
    emailNotifications: boolean;
    pushNotifications: boolean;
    tempHighAlert: number;
    windHighAlert: number;
    units: string;
    timezone: string;
    serverAddress: string;
}
/**
 * Get user preferences
 */
export declare function getUserPreferences(userId: number): Promise<UserPreferences | null>;
/**
 * Upsert user preferences
 */
export declare function upsertUserPreferences(prefs: Partial<UserPreferences> & {
    userId: number;
}): Promise<UserPreferences>;
export interface PgAlarm {
    id: number;
    station_id: number;
    name: string;
    parameter: string;
    condition: string;
    threshold: number;
    unit: string;
    severity: string;
    enabled: boolean;
    email_notifications: boolean;
    email_recipients?: string | null;
    last_triggered_at?: string | null;
    trigger_count: number;
    stale_minutes?: number | null;
    created_at: string;
    updated_at: string;
}
export interface PgAlarmEvent {
    id: number;
    alarm_id: number;
    station_id: number;
    triggered_value?: number | null;
    message?: string | null;
    acknowledged: boolean;
    acknowledged_by?: string | null;
    acknowledged_at?: string | null;
    created_at: string;
}
export declare function pgCreateAlarm(alarm: {
    station_id: number;
    name: string;
    parameter: string;
    condition: string;
    threshold: number;
    unit?: string;
    severity?: string;
    enabled?: boolean;
    email_notifications?: boolean;
    email_recipients?: string | null;
    stale_minutes?: number | null;
}): Promise<number>;
export declare function pgGetAlarmById(id: number): Promise<PgAlarm | null>;
export declare function pgGetAlarmsByStation(stationId: number): Promise<PgAlarm[]>;
export declare function pgGetAllAlarms(): Promise<PgAlarm[]>;
export declare function pgUpdateAlarm(id: number, updates: Partial<{
    name: string;
    parameter: string;
    condition: string;
    threshold: number;
    unit: string;
    severity: string;
    enabled: boolean;
    email_notifications: boolean;
    email_recipients: string | null;
    last_triggered_at: string;
    trigger_count: number;
}>): Promise<void>;
export declare function pgDeleteAlarm(id: number): Promise<void>;
export declare function pgTriggerAlarm(alarmId: number, triggeredValue: number, message?: string): Promise<number>;
export declare function pgGetAlarmEvents(alarmId?: number, stationId?: number, limit?: number): Promise<PgAlarmEvent[]>;
export declare function pgAcknowledgeAlarmEvent(eventId: number, acknowledgedBy: string): Promise<void>;
export declare function pgDeleteAlarmEvent(eventId: number): Promise<void>;
export declare function pgCleanupOldAlarmEvents(daysToKeep?: number): Promise<number>;
export declare function pgGetAllOrganizations(): Promise<any[]>;
export declare function pgGetOrganizationById(id: number): Promise<any | null>;
export declare function pgCreateOrganization(name: string, slug: string, description: string | null, ownerId: string, logoUrl?: string | null): Promise<number>;
export declare function pgUpdateOrganization(id: number, data: {
    name?: string;
    description?: string;
    logoUrl?: string | null;
}): Promise<void>;
export declare function pgDeleteOrganization(id: number): Promise<void>;
export declare function pgGetOrganizationMembers(orgId: number): Promise<any[]>;
export declare function pgAddOrganizationMember(orgId: number, userId: string, role: string): Promise<number>;
export declare function pgUpdateMemberRole(orgId: number, userId: string, role: string): Promise<void>;
export declare function pgRemoveOrganizationMember(orgId: number, userId: string): Promise<void>;
export declare function pgIsOrganizationAdmin(orgId: number, userId: string): Promise<boolean>;
export declare function pgGetOrganizationInvitations(orgId: number): Promise<any[]>;
export declare function pgCreateOrganizationInvitation(orgId: number, email: string, role: string): Promise<string>;
export declare function pgGetUserOrganizations(userId: string): Promise<any[]>;
export declare function pgCreateShare(share: {
    station_id: number;
    share_token: string;
    slug?: string;
    name: string;
    email?: string;
    access_level: string;
    password?: string;
    expires_at?: string;
    is_active: boolean;
    access_count: number;
    created_by: string;
}): Promise<string>;
export declare function pgGetShareBySlug(slug: string): Promise<any | null>;
export declare function pgGetShareByToken(token: string): Promise<any | null>;
export declare function pgGetSharesByStation(stationId: number): Promise<any[]>;
export declare function pgUpdateShare(shareToken: string, updates: Record<string, any>): Promise<void>;
export declare function pgDeleteShare(shareToken: string): Promise<void>;
declare const _default: {
    isPostgresEnabled: typeof isPostgresEnabled;
    initPostgresDatabase: typeof initPostgresDatabase;
    closePostgresDatabase: typeof closePostgresDatabase;
    getPool: typeof getPool;
    query: typeof query;
    getClient: typeof getClient;
    getAllStations: typeof getAllStations;
    getStationById: typeof getStationById;
    createStation: typeof createStation;
    updateStation: typeof updateStation;
    deleteStation: typeof deleteStation;
    insertWeatherData: typeof insertWeatherData;
    getWeatherData: typeof getWeatherData;
    getLatestWeatherData: typeof getLatestWeatherData;
    getDistinctTableNames: typeof getDistinctTableNames;
    getUserByEmail: typeof getUserByEmail;
    createUser: typeof createUser;
    updateUserLastLogin: typeof updateUserLastLogin;
    getAllDropboxConfigs: typeof getAllDropboxConfigs;
    getDropboxConfigById: typeof getDropboxConfigById;
    createDropboxConfig: typeof createDropboxConfig;
    updateDropboxConfig: typeof updateDropboxConfig;
    deleteDropboxConfig: typeof deleteDropboxConfig;
    updateDropboxConfigSyncStatus: typeof updateDropboxConfigSyncStatus;
    createPasswordResetToken: typeof createPasswordResetToken;
    validatePasswordResetToken: typeof validatePasswordResetToken;
    markPasswordResetTokenUsed: typeof markPasswordResetTokenUsed;
    createUserInvitationToken: typeof createUserInvitationToken;
    validateUserInvitationToken: typeof validateUserInvitationToken;
    markUserInvitationTokenUsed: typeof markUserInvitationTokenUsed;
    updateUserPassword: typeof updateUserPassword;
    updateUserProfile: typeof updateUserProfile;
    getSetting: typeof getSetting;
    setSetting: typeof setSetting;
    getAllSettings: typeof getAllSettings;
    getUserPreferences: typeof getUserPreferences;
    upsertUserPreferences: typeof upsertUserPreferences;
    pgCreateAlarm: typeof pgCreateAlarm;
    pgGetAlarmById: typeof pgGetAlarmById;
    pgGetAlarmsByStation: typeof pgGetAlarmsByStation;
    pgGetAllAlarms: typeof pgGetAllAlarms;
    pgUpdateAlarm: typeof pgUpdateAlarm;
    pgDeleteAlarm: typeof pgDeleteAlarm;
    pgTriggerAlarm: typeof pgTriggerAlarm;
    pgGetAlarmEvents: typeof pgGetAlarmEvents;
    pgAcknowledgeAlarmEvent: typeof pgAcknowledgeAlarmEvent;
    pgDeleteAlarmEvent: typeof pgDeleteAlarmEvent;
    pgCleanupOldAlarmEvents: typeof pgCleanupOldAlarmEvents;
    pgGetAllOrganizations: typeof pgGetAllOrganizations;
    pgGetOrganizationById: typeof pgGetOrganizationById;
    pgCreateOrganization: typeof pgCreateOrganization;
    pgUpdateOrganization: typeof pgUpdateOrganization;
    pgDeleteOrganization: typeof pgDeleteOrganization;
    pgGetOrganizationMembers: typeof pgGetOrganizationMembers;
    pgAddOrganizationMember: typeof pgAddOrganizationMember;
    pgUpdateMemberRole: typeof pgUpdateMemberRole;
    pgRemoveOrganizationMember: typeof pgRemoveOrganizationMember;
    pgIsOrganizationAdmin: typeof pgIsOrganizationAdmin;
    pgGetOrganizationInvitations: typeof pgGetOrganizationInvitations;
    pgCreateOrganizationInvitation: typeof pgCreateOrganizationInvitation;
    pgGetUserOrganizations: typeof pgGetUserOrganizations;
    pgCreateShare: typeof pgCreateShare;
    pgGetShareByToken: typeof pgGetShareByToken;
    pgGetShareBySlug: typeof pgGetShareBySlug;
    pgGetSharesByStation: typeof pgGetSharesByStation;
    pgUpdateShare: typeof pgUpdateShare;
    pgDeleteShare: typeof pgDeleteShare;
};
export default _default;
