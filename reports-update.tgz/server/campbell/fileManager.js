"use strict";
// Stratus Weather Server
// Created by Lukas Esterhuizen
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileManager = void 0;
/**
 * Campbell Scientific File Manager
 * Handles file operations on dataloggers: listing, download, upload, delete, backup/restore
 */
const events_1 = require("events");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const os = __importStar(require("os"));
const pakbusProtocol_1 = require("./pakbusProtocol");
// File control commands for PakBus
const FILE_COMMANDS = {
    COMPILE_RUN: 0x01,
    COMPILE_SET_RUN_ON_PU: 0x02,
    RUN_NOW: 0x03,
    SET_RUN_ON_PU: 0x04,
    RUN_ON_PU_COMPILE_RUN: 0x05,
    STOP_PROGRAM: 0x06,
    DELETE_STOP_PROGRAM: 0x07,
    STOP_DELETE_RUN_ON_PU: 0x08,
    PAUSE: 0x09,
    RESUME: 0x0A,
    MARK_FOR_DELETE: 0x0B,
    GET_FILE: 0x0C,
    SEND_FILE: 0x0D,
    DIR_LIST: 0x0E,
    FORMAT_DEVICE: 0x0F,
    FILE_INFO: 0x10,
    CLOSE_FILE: 0x11
};
// Default storage devices on Campbell dataloggers
const STORAGE_DEVICES = {
    CPU: 'CPU:',
    USR: 'USR:',
    CRD: 'CRD:', // CF card
    USB: 'USB:'
};
class FileManager extends events_1.EventEmitter {
    constructor(pakbus, backupDir) {
        super();
        this.activeTransfers = new Map();
        this.chunkSize = 512; // Bytes per transfer chunk
        this.pakbus = pakbus;
        this.backupDir = backupDir || this.getDefaultBackupDir();
        // Ensure backup directory exists
        if (!fs.existsSync(this.backupDir)) {
            fs.mkdirSync(this.backupDir, { recursive: true });
        }
    }
    /**
     * Get a writable default backup directory (same logic as db.ts)
     */
    getDefaultBackupDir() {
        if (process.env.STRATUS_DATA_DIR) {
            return path.join(process.env.STRATUS_DATA_DIR, 'backups');
        }
        const platform = process.platform;
        let appDataPath;
        if (platform === 'win32') {
            appDataPath = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
        }
        else if (platform === 'darwin') {
            appDataPath = path.join(os.homedir(), 'Library', 'Application Support');
        }
        else {
            appDataPath = process.env.XDG_DATA_HOME || path.join(os.homedir(), '.local', 'share');
        }
        return path.join(appDataPath, 'Stratus Weather Server', 'backups');
    }
    /**
     * List files on a storage device
     */
    async listFiles(stationAddress, device = 'CPU:') {
        const files = [];
        try {
            // Build directory listing request
            const payload = this.buildDirListPayload(device);
            const response = await this.pakbus.sendTransaction(stationAddress, pakbusProtocol_1.MESSAGE_TYPES.FILE_CONTROL, payload);
            if (response && response.data) {
                const parsedFiles = this.parseDirectoryListing(response.data, device);
                files.push(...parsedFiles);
            }
            this.emit('files-listed', { stationAddress, device, files });
            return files;
        }
        catch (error) {
            this.emit('error', { operation: 'listFiles', error });
            throw error;
        }
    }
    /**
     * Get information about a specific file
     */
    async getFileInfo(stationAddress, filePath) {
        try {
            const payload = this.buildFileInfoPayload(filePath);
            const response = await this.pakbus.sendTransaction(stationAddress, pakbusProtocol_1.MESSAGE_TYPES.FILE_CONTROL, payload);
            if (response && response.data) {
                return this.parseFileInfo(response.data, filePath);
            }
            return null;
        }
        catch (error) {
            this.emit('error', { operation: 'getFileInfo', error });
            throw error;
        }
    }
    /**
     * Download a file from the datalogger
     * Includes path sanitization to prevent directory traversal attacks
     */
    async downloadFile(stationAddress, remoteFilePath, localFilePath) {
        const transferId = `download-${Date.now()}`;
        // SECURITY: Sanitize and validate local file path to prevent directory traversal
        const resolvedPath = path.resolve(localFilePath);
        const allowedDir = path.resolve(this.backupDir);
        if (!resolvedPath.startsWith(allowedDir + path.sep) && resolvedPath !== allowedDir) {
            throw new Error(`Invalid file path: must be within backup directory (${allowedDir})`);
        }
        // Initialise progress tracking
        const progress = {
            fileName: remoteFilePath,
            totalBytes: 0,
            transferredBytes: 0,
            percentComplete: 0,
            bytesPerSecond: 0,
            estimatedTimeRemaining: 0,
            status: 'pending'
        };
        this.activeTransfers.set(transferId, progress);
        try {
            // Get file info first to know total size
            const fileInfo = await this.getFileInfo(stationAddress, remoteFilePath);
            if (!fileInfo) {
                throw new Error(`File not found: ${remoteFilePath}`);
            }
            progress.totalBytes = fileInfo.size;
            progress.status = 'in-progress';
            this.emitProgress(transferId, progress);
            // Ensure local directory exists (using sanitized path)
            const localDir = path.dirname(resolvedPath);
            if (!fs.existsSync(localDir)) {
                fs.mkdirSync(localDir, { recursive: true });
            }
            // Open local file for writing (using sanitized path)
            const writeStream = fs.createWriteStream(resolvedPath);
            const startTime = Date.now();
            let offset = 0;
            // Download in chunks
            while (offset < fileInfo.size) {
                const bytesToRead = Math.min(this.chunkSize, fileInfo.size - offset);
                const payload = this.buildGetFilePayload(remoteFilePath, offset, bytesToRead);
                const response = await this.pakbus.sendTransaction(stationAddress, pakbusProtocol_1.MESSAGE_TYPES.FILE_CONTROL, payload);
                if (response && response.data) {
                    const chunk = this.extractFileChunk(response.data);
                    if (chunk.length > 0) {
                        writeStream.write(chunk);
                        offset += chunk.length;
                        // Update progress
                        progress.transferredBytes = offset;
                        progress.percentComplete = (offset / fileInfo.size) * 100;
                        const elapsedSeconds = (Date.now() - startTime) / 1000;
                        progress.bytesPerSecond = offset / elapsedSeconds;
                        progress.estimatedTimeRemaining =
                            (fileInfo.size - offset) / progress.bytesPerSecond;
                        this.emitProgress(transferId, progress);
                    }
                }
                else {
                    throw new Error('Failed to receive file chunk');
                }
            }
            writeStream.end();
            progress.status = 'completed';
            progress.percentComplete = 100;
            this.emitProgress(transferId, progress);
            this.activeTransfers.delete(transferId);
            this.emit('download-complete', {
                stationAddress,
                remoteFilePath,
                localFilePath,
                size: fileInfo.size
            });
            return true;
        }
        catch (error) {
            progress.status = 'failed';
            progress.error = error instanceof Error ? error.message : String(error);
            this.emitProgress(transferId, progress);
            this.activeTransfers.delete(transferId);
            this.emit('error', { operation: 'downloadFile', error });
            throw error;
        }
    }
    /**
     * Upload a file to the datalogger
     */
    async uploadFile(stationAddress, localFilePath, remoteFilePath, options) {
        const transferId = `upload-${Date.now()}`;
        // Check if local file exists
        if (!fs.existsSync(localFilePath)) {
            throw new Error(`Local file not found: ${localFilePath}`);
        }
        const stats = fs.statSync(localFilePath);
        // Initialise progress tracking
        const progress = {
            fileName: localFilePath,
            totalBytes: stats.size,
            transferredBytes: 0,
            percentComplete: 0,
            bytesPerSecond: 0,
            estimatedTimeRemaining: 0,
            status: 'pending'
        };
        this.activeTransfers.set(transferId, progress);
        try {
            progress.status = 'in-progress';
            this.emitProgress(transferId, progress);
            const fileBuffer = fs.readFileSync(localFilePath);
            const startTime = Date.now();
            let offset = 0;
            // Start file send
            const startPayload = this.buildSendFileStartPayload(remoteFilePath, stats.size);
            await this.pakbus.sendTransaction(stationAddress, pakbusProtocol_1.MESSAGE_TYPES.FILE_CONTROL, startPayload);
            // Upload in chunks
            while (offset < fileBuffer.length) {
                const bytesToSend = Math.min(this.chunkSize, fileBuffer.length - offset);
                const chunk = fileBuffer.slice(offset, offset + bytesToSend);
                const payload = this.buildSendFileChunkPayload(remoteFilePath, offset, chunk, offset + bytesToSend >= fileBuffer.length // Last chunk
                );
                const response = await this.pakbus.sendTransaction(stationAddress, pakbusProtocol_1.MESSAGE_TYPES.FILE_CONTROL, payload);
                if (response && response.success) {
                    offset += bytesToSend;
                    // Update progress
                    progress.transferredBytes = offset;
                    progress.percentComplete = (offset / stats.size) * 100;
                    const elapsedSeconds = (Date.now() - startTime) / 1000;
                    progress.bytesPerSecond = offset / elapsedSeconds;
                    progress.estimatedTimeRemaining =
                        (stats.size - offset) / progress.bytesPerSecond;
                    this.emitProgress(transferId, progress);
                }
                else {
                    throw new Error('Failed to send file chunk');
                }
            }
            // Close the file
            const closePayload = this.buildCloseFilePayload(remoteFilePath);
            await this.pakbus.sendTransaction(stationAddress, pakbusProtocol_1.MESSAGE_TYPES.FILE_CONTROL, closePayload);
            // Optionally compile and run
            if (options?.compileRun || options?.setRunOnPowerUp) {
                const command = options.setRunOnPowerUp
                    ? FILE_COMMANDS.COMPILE_SET_RUN_ON_PU
                    : FILE_COMMANDS.COMPILE_RUN;
                const runPayload = this.buildFileCommandPayload(remoteFilePath, command);
                await this.pakbus.sendTransaction(stationAddress, pakbusProtocol_1.MESSAGE_TYPES.FILE_CONTROL, runPayload);
            }
            progress.status = 'completed';
            progress.percentComplete = 100;
            this.emitProgress(transferId, progress);
            this.activeTransfers.delete(transferId);
            this.emit('upload-complete', {
                stationAddress,
                localFilePath,
                remoteFilePath,
                size: stats.size
            });
            return true;
        }
        catch (error) {
            progress.status = 'failed';
            progress.error = error instanceof Error ? error.message : String(error);
            this.emitProgress(transferId, progress);
            this.activeTransfers.delete(transferId);
            this.emit('error', { operation: 'uploadFile', error });
            throw error;
        }
    }
    /**
     * Delete a file from the datalogger
     */
    async deleteFile(stationAddress, filePath) {
        try {
            const payload = this.buildFileCommandPayload(filePath, FILE_COMMANDS.MARK_FOR_DELETE);
            const response = await this.pakbus.sendTransaction(stationAddress, pakbusProtocol_1.MESSAGE_TYPES.FILE_CONTROL, payload);
            if (response && response.success) {
                this.emit('file-deleted', { stationAddress, filePath });
                return true;
            }
            return false;
        }
        catch (error) {
            this.emit('error', { operation: 'deleteFile', error });
            throw error;
        }
    }
    /**
     * Get storage device information
     */
    async getStorageInfo(stationAddress, device = 'CPU:') {
        try {
            // Request device status - typically from public status table
            const status = await this.pakbus.sendTransaction(stationAddress, pakbusProtocol_1.MESSAGE_TYPES.COLLECT_DATA, this.buildStorageInfoPayload(device));
            if (status && status.data) {
                return this.parseStorageInfo(status.data, device);
            }
            // Return default if unable to get info
            return {
                device,
                totalBytes: 0,
                usedBytes: 0,
                freeBytes: 0,
                percentUsed: 0
            };
        }
        catch (error) {
            this.emit('error', { operation: 'getStorageInfo', error });
            throw error;
        }
    }
    /**
     * Create a backup of station files
     */
    async createBackup(stationAddress, stationName, files, notes) {
        const backupId = `backup-${stationAddress}-${Date.now()}`;
        const backupPath = path.join(this.backupDir, stationName, backupId);
        // Create backup directory
        fs.mkdirSync(backupPath, { recursive: true });
        try {
            // If no files specified, get all files from CPU:
            let filesToBackup = files;
            if (!filesToBackup || filesToBackup.length === 0) {
                const allFiles = await this.listFiles(stationAddress, 'CPU:');
                filesToBackup = allFiles.map(f => f.path);
            }
            const backedUpFiles = [];
            let totalSize = 0;
            // Download each file
            for (const remoteFile of filesToBackup) {
                try {
                    const fileName = path.basename(remoteFile);
                    const localPath = path.join(backupPath, fileName);
                    await this.downloadFile(stationAddress, remoteFile, localPath);
                    const stats = fs.statSync(localPath);
                    totalSize += stats.size;
                    backedUpFiles.push(fileName);
                    this.emit('backup-progress', {
                        backupId,
                        currentFile: fileName,
                        filesComplete: backedUpFiles.length,
                        filesTotal: filesToBackup.length
                    });
                }
                catch (error) {
                    console.error(`Failed to backup ${remoteFile}:`, error);
                }
            }
            // Create backup manifest
            const backupInfo = {
                id: backupId,
                stationId: String(stationAddress),
                stationName,
                timestamp: new Date(),
                files: backedUpFiles,
                totalSize,
                backupPath,
                notes
            };
            // Save manifest
            const manifestPath = path.join(backupPath, 'manifest.json');
            fs.writeFileSync(manifestPath, JSON.stringify(backupInfo, null, 2));
            this.emit('backup-complete', backupInfo);
            return backupInfo;
        }
        catch (error) {
            this.emit('error', { operation: 'createBackup', error });
            throw error;
        }
    }
    /**
     * Restore files from a backup
     */
    async restoreBackup(stationAddress, backupId, files, options) {
        try {
            // Find the backup manifest
            const backupInfo = this.loadBackupInfo(backupId);
            if (!backupInfo) {
                throw new Error(`Backup not found: ${backupId}`);
            }
            const filesToRestore = files || backupInfo.files;
            let restoredCount = 0;
            for (const fileName of filesToRestore) {
                try {
                    const localPath = path.join(backupInfo.backupPath, fileName);
                    if (!fs.existsSync(localPath)) {
                        console.warn(`Backup file not found: ${localPath}`);
                        continue;
                    }
                    const remotePath = `CPU:${fileName}`;
                    // Determine if this is a program file
                    const isProgramFile = fileName.endsWith('.CR1') ||
                        fileName.endsWith('.CR2') ||
                        fileName.endsWith('.CR3') ||
                        fileName.endsWith('.CR6') ||
                        fileName.endsWith('.CRB');
                    await this.uploadFile(stationAddress, localPath, remotePath, isProgramFile ? options : undefined);
                    restoredCount++;
                    this.emit('restore-progress', {
                        backupId,
                        currentFile: fileName,
                        filesComplete: restoredCount,
                        filesTotal: filesToRestore.length
                    });
                }
                catch (error) {
                    console.error(`Failed to restore ${fileName}:`, error);
                }
            }
            this.emit('restore-complete', {
                backupId,
                filesRestored: restoredCount,
                filesTotal: filesToRestore.length
            });
            return restoredCount > 0;
        }
        catch (error) {
            this.emit('error', { operation: 'restoreBackup', error });
            throw error;
        }
    }
    /**
     * List all available backups
     */
    listBackups(stationName) {
        const backups = [];
        try {
            const searchDir = stationName
                ? path.join(this.backupDir, stationName)
                : this.backupDir;
            if (!fs.existsSync(searchDir)) {
                return backups;
            }
            const searchBackupsInDir = (dir) => {
                const entries = fs.readdirSync(dir, { withFileTypes: true });
                for (const entry of entries) {
                    if (entry.isDirectory()) {
                        const manifestPath = path.join(dir, entry.name, 'manifest.json');
                        if (fs.existsSync(manifestPath)) {
                            try {
                                const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'));
                                backups.push(manifest);
                            }
                            catch (e) {
                                console.error(`Failed to read manifest: ${manifestPath}`);
                            }
                        }
                        else {
                            // Search subdirectories
                            searchBackupsInDir(path.join(dir, entry.name));
                        }
                    }
                }
            };
            searchBackupsInDir(searchDir);
            // Sort by timestamp descending
            backups.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
            return backups;
        }
        catch (error) {
            console.error('Failed to list backups:', error);
            return backups;
        }
    }
    /**
     * Delete a backup
     */
    deleteBackup(backupId) {
        try {
            const backupInfo = this.loadBackupInfo(backupId);
            if (!backupInfo) {
                return false;
            }
            // Remove backup directory
            fs.rmSync(backupInfo.backupPath, { recursive: true, force: true });
            this.emit('backup-deleted', backupId);
            return true;
        }
        catch (error) {
            console.error(`Failed to delete backup: ${backupId}`, error);
            return false;
        }
    }
    /**
     * Cancel an active transfer
     */
    cancelTransfer(transferId) {
        const transfer = this.activeTransfers.get(transferId);
        if (transfer && transfer.status === 'in-progress') {
            transfer.status = 'cancelled';
            this.activeTransfers.delete(transferId);
            this.emit('transfer-cancelled', transferId);
            return true;
        }
        return false;
    }
    /**
     * Get active transfer status
     */
    getTransferStatus(transferId) {
        return this.activeTransfers.get(transferId);
    }
    /**
     * Get all active transfers
     */
    getActiveTransfers() {
        return new Map(this.activeTransfers);
    }
    // 
    emitProgress(transferId, progress) {
        this.emit('transfer-progress', { transferId, ...progress });
    }
    loadBackupInfo(backupId) {
        // Search for backup by ID
        const allBackups = this.listBackups();
        return allBackups.find(b => b.id === backupId) || null;
    }
    buildDirListPayload(device) {
        const command = Buffer.alloc(1);
        command.writeUInt8(FILE_COMMANDS.DIR_LIST, 0);
        const deviceBytes = Buffer.from(device + '\0', 'ascii');
        return Buffer.concat([command, deviceBytes]);
    }
    buildFileInfoPayload(filePath) {
        const command = Buffer.alloc(1);
        command.writeUInt8(FILE_COMMANDS.FILE_INFO, 0);
        const pathBytes = Buffer.from(filePath + '\0', 'ascii');
        return Buffer.concat([command, pathBytes]);
    }
    buildGetFilePayload(filePath, offset, length) {
        const command = Buffer.alloc(9);
        command.writeUInt8(FILE_COMMANDS.GET_FILE, 0);
        command.writeUInt32LE(offset, 1);
        command.writeUInt32LE(length, 5);
        const pathBytes = Buffer.from(filePath + '\0', 'ascii');
        return Buffer.concat([command, pathBytes]);
    }
    buildSendFileStartPayload(filePath, fileSize) {
        const command = Buffer.alloc(5);
        command.writeUInt8(FILE_COMMANDS.SEND_FILE, 0);
        command.writeUInt32LE(fileSize, 1);
        const pathBytes = Buffer.from(filePath + '\0', 'ascii');
        return Buffer.concat([command, pathBytes]);
    }
    buildSendFileChunkPayload(filePath, offset, data, isLast) {
        const header = Buffer.alloc(10);
        header.writeUInt8(FILE_COMMANDS.SEND_FILE, 0);
        header.writeUInt32LE(offset, 1);
        header.writeUInt32LE(data.length, 5);
        header.writeUInt8(isLast ? 1 : 0, 9);
        return Buffer.concat([header, data]);
    }
    buildCloseFilePayload(filePath) {
        const command = Buffer.alloc(1);
        command.writeUInt8(FILE_COMMANDS.CLOSE_FILE, 0);
        const pathBytes = Buffer.from(filePath + '\0', 'ascii');
        return Buffer.concat([command, pathBytes]);
    }
    buildFileCommandPayload(filePath, command) {
        const commandByte = Buffer.alloc(1);
        commandByte.writeUInt8(command, 0);
        const pathBytes = Buffer.from(filePath + '\0', 'ascii');
        return Buffer.concat([commandByte, pathBytes]);
    }
    buildStorageInfoPayload(device) {
        // Request Status table for storage info
        const tableNumber = 1; // Public table
        const payload = Buffer.alloc(3);
        payload.writeUInt8(0x05, 0); // Collect mode
        payload.writeUInt16LE(tableNumber, 1);
        return payload;
    }
    parseDirectoryListing(data, device) {
        const files = [];
        let offset = 0;
        while (offset < data.length) {
            // Each file entry: name (null-terminated), size (4 bytes), time (4 bytes), attributes (1 byte)
            const nameEnd = data.indexOf(0, offset);
            if (nameEnd === -1)
                break;
            const name = data.slice(offset, nameEnd).toString('ascii');
            offset = nameEnd + 1;
            if (offset + 9 > data.length)
                break;
            const size = data.readUInt32LE(offset);
            offset += 4;
            const timestamp = data.readUInt32LE(offset);
            offset += 4;
            const attrs = data.readUInt8(offset);
            offset += 1;
            files.push({
                name,
                size,
                lastModified: new Date(timestamp * 1000),
                attributes: this.parseFileAttributes(attrs),
                path: `${device}${name}`
            });
        }
        return files;
    }
    parseFileAttributes(attrs) {
        return {
            readOnly: (attrs & 0x01) !== 0,
            hidden: (attrs & 0x02) !== 0,
            system: (attrs & 0x04) !== 0,
            paused: (attrs & 0x08) !== 0,
            runOnPowerUp: (attrs & 0x10) !== 0,
            runNow: (attrs & 0x20) !== 0
        };
    }
    parseFileInfo(data, filePath) {
        const size = data.readUInt32LE(0);
        const timestamp = data.readUInt32LE(4);
        const attrs = data.readUInt8(8);
        return {
            name: path.basename(filePath),
            size,
            lastModified: new Date(timestamp * 1000),
            attributes: this.parseFileAttributes(attrs),
            path: filePath
        };
    }
    extractFileChunk(data) {
        // First byte is status, rest is file data
        if (data.length < 1)
            return Buffer.alloc(0);
        const status = data.readUInt8(0);
        if (status !== 0) {
            console.warn(`File chunk status: ${status}`);
        }
        return data.slice(1);
    }
    parseStorageInfo(data, device) {
        // Parse storage info from status table response
        // Format varies by datalogger model
        let totalBytes = 0;
        let freeBytes = 0;
        if (data.length >= 8) {
            totalBytes = data.readUInt32LE(0);
            freeBytes = data.readUInt32LE(4);
        }
        const usedBytes = totalBytes - freeBytes;
        const percentUsed = totalBytes > 0 ? (usedBytes / totalBytes) * 100 : 0;
        return {
            device,
            totalBytes,
            usedBytes,
            freeBytes,
            percentUsed
        };
    }
}
exports.FileManager = FileManager;
exports.default = FileManager;
