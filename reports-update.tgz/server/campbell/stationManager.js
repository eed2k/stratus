"use strict";
// Stratus Weather Server
// Created by Lukas Esterhuizen
Object.defineProperty(exports, "__esModule", { value: true });
exports.stationManager = exports.StationManager = void 0;
/**
 * Station Manager
 * Device discovery, configuration management, and program handling
 */
const events_1 = require("events");
const connectionManager_1 = require("./connectionManager");
class StationManager extends events_1.EventEmitter {
    constructor() {
        super();
        this.stations = new Map();
        this.discoveryInProgress = false;
        this.setupConnectionEvents();
    }
    /**
     * Setup connection manager events
     */
    setupConnectionEvents() {
        connectionManager_1.connectionManager.on("connected", async (stationId) => {
            await this.updateStationStatus(stationId, "online");
            await this.refreshStationInfo(stationId);
        });
        connectionManager_1.connectionManager.on("disconnected", (stationId) => {
            this.updateStationStatus(stationId, "offline");
        });
        connectionManager_1.connectionManager.on("error", (stationId, error) => {
            this.updateStationStatus(stationId, "error");
            this.emit("station-error", stationId, error);
        });
        connectionManager_1.connectionManager.on("status", (stationId, status) => {
            const station = this.stations.get(stationId);
            if (station && status.batteryVoltage !== undefined) {
                station.batteryVoltage = status.batteryVoltage;
                this.emit("station-updated", station);
            }
        });
    }
    /**
     * Add a new station
     */
    async addStation(name, config) {
        const id = this.generateStationId();
        const station = {
            id,
            name,
            serialNumber: "",
            model: "",
            osVersion: "",
            pakbusAddress: config.pakbusAddress,
            connectionType: config.type,
            connectionConfig: config,
            status: "connecting",
        };
        this.stations.set(id, station);
        this.emit("station-added", station);
        // Connect to station
        try {
            await connectionManager_1.connectionManager.addConnection(id, config);
            await this.refreshStationInfo(id);
        }
        catch (error) {
            station.status = "error";
            this.emit("station-error", id, error);
        }
        return station;
    }
    /**
     * Remove a station
     */
    async removeStation(stationId) {
        await connectionManager_1.connectionManager.removeConnection(stationId);
        this.stations.delete(stationId);
        this.emit("station-removed", stationId);
    }
    /**
     * Get station by ID
     */
    getStation(stationId) {
        return this.stations.get(stationId) || null;
    }
    /**
     * Get all stations
     */
    getAllStations() {
        return Array.from(this.stations.values());
    }
    /**
     * Update station configuration
     */
    async updateStation(stationId, updates) {
        const station = this.stations.get(stationId);
        if (!station)
            return null;
        Object.assign(station, updates);
        // If connection config changed, reconnect
        if (updates.connectionConfig) {
            await connectionManager_1.connectionManager.removeConnection(stationId);
            await connectionManager_1.connectionManager.addConnection(stationId, updates.connectionConfig);
        }
        this.emit("station-updated", station);
        return station;
    }
    /**
     * Discover stations
     */
    async discoverStations(config) {
        if (this.discoveryInProgress) {
            throw new Error("Discovery already in progress");
        }
        this.discoveryInProgress = true;
        this.emit("discovery-started");
        try {
            const discovered = await connectionManager_1.connectionManager.discoverStations(config);
            // Get additional info for each discovered station
            const results = [];
            for (const item of discovered) {
                const result = {
                    address: item.address,
                    type: item.type,
                };
                // Try to get station info
                try {
                    const tempConfig = {
                        ...config,
                        pakbusAddress: item.address,
                        mode: "pull",
                    };
                    await connectionManager_1.connectionManager.addConnection(-1, tempConfig);
                    const pakbus = connectionManager_1.connectionManager.getPakBus(-1);
                    if (pakbus) {
                        const settings = await pakbus.getSettings();
                        if (settings.success && settings.data) {
                            result.stationType = settings.data.stationName;
                            result.serialNumber = settings.data.serialNumber;
                        }
                    }
                    await connectionManager_1.connectionManager.removeConnection(-1);
                }
                catch {
                    // Continue without additional info
                }
                results.push(result);
                this.emit("station-discovered", result);
            }
            this.emit("discovery-complete", results);
            return results;
        }
        finally {
            this.discoveryInProgress = false;
        }
    }
    /**
     * Test connection to a station
     */
    async testConnection(config) {
        const startTime = Date.now();
        try {
            await connectionManager_1.connectionManager.addConnection(-1, config);
            const pakbus = connectionManager_1.connectionManager.getPakBus(-1);
            if (!pakbus) {
                throw new Error("Failed to create PakBus connection");
            }
            const helloResult = await pakbus.hello();
            await connectionManager_1.connectionManager.removeConnection(-1);
            if (!helloResult.success) {
                return {
                    success: false,
                    error: helloResult.error || "Hello transaction failed",
                };
            }
            return {
                success: true,
                latency: Date.now() - startTime,
                stationInfo: helloResult.data,
            };
        }
        catch (error) {
            await connectionManager_1.connectionManager.removeConnection(-1).catch(() => { });
            return {
                success: false,
                error: error.message,
            };
        }
    }
    /**
     * Refresh station information
     */
    async refreshStationInfo(stationId) {
        const station = this.stations.get(stationId);
        if (!station)
            return;
        const pakbus = connectionManager_1.connectionManager.getPakBus(stationId);
        if (!pakbus)
            return;
        try {
            // Get settings
            const settingsResult = await pakbus.getSettings();
            if (settingsResult.success && settingsResult.data) {
                station.name = station.name || settingsResult.data.stationName;
                station.serialNumber = settingsResult.data.serialNumber;
                station.osVersion = settingsResult.data.osVersion;
            }
            // Get table definitions
            const tablesResult = await pakbus.getTableDefinitions();
            if (tablesResult.success) {
                station.tables = tablesResult.data;
            }
            station.lastSeen = new Date();
            this.emit("station-updated", station);
        }
        catch (error) {
            console.error(`Error refreshing station ${stationId}:`, error);
        }
    }
    /**
     * Sync station clock
     */
    async syncClock(stationId) {
        const pakbus = connectionManager_1.connectionManager.getPakBus(stationId);
        if (!pakbus) {
            return { success: false, error: "Station not connected" };
        }
        try {
            // Get current station time
            const clockResult = await pakbus.getClock();
            if (!clockResult.success) {
                throw new Error(clockResult.error || "Failed to get clock");
            }
            const stationTime = clockResult.data;
            const systemTime = new Date();
            const offset = systemTime.getTime() - stationTime.getTime();
            // Set clock if offset is significant (> 1 second)
            if (Math.abs(offset) > 1000) {
                const setResult = await pakbus.setClock(systemTime);
                if (!setResult.success) {
                    throw new Error(setResult.error || "Failed to set clock");
                }
            }
            return {
                success: true,
                offset: Math.round(offset / 1000),
            };
        }
        catch (error) {
            return {
                success: false,
                error: error.message,
            };
        }
    }
    /**
     * Get program information
     */
    async getProgramInfo(stationId) {
        const pakbus = connectionManager_1.connectionManager.getPakBus(stationId);
        if (!pakbus)
            return null;
        try {
            // This would require additional PakBus commands
            // Simplified version
            const settingsResult = await pakbus.getSettings();
            if (settingsResult.success && settingsResult.data) {
                return {
                    name: settingsResult.data.programName || "Unknown",
                    signature: settingsResult.data.programSignature || "",
                    size: 0,
                    running: true,
                };
            }
        }
        catch {
            // Ignore errors
        }
        return null;
    }
    /**
     * Upload program to station
     */
    async uploadProgram(stationId, programContent, fileName = "CPU:program.cr1") {
        const pakbus = connectionManager_1.connectionManager.getPakBus(stationId);
        if (!pakbus) {
            return { success: false, error: "Station not connected" };
        }
        try {
            // Stop current program
            await pakbus.programControl("stop");
            // Upload new program
            const uploadResult = await pakbus.uploadFile(fileName, programContent);
            if (!uploadResult.success) {
                throw new Error(uploadResult.error || "Upload failed");
            }
            // Compile and run
            const compileResult = await pakbus.programControl("compile");
            if (!compileResult.success) {
                throw new Error(compileResult.error || "Compile failed");
            }
            const runResult = await pakbus.programControl("run");
            if (!runResult.success) {
                throw new Error(runResult.error || "Failed to start program");
            }
            await this.refreshStationInfo(stationId);
            return { success: true };
        }
        catch (error) {
            return {
                success: false,
                error: error.message,
            };
        }
    }
    /**
     * Download program from station
     */
    async downloadProgram(stationId, fileName = "CPU:program.cr1") {
        const pakbus = connectionManager_1.connectionManager.getPakBus(stationId);
        if (!pakbus) {
            return { success: false, error: "Station not connected" };
        }
        try {
            const result = await pakbus.downloadFile(fileName);
            if (!result.success) {
                throw new Error(result.error || "Download failed");
            }
            return {
                success: true,
                content: result.data,
            };
        }
        catch (error) {
            return {
                success: false,
                error: error.message,
            };
        }
    }
    /**
     * Update station status
     */
    async updateStationStatus(stationId, status) {
        const station = this.stations.get(stationId);
        if (station) {
            station.status = status;
            if (status === "online") {
                station.lastSeen = new Date();
            }
            this.emit("station-status-changed", stationId, status);
        }
    }
    /**
     * Generate unique station ID
     */
    generateStationId() {
        let id = 1;
        while (this.stations.has(id)) {
            id++;
        }
        return id;
    }
    /**
     * Get connection health for all stations
     */
    getConnectionHealth() {
        return connectionManager_1.connectionManager.getAllHealth();
    }
    /**
     * List available connection endpoints
     * Note: Serial ports not available in cloud deployment
     */
    async listAvailableEndpoints() {
        return connectionManager_1.connectionManager.listAvailableEndpoints();
    }
}
exports.StationManager = StationManager;
exports.stationManager = new StationManager();
