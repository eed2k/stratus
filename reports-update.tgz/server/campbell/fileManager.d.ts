/**
 * Campbell Scientific File Manager
 * Handles file operations on dataloggers: listing, download, upload, delete, backup/restore
 */
import { EventEmitter } from 'events';
import { PakBusProtocol } from './pakbusProtocol';
export interface DataloggerFile {
    name: string;
    size: number;
    lastModified: Date;
    attributes: FileAttributes;
    path: string;
}
export interface FileAttributes {
    readOnly: boolean;
    hidden: boolean;
    system: boolean;
    paused: boolean;
    runOnPowerUp: boolean;
    runNow: boolean;
}
export interface TransferProgress {
    fileName: string;
    totalBytes: number;
    transferredBytes: number;
    percentComplete: number;
    bytesPerSecond: number;
    estimatedTimeRemaining: number;
    status: 'pending' | 'in-progress' | 'completed' | 'failed' | 'cancelled';
    error?: string;
}
export interface StorageInfo {
    device: string;
    totalBytes: number;
    usedBytes: number;
    freeBytes: number;
    percentUsed: number;
}
export interface BackupInfo {
    id: string;
    stationId: string;
    stationName: string;
    timestamp: Date;
    files: string[];
    totalSize: number;
    backupPath: string;
    notes?: string;
}
export declare class FileManager extends EventEmitter {
    private pakbus;
    private activeTransfers;
    private backupDir;
    private chunkSize;
    constructor(pakbus: PakBusProtocol, backupDir?: string);
    /**
     * Get a writable default backup directory (same logic as db.ts)
     */
    private getDefaultBackupDir;
    /**
     * List files on a storage device
     */
    listFiles(stationAddress: number, device?: string): Promise<DataloggerFile[]>;
    /**
     * Get information about a specific file
     */
    getFileInfo(stationAddress: number, filePath: string): Promise<DataloggerFile | null>;
    /**
     * Download a file from the datalogger
     * Includes path sanitization to prevent directory traversal attacks
     */
    downloadFile(stationAddress: number, remoteFilePath: string, localFilePath: string): Promise<boolean>;
    /**
     * Upload a file to the datalogger
     */
    uploadFile(stationAddress: number, localFilePath: string, remoteFilePath: string, options?: {
        compileRun?: boolean;
        setRunOnPowerUp?: boolean;
    }): Promise<boolean>;
    /**
     * Delete a file from the datalogger
     */
    deleteFile(stationAddress: number, filePath: string): Promise<boolean>;
    /**
     * Get storage device information
     */
    getStorageInfo(stationAddress: number, device?: string): Promise<StorageInfo>;
    /**
     * Create a backup of station files
     */
    createBackup(stationAddress: number, stationName: string, files?: string[], notes?: string): Promise<BackupInfo>;
    /**
     * Restore files from a backup
     */
    restoreBackup(stationAddress: number, backupId: string, files?: string[], options?: {
        compileRun?: boolean;
        setRunOnPowerUp?: boolean;
    }): Promise<boolean>;
    /**
     * List all available backups
     */
    listBackups(stationName?: string): BackupInfo[];
    /**
     * Delete a backup
     */
    deleteBackup(backupId: string): boolean;
    /**
     * Cancel an active transfer
     */
    cancelTransfer(transferId: string): boolean;
    /**
     * Get active transfer status
     */
    getTransferStatus(transferId: string): TransferProgress | undefined;
    /**
     * Get all active transfers
     */
    getActiveTransfers(): Map<string, TransferProgress>;
    private emitProgress;
    private loadBackupInfo;
    private buildDirListPayload;
    private buildFileInfoPayload;
    private buildGetFilePayload;
    private buildSendFileStartPayload;
    private buildSendFileChunkPayload;
    private buildCloseFilePayload;
    private buildFileCommandPayload;
    private buildStorageInfoPayload;
    private parseDirectoryListing;
    private parseFileAttributes;
    private parseFileInfo;
    private extractFileChunk;
    private parseStorageInfo;
}
export default FileManager;
