/**
 * Station Manager
 * Device discovery, configuration management, and program handling
 */
import { EventEmitter } from "events";
import { ConnectionConfig, ConnectionHealth } from "./connectionManager";
import { TableDefinition } from "./pakbusProtocol";
export interface StationInfo {
    id: number;
    name: string;
    serialNumber: string;
    model: string;
    osVersion: string;
    pakbusAddress: number;
    connectionType: string;
    connectionConfig: ConnectionConfig;
    status: "online" | "offline" | "connecting" | "error";
    lastSeen?: Date;
    batteryVoltage?: number;
    programName?: string;
    programSignature?: string;
    tables?: TableDefinition[];
}
export interface DiscoveryResult {
    address: number;
    type: string;
    stationType?: string;
    serialNumber?: string;
}
export interface ProgramInfo {
    name: string;
    signature: string;
    compileDate?: Date;
    size: number;
    running: boolean;
}
export declare class StationManager extends EventEmitter {
    private stations;
    private discoveryInProgress;
    constructor();
    /**
     * Setup connection manager events
     */
    private setupConnectionEvents;
    /**
     * Add a new station
     */
    addStation(name: string, config: ConnectionConfig): Promise<StationInfo>;
    /**
     * Remove a station
     */
    removeStation(stationId: number): Promise<void>;
    /**
     * Get station by ID
     */
    getStation(stationId: number): StationInfo | null;
    /**
     * Get all stations
     */
    getAllStations(): StationInfo[];
    /**
     * Update station configuration
     */
    updateStation(stationId: number, updates: Partial<StationInfo>): Promise<StationInfo | null>;
    /**
     * Discover stations
     */
    discoverStations(config: Partial<ConnectionConfig>): Promise<DiscoveryResult[]>;
    /**
     * Test connection to a station
     */
    testConnection(config: ConnectionConfig): Promise<{
        success: boolean;
        latency?: number;
        error?: string;
        stationInfo?: any;
    }>;
    /**
     * Refresh station information
     */
    refreshStationInfo(stationId: number): Promise<void>;
    /**
     * Sync station clock
     */
    syncClock(stationId: number): Promise<{
        success: boolean;
        offset?: number;
        error?: string;
    }>;
    /**
     * Get program information
     */
    getProgramInfo(stationId: number): Promise<ProgramInfo | null>;
    /**
     * Upload program to station
     */
    uploadProgram(stationId: number, programContent: Buffer, fileName?: string): Promise<{
        success: boolean;
        error?: string;
    }>;
    /**
     * Download program from station
     */
    downloadProgram(stationId: number, fileName?: string): Promise<{
        success: boolean;
        content?: Buffer;
        error?: string;
    }>;
    /**
     * Update station status
     */
    private updateStationStatus;
    /**
     * Generate unique station ID
     */
    private generateStationId;
    /**
     * Get connection health for all stations
     */
    getConnectionHealth(): ConnectionHealth[];
    /**
     * List available connection endpoints
     * Note: Serial ports not available in cloud deployment
     */
    listAvailableEndpoints(): Promise<Array<{
        type: string;
        description: string;
    }>>;
}
export declare const stationManager: StationManager;
