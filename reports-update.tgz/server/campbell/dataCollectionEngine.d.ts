/**
 * Data Collection Engine
 * Handles scheduled data collection, gap filling, and data processing
 */
import { EventEmitter } from "events";
export interface CollectionSchedule {
    stationId: number;
    tableName: string;
    schedule: string;
    enabled: boolean;
    lastCollection?: Date;
    nextCollection?: Date;
    recordsCollected?: number;
    retention?: number;
}
export interface DataProcessingRule {
    id: string;
    stationId: number;
    tableName: string;
    column: string;
    type: "scale" | "offset" | "calibration" | "qc" | "aggregate";
    parameters: Record<string, any>;
    enabled: boolean;
}
export interface CollectionResult {
    stationId: number;
    tableName: string;
    timestamp: Date;
    recordsCollected: number;
    success: boolean;
    error?: string;
    duration: number;
}
export declare class DataCollectionEngine extends EventEmitter {
    private schedules;
    private processingRules;
    private collectionHistory;
    private maxHistoryLength;
    private lastRecordNumbers;
    constructor();
    /**
     * Setup connection manager event handlers
     */
    private setupConnectionEvents;
    /**
     * Add collection schedule
     */
    addSchedule(schedule: CollectionSchedule): void;
    /**
     * Remove collection schedule
     */
    removeSchedule(stationId: number, tableName: string): void;
    /**
     * Enable/disable schedule
     */
    setScheduleEnabled(stationId: number, tableName: string, enabled: boolean): void;
    /**
     * Get all schedules for a station
     */
    getSchedules(stationId?: number): CollectionSchedule[];
    /**
     * Collect data from a specific table
     */
    collectTable(stationId: number, tableName: string): Promise<CollectionResult>;
    /**
     * Collect all tables for a station
     */
    collectAll(stationId: number): Promise<CollectionResult[]>;
    /**
     * Check for data gaps and fill them
     */
    checkForGaps(stationId: number): Promise<void>;
    /**
     * Fill data gaps for a table
     */
    fillGaps(stationId: number, tableName: string): Promise<number>;
    /**
     * Add data processing rule
     */
    addProcessingRule(rule: DataProcessingRule): void;
    /**
     * Remove data processing rule
     */
    removeProcessingRule(ruleId: string): void;
    /**
     * Get processing rules for a table
     */
    getProcessingRules(stationId: number, tableName?: string): DataProcessingRule[];
    /**
     * Apply processing rules to a record
     */
    private applyProcessingRules;
    /**
     * Process incoming data (push mode)
     */
    private processIncomingData;
    /**
     * Add result to history
     */
    private addToHistory;
    /**
     * Get collection history
     */
    getHistory(stationId?: number, tableName?: string, limit?: number): CollectionResult[];
    /**
     * Get collection statistics
     */
    getStatistics(stationId?: number): {
        totalCollections: number;
        successfulCollections: number;
        failedCollections: number;
        totalRecords: number;
        averageDuration: number;
    };
    /**
     * Stop all scheduled tasks
     */
    stopAll(): void;
    /**
     * Start all enabled scheduled tasks
     */
    startAll(): void;
}
export declare const dataCollectionEngine: DataCollectionEngine;
