"use strict";
// Stratus Weather Server
// Created by Lukas Esterhuizen
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.dataCollectionEngine = exports.DataCollectionEngine = void 0;
/// <reference types="node" />
/**
 * Data Collection Engine
 * Handles scheduled data collection, gap filling, and data processing
 */
const events_1 = require("events");
const connectionManager_1 = require("./connectionManager");
const cron = __importStar(require("node-cron"));
class DataCollectionEngine extends events_1.EventEmitter {
    constructor() {
        super();
        this.schedules = new Map();
        this.processingRules = new Map();
        this.collectionHistory = [];
        this.maxHistoryLength = 1000;
        // Gap tracking
        this.lastRecordNumbers = new Map();
        this.setupConnectionEvents();
    }
    /**
     * Setup connection manager event handlers
     */
    setupConnectionEvents() {
        connectionManager_1.connectionManager.on("connected", (stationId) => {
            // Check for data gaps when connection is restored
            this.checkForGaps(stationId);
        });
        connectionManager_1.connectionManager.on("data", (stationId, data) => {
            this.processIncomingData(stationId, data);
        });
    }
    /**
     * Add collection schedule
     */
    addSchedule(schedule) {
        const key = `${schedule.stationId}-${schedule.tableName}`;
        // Remove existing schedule if any
        this.removeSchedule(schedule.stationId, schedule.tableName);
        // Create cron task
        let task = null;
        if (schedule.enabled) {
            task = cron.schedule(schedule.schedule, () => {
                this.collectTable(schedule.stationId, schedule.tableName);
            });
        }
        this.schedules.set(key, { schedule, task });
        this.emit("schedule-added", schedule);
    }
    /**
     * Remove collection schedule
     */
    removeSchedule(stationId, tableName) {
        const key = `${stationId}-${tableName}`;
        const existing = this.schedules.get(key);
        if (existing) {
            if (existing.task) {
                existing.task.stop();
            }
            this.schedules.delete(key);
            this.emit("schedule-removed", { stationId, tableName });
        }
    }
    /**
     * Enable/disable schedule
     */
    setScheduleEnabled(stationId, tableName, enabled) {
        const key = `${stationId}-${tableName}`;
        const existing = this.schedules.get(key);
        if (existing) {
            existing.schedule.enabled = enabled;
            if (enabled && !existing.task) {
                existing.task = cron.schedule(existing.schedule.schedule, () => {
                    this.collectTable(stationId, tableName);
                });
            }
            else if (!enabled && existing.task) {
                existing.task.stop();
                existing.task = null;
            }
            this.emit("schedule-updated", existing.schedule);
        }
    }
    /**
     * Get all schedules for a station
     */
    getSchedules(stationId) {
        const schedules = [];
        for (const [key, value] of this.schedules) {
            if (stationId === undefined || value.schedule.stationId === stationId) {
                schedules.push(value.schedule);
            }
        }
        return schedules;
    }
    /**
     * Collect data from a specific table
     */
    async collectTable(stationId, tableName) {
        const startTime = Date.now();
        const result = {
            stationId,
            tableName,
            timestamp: new Date(),
            recordsCollected: 0,
            success: false,
            duration: 0,
        };
        try {
            const pakbus = connectionManager_1.connectionManager.getPakBus(stationId);
            if (!pakbus) {
                throw new Error("Station not connected");
            }
            // Get last record number to collect only new records
            const lastRecordKey = `${stationId}-${tableName}`;
            const lastRecord = this.lastRecordNumbers.get(lastRecordKey) || 0;
            // Collect data
            const collectResult = await pakbus.collectData(tableName, lastRecord + 1);
            if (!collectResult.success) {
                throw new Error(collectResult.error || "Collection failed");
            }
            const records = collectResult.data;
            result.recordsCollected = records.length;
            result.success = true;
            // Update last record number
            if (records.length > 0) {
                const maxRecord = Math.max(...records.map(r => r.recordNumber));
                this.lastRecordNumbers.set(lastRecordKey, maxRecord);
            }
            // Process records
            for (const record of records) {
                const processedRecord = this.applyProcessingRules(stationId, tableName, record);
                this.emit("data-collected", stationId, tableName, processedRecord);
            }
            // Update schedule info
            const scheduleKey = `${stationId}-${tableName}`;
            const schedule = this.schedules.get(scheduleKey);
            if (schedule) {
                schedule.schedule.lastCollection = new Date();
                schedule.schedule.recordsCollected = (schedule.schedule.recordsCollected || 0) + records.length;
            }
        }
        catch (error) {
            result.success = false;
            result.error = error.message;
            this.emit("collection-error", stationId, tableName, error);
        }
        result.duration = Date.now() - startTime;
        this.addToHistory(result);
        this.emit("collection-complete", result);
        return result;
    }
    /**
     * Collect all tables for a station
     */
    async collectAll(stationId) {
        const results = [];
        const schedules = this.getSchedules(stationId);
        for (const schedule of schedules) {
            const result = await this.collectTable(stationId, schedule.tableName);
            results.push(result);
        }
        return results;
    }
    /**
     * Check for data gaps and fill them
     */
    async checkForGaps(stationId) {
        const schedules = this.getSchedules(stationId);
        for (const schedule of schedules) {
            await this.fillGaps(stationId, schedule.tableName);
        }
    }
    /**
     * Fill data gaps for a table
     */
    async fillGaps(stationId, tableName) {
        let gapsFilled = 0;
        try {
            const pakbus = connectionManager_1.connectionManager.getPakBus(stationId);
            if (!pakbus)
                return 0;
            // Get table definitions to understand record structure
            const tableDefsResult = await pakbus.getTableDefinitions();
            if (!tableDefsResult.success)
                return 0;
            const tableDef = tableDefsResult.data
                .find(t => t.tableName === tableName);
            if (!tableDef)
                return 0;
            // Calculate expected records based on last collection and interval
            const lastRecordKey = `${stationId}-${tableName}`;
            const lastRecord = this.lastRecordNumbers.get(lastRecordKey) || 0;
            // Request any missing records
            const collectResult = await pakbus.collectData(tableName, lastRecord + 1);
            if (collectResult.success) {
                const records = collectResult.data;
                gapsFilled = records.length;
                for (const record of records) {
                    const processedRecord = this.applyProcessingRules(stationId, tableName, record);
                    this.emit("gap-filled", stationId, tableName, processedRecord);
                }
                // Update last record
                if (records.length > 0) {
                    const maxRecord = Math.max(...records.map(r => r.recordNumber));
                    this.lastRecordNumbers.set(lastRecordKey, maxRecord);
                }
            }
        }
        catch (error) {
            console.error(`Error filling gaps for ${stationId}/${tableName}:`, error);
        }
        return gapsFilled;
    }
    /**
     * Add data processing rule
     */
    addProcessingRule(rule) {
        this.processingRules.set(rule.id, rule);
        this.emit("rule-added", rule);
    }
    /**
     * Remove data processing rule
     */
    removeProcessingRule(ruleId) {
        this.processingRules.delete(ruleId);
        this.emit("rule-removed", ruleId);
    }
    /**
     * Get processing rules for a table
     */
    getProcessingRules(stationId, tableName) {
        const rules = [];
        for (const rule of this.processingRules.values()) {
            if (rule.stationId === stationId) {
                if (tableName === undefined || rule.tableName === tableName) {
                    rules.push(rule);
                }
            }
        }
        return rules;
    }
    /**
     * Apply processing rules to a record
     */
    applyProcessingRules(stationId, tableName, record) {
        const rules = this.getProcessingRules(stationId, tableName);
        const processed = { ...record, values: { ...record.values } };
        for (const rule of rules) {
            if (!rule.enabled)
                continue;
            const value = processed.values[rule.column];
            if (value === undefined)
                continue;
            switch (rule.type) {
                case "scale":
                    if (typeof value === "number") {
                        processed.values[rule.column] = value * (rule.parameters.factor || 1);
                    }
                    break;
                case "offset":
                    if (typeof value === "number") {
                        processed.values[rule.column] = value + (rule.parameters.offset || 0);
                    }
                    break;
                case "calibration":
                    if (typeof value === "number") {
                        // Apply polynomial calibration: y = a0 + a1*x + a2*x^2 + ...
                        const coeffs = rule.parameters.coefficients || [0, 1];
                        let result = 0;
                        for (let i = 0; i < coeffs.length; i++) {
                            result += coeffs[i] * Math.pow(value, i);
                        }
                        processed.values[rule.column] = result;
                    }
                    break;
                case "qc":
                    if (typeof value === "number") {
                        // Quality control - flag or remove out-of-range values
                        const min = rule.parameters.min ?? -Infinity;
                        const max = rule.parameters.max ?? Infinity;
                        if (value < min || value > max) {
                            if (rule.parameters.action === "null") {
                                processed.values[rule.column] = null;
                            }
                            else if (rule.parameters.action === "flag") {
                                processed.values[`${rule.column}_qc`] = "out_of_range";
                            }
                        }
                    }
                    break;
            }
        }
        return processed;
    }
    /**
     * Process incoming data (push mode)
     */
    processIncomingData(stationId, data) {
        // Handle pushed data from station
        if (data.tableName && data.records) {
            for (const record of data.records) {
                const processed = this.applyProcessingRules(stationId, data.tableName, record);
                this.emit("data-received", stationId, data.tableName, processed);
            }
            // Update last record number
            const lastRecordKey = `${stationId}-${data.tableName}`;
            if (data.records.length > 0) {
                const maxRecord = Math.max(...data.records.map((r) => r.recordNumber));
                const currentLast = this.lastRecordNumbers.get(lastRecordKey) || 0;
                if (maxRecord > currentLast) {
                    this.lastRecordNumbers.set(lastRecordKey, maxRecord);
                }
            }
        }
    }
    /**
     * Add result to history
     */
    addToHistory(result) {
        this.collectionHistory.unshift(result);
        if (this.collectionHistory.length > this.maxHistoryLength) {
            this.collectionHistory.pop();
        }
    }
    /**
     * Get collection history
     */
    getHistory(stationId, tableName, limit = 100) {
        let history = this.collectionHistory;
        if (stationId !== undefined) {
            history = history.filter(h => h.stationId === stationId);
        }
        if (tableName !== undefined) {
            history = history.filter(h => h.tableName === tableName);
        }
        return history.slice(0, limit);
    }
    /**
     * Get collection statistics
     */
    getStatistics(stationId) {
        let history = this.collectionHistory;
        if (stationId !== undefined) {
            history = history.filter(h => h.stationId === stationId);
        }
        const successful = history.filter(h => h.success);
        const failed = history.filter(h => !h.success);
        const totalRecords = successful.reduce((sum, h) => sum + h.recordsCollected, 0);
        const avgDuration = history.length > 0
            ? history.reduce((sum, h) => sum + h.duration, 0) / history.length
            : 0;
        return {
            totalCollections: history.length,
            successfulCollections: successful.length,
            failedCollections: failed.length,
            totalRecords,
            averageDuration: Math.round(avgDuration),
        };
    }
    /**
     * Stop all scheduled tasks
     */
    stopAll() {
        for (const [key, value] of this.schedules) {
            if (value.task) {
                value.task.stop();
            }
        }
        this.emit("stopped");
    }
    /**
     * Start all enabled scheduled tasks
     */
    startAll() {
        for (const [key, value] of this.schedules) {
            if (value.schedule.enabled && !value.task) {
                value.task = cron.schedule(value.schedule.schedule, () => {
                    this.collectTable(value.schedule.stationId, value.schedule.tableName);
                });
            }
        }
        this.emit("started");
    }
}
exports.DataCollectionEngine = DataCollectionEngine;
exports.dataCollectionEngine = new DataCollectionEngine();
