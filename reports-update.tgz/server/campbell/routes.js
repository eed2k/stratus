"use strict";
// Stratus Weather Server
// Created by Lukas Esterhuizen
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerCampbellRoutes = registerCampbellRoutes;
const dataCollectionService_1 = require("./dataCollectionService");
const localAuth_1 = require("../localAuth");
const localStorage_1 = require("../localStorage");
const zod_1 = require("zod");
const emailService_1 = require("../services/emailService");
// Local schema definitions
const insertSensorSchema = zod_1.z.object({
    stationId: zod_1.z.number(),
    name: zod_1.z.string(),
    type: zod_1.z.string(),
    unit: zod_1.z.string(),
    minValue: zod_1.z.number().optional(),
    maxValue: zod_1.z.number().optional()
});
const insertCalibrationRecordSchema = zod_1.z.object({
    sensorId: zod_1.z.number(),
    calibratedAt: zod_1.z.coerce.date(),
    values: zod_1.z.any(),
    notes: zod_1.z.string().optional()
});
const insertMaintenanceEventSchema = zod_1.z.object({
    stationId: zod_1.z.number(),
    eventType: zod_1.z.string(),
    description: zod_1.z.string(),
    scheduledAt: zod_1.z.coerce.date().optional(),
    completedAt: zod_1.z.coerce.date().optional()
});
const insertAlarmSchema = zod_1.z.object({
    stationId: zod_1.z.number(),
    name: zod_1.z.string(),
    condition: zod_1.z.string(),
    threshold: zod_1.z.number(),
    severity: zod_1.z.enum(['info', 'warning', 'error', 'critical']),
    notificationEmails: zod_1.z.array(zod_1.z.string().email()).optional(), // Email recipients
    enabled: zod_1.z.boolean().optional()
});
const insertDataQualityFlagSchema = zod_1.z.object({
    weatherDataId: zod_1.z.number(),
    flagType: zod_1.z.string(),
    description: zod_1.z.string().optional()
});
function registerCampbellRoutes(app) {
    // 
    /**
     * Start data collection for a station
     */
    app.post("/api/campbell/stations/:stationId/start", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const stationId = parseInt(req.params.stationId);
            const station = await localStorage_1.storage.getStation(stationId);
            if (!station) {
                return res.status(404).json({ message: "Station not found" });
            }
            const connectionConfig = {
                stationId: station.id,
                connectionType: station.connectionType || 'tcp',
                protocol: station.protocol || 'pakbus',
                host: station.ipAddress || undefined,
                port: station.port || 6785,
                serialPort: station.serialPort || undefined,
                baudRate: station.baudRate || 115200,
                pakbusAddress: station.pakbusAddress || 1,
                securityCode: station.securityCode || 0,
                dataTable: station.dataTable || 'OneMin',
                pollInterval: station.pollInterval || 60,
                autoReconnect: true,
                reconnectInterval: 30,
                maxReconnectAttempts: 10,
            };
            await dataCollectionService_1.dataCollectionService.startStation({
                stationId: station.id,
                enabled: true,
                connectionConfig,
            });
            res.json({ message: "Data collection started", stationId });
        }
        catch (error) {
            console.error("Error starting station:", error);
            res.status(500).json({ message: error.message || "Failed to start station" });
        }
    });
    /**
     * Stop data collection for a station
     */
    app.post("/api/campbell/stations/:stationId/stop", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const stationId = parseInt(req.params.stationId);
            await dataCollectionService_1.dataCollectionService.stopStation(stationId);
            res.json({ message: "Data collection stopped", stationId });
        }
        catch (error) {
            console.error("Error stopping station:", error);
            res.status(500).json({ message: error.message || "Failed to stop station" });
        }
    });
    /**
     * Restart data collection for a station
     */
    app.post("/api/campbell/stations/:stationId/restart", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const stationId = parseInt(req.params.stationId);
            await dataCollectionService_1.dataCollectionService.restartStation(stationId);
            res.json({ message: "Data collection restarted", stationId });
        }
        catch (error) {
            console.error("Error restarting station:", error);
            res.status(500).json({ message: error.message || "Failed to restart station" });
        }
    });
    /**
     * Get station connection status
     */
    app.get("/api/campbell/stations/:stationId/status", async (req, res) => {
        try {
            const stationId = parseInt(req.params.stationId);
            const status = dataCollectionService_1.dataCollectionService.getStationStatus(stationId);
            if (!status) {
                return res.status(404).json({ message: "Station status not found" });
            }
            res.json(status);
        }
        catch (error) {
            console.error("Error getting station status:", error);
            res.status(500).json({ message: error.message || "Failed to get station status" });
        }
    });
    /**
     * Get all station statuses
     */
    app.get("/api/campbell/stations/status", async (req, res) => {
        try {
            const statuses = dataCollectionService_1.dataCollectionService.getAllStationStatuses();
            res.json(statuses);
        }
        catch (error) {
            console.error("Error getting station statuses:", error);
            res.status(500).json({ message: error.message || "Failed to get station statuses" });
        }
    });
    /**
     * Manually collect data from a station
     */
    app.post("/api/campbell/stations/:stationId/collect", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const stationId = parseInt(req.params.stationId);
            const { tableName } = req.body;
            const records = await dataCollectionService_1.dataCollectionService.collectDataNow(stationId, tableName);
            res.json({ records, count: records.length });
        }
        catch (error) {
            console.error("Error collecting data:", error);
            res.status(500).json({ message: error.message || "Failed to collect data" });
        }
    });
    /**
     * Get table definition from datalogger
     */
    app.get("/api/campbell/stations/:stationId/tables/:tableName", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const stationId = parseInt(req.params.stationId);
            const tableName = req.params.tableName;
            const tableDef = await dataCollectionService_1.dataCollectionService.getTableDefinition(stationId, tableName);
            res.json(tableDef);
        }
        catch (error) {
            console.error("Error getting table definition:", error);
            res.status(500).json({ message: error.message || "Failed to get table definition" });
        }
    });
    // 
    /**
     * Get all sensors for a station
     */
    app.get("/api/stations/:stationId/sensors", async (req, res) => {
        try {
            const stationId = parseInt(req.params.stationId);
            const sensors = await localStorage_1.storage.getSensors(stationId);
            res.json(sensors);
        }
        catch (error) {
            console.error("Error fetching sensors:", error);
            res.status(500).json({ message: "Failed to fetch sensors" });
        }
    });
    /**
     * Create a new sensor
     */
    app.post("/api/stations/:stationId/sensors", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const stationId = parseInt(req.params.stationId);
            const parsed = insertSensorSchema.safeParse({ ...req.body, stationId });
            if (!parsed.success) {
                return res.status(400).json({ message: "Invalid sensor data", errors: parsed.error.errors });
            }
            const sensor = await localStorage_1.storage.createSensor(parsed.data);
            res.status(201).json(sensor);
        }
        catch (error) {
            console.error("Error creating sensor:", error);
            res.status(500).json({ message: "Failed to create sensor" });
        }
    });
    /**
     * Update a sensor
     */
    app.patch("/api/sensors/:sensorId", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const sensorId = parseInt(req.params.sensorId);
            const sensor = await localStorage_1.storage.updateSensor(sensorId, req.body);
            if (!sensor) {
                return res.status(404).json({ message: "Sensor not found" });
            }
            res.json(sensor);
        }
        catch (error) {
            console.error("Error updating sensor:", error);
            res.status(500).json({ message: "Failed to update sensor" });
        }
    });
    /**
     * Delete a sensor
     */
    app.delete("/api/sensors/:sensorId", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const sensorId = parseInt(req.params.sensorId);
            const deleted = await localStorage_1.storage.deleteSensor(sensorId);
            if (!deleted) {
                return res.status(404).json({ message: "Sensor not found" });
            }
            res.status(204).send();
        }
        catch (error) {
            console.error("Error deleting sensor:", error);
            res.status(500).json({ message: "Failed to delete sensor" });
        }
    });
    // 
    /**
     * Get calibration records for a sensor
     */
    app.get("/api/sensors/:sensorId/calibrations", async (req, res) => {
        try {
            const sensorId = parseInt(req.params.sensorId);
            const calibrations = await localStorage_1.storage.getCalibrationRecords(sensorId);
            res.json(calibrations);
        }
        catch (error) {
            console.error("Error fetching calibrations:", error);
            res.status(500).json({ message: "Failed to fetch calibrations" });
        }
    });
    /**
     * Get calibrations due soon (within specified days)
     */
    app.get("/api/stations/:stationId/calibrations/due", async (req, res) => {
        try {
            const stationId = parseInt(req.params.stationId);
            const daysAhead = parseInt(req.query.days) || 90;
            const calibrations = await localStorage_1.storage.getCalibrationsDue(stationId, daysAhead);
            res.json(calibrations);
        }
        catch (error) {
            console.error("Error fetching due calibrations:", error);
            res.status(500).json({ message: "Failed to fetch due calibrations" });
        }
    });
    /**
     * Create a calibration record
     */
    app.post("/api/sensors/:sensorId/calibrations", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const sensorId = parseInt(req.params.sensorId);
            const parsed = insertCalibrationRecordSchema.safeParse({ ...req.body, sensorId });
            if (!parsed.success) {
                return res.status(400).json({ message: "Invalid calibration data", errors: parsed.error.errors });
            }
            const calibration = await localStorage_1.storage.createCalibrationRecord(parsed.data);
            res.status(201).json(calibration);
        }
        catch (error) {
            console.error("Error creating calibration:", error);
            res.status(500).json({ message: "Failed to create calibration" });
        }
    });
    // 
    /**
     * Get maintenance events for a station
     */
    app.get("/api/stations/:stationId/maintenance", async (req, res) => {
        try {
            const stationId = parseInt(req.params.stationId);
            const { type, startDate, endDate } = req.query;
            const events = await localStorage_1.storage.getMaintenanceEvents(stationId, type, startDate ? new Date(startDate) : undefined, endDate ? new Date(endDate) : undefined);
            res.json(events);
        }
        catch (error) {
            console.error("Error fetching maintenance events:", error);
            res.status(500).json({ message: "Failed to fetch maintenance events" });
        }
    });
    /**
     * Create a maintenance event
     */
    app.post("/api/stations/:stationId/maintenance", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const stationId = parseInt(req.params.stationId);
            const parsed = insertMaintenanceEventSchema.safeParse({ ...req.body, stationId });
            if (!parsed.success) {
                return res.status(400).json({ message: "Invalid maintenance data", errors: parsed.error.errors });
            }
            const event = await localStorage_1.storage.createMaintenanceEvent(parsed.data);
            res.status(201).json(event);
        }
        catch (error) {
            console.error("Error creating maintenance event:", error);
            res.status(500).json({ message: "Failed to create maintenance event" });
        }
    });
    // 
    // NOTE: Top-level alarm CRUD (/api/alarms, /api/alarms/:id) is handled
    // in server/routes.ts with optionalAuth. Only station-scoped alarm
    // endpoints are defined here to avoid route shadowing.
    /**
     * Get alarms for a station
     */
    app.get("/api/stations/:stationId/alarms", async (req, res) => {
        try {
            const stationId = parseInt(req.params.stationId);
            const alarms = await localStorage_1.storage.getAlarms(stationId);
            res.json(alarms);
        }
        catch (error) {
            console.error("Error fetching alarms:", error);
            res.status(500).json({ message: "Failed to fetch alarms" });
        }
    });
    /**
     * Create an alarm for a specific station
     */
    app.post("/api/stations/:stationId/alarms", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const stationId = parseInt(req.params.stationId);
            const parsed = insertAlarmSchema.safeParse({ ...req.body, stationId });
            if (!parsed.success) {
                return res.status(400).json({ message: "Invalid alarm data", errors: parsed.error.errors });
            }
            const alarm = await localStorage_1.storage.createAlarm(parsed.data);
            res.status(201).json(alarm);
        }
        catch (error) {
            console.error("Error creating alarm:", error);
            res.status(500).json({ message: "Failed to create alarm" });
        }
    });
    /**
     * Get active alarm events
     */
    app.get("/api/stations/:stationId/alarms/events/active", async (req, res) => {
        try {
            const stationId = parseInt(req.params.stationId);
            const events = await localStorage_1.storage.getActiveAlarmEvents(stationId);
            res.json(events);
        }
        catch (error) {
            console.error("Error fetching active alarm events:", error);
            res.status(500).json({ message: "Failed to fetch active alarm events" });
        }
    });
    /**
     * Acknowledge an alarm event
     */
    app.post("/api/alarms/events/:eventId/acknowledge", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const eventId = parseInt(req.params.eventId);
            const { acknowledgedBy, notes } = req.body;
            const event = await localStorage_1.storage.acknowledgeAlarmEvent(eventId, acknowledgedBy, notes);
            res.json(event);
        }
        catch (error) {
            console.error("Error acknowledging alarm:", error);
            res.status(500).json({ message: "Failed to acknowledge alarm" });
        }
    });
    // 
    /**
     * Get data quality flags for a station
     */
    app.get("/api/stations/:stationId/quality-flags", async (req, res) => {
        try {
            const stationId = parseInt(req.params.stationId);
            const { startTime, endTime } = req.query;
            const flags = await localStorage_1.storage.getDataQualityFlags(stationId, startTime ? new Date(startTime) : undefined, endTime ? new Date(endTime) : undefined);
            res.json(flags);
        }
        catch (error) {
            console.error("Error fetching quality flags:", error);
            res.status(500).json({ message: "Failed to fetch quality flags" });
        }
    });
    /**
     * Create a data quality flag
     */
    app.post("/api/stations/:stationId/quality-flags", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const stationId = parseInt(req.params.stationId);
            const parsed = insertDataQualityFlagSchema.safeParse({ ...req.body, stationId });
            if (!parsed.success) {
                return res.status(400).json({ message: "Invalid quality flag data", errors: parsed.error.errors });
            }
            const flag = await localStorage_1.storage.createDataQualityFlag(parsed.data);
            res.status(201).json(flag);
        }
        catch (error) {
            console.error("Error creating quality flag:", error);
            res.status(500).json({ message: "Failed to create quality flag" });
        }
    });
    // 
    /**
     * Get configuration change history for a station
     */
    app.get("/api/stations/:stationId/config-history", async (req, res) => {
        try {
            const stationId = parseInt(req.params.stationId);
            const history = await localStorage_1.storage.getConfigurationHistory(stationId);
            res.json(history);
        }
        catch (error) {
            console.error("Error fetching config history:", error);
            res.status(500).json({ message: "Failed to fetch configuration history" });
        }
    });
    // 
    /**
     * Get all station groups
     */
    app.get("/api/station-groups", async (req, res) => {
        try {
            const groups = await localStorage_1.storage.getStationGroups();
            res.json(groups);
        }
        catch (error) {
            console.error("Error fetching station groups:", error);
            res.status(500).json({ message: "Failed to fetch station groups" });
        }
    });
    /**
     * Create a station group
     */
    app.post("/api/station-groups", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const group = await localStorage_1.storage.createStationGroup(req.body);
            res.status(201).json(group);
        }
        catch (error) {
            console.error("Error creating station group:", error);
            res.status(500).json({ message: "Failed to create station group" });
        }
    });
    /**
     * Add station to group
     */
    app.post("/api/station-groups/:groupId/stations/:stationId", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const groupId = parseInt(req.params.groupId);
            const stationId = parseInt(req.params.stationId);
            await localStorage_1.storage.addStationToGroup(groupId, stationId);
            res.json({ message: "Station added to group" });
        }
        catch (error) {
            console.error("Error adding station to group:", error);
            res.status(500).json({ message: "Failed to add station to group" });
        }
    });
    /**
     * Remove station from group
     */
    app.delete("/api/station-groups/:groupId/stations/:stationId", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const groupId = parseInt(req.params.groupId);
            const stationId = parseInt(req.params.stationId);
            await localStorage_1.storage.removeStationFromGroup(groupId, stationId);
            res.status(204).send();
        }
        catch (error) {
            console.error("Error removing station from group:", error);
            res.status(500).json({ message: "Failed to remove station from group" });
        }
    });
    // 
    /**
     * Check email configuration status
     */
    app.get("/api/email/status", async (req, res) => {
        res.json({
            configured: (0, emailService_1.isEmailConfigured)(),
            provider: 'MailerSend',
        });
    });
    /**
     * Send test email to verify configuration
     */
    app.post("/api/email/test", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const { email } = req.body;
            if (!email || typeof email !== 'string' || !email.includes('@')) {
                return res.status(400).json({ message: "Valid email address required" });
            }
            if (!(0, emailService_1.isEmailConfigured)()) {
                return res.status(503).json({
                    message: "Email not configured. Set SENDGRID_API_KEY and SENDGRID_FROM_EMAIL environment variables.",
                    configured: false
                });
            }
            const success = await (0, emailService_1.sendTestEmail)(email);
            if (success) {
                res.json({ message: "Test email sent successfully", email });
            }
            else {
                res.status(500).json({ message: "Failed to send test email" });
            }
        }
        catch (error) {
            console.error("Error sending test email:", error);
            res.status(500).json({ message: "Failed to send test email" });
        }
    });
    /**
     * Manually trigger an alarm email notification (for testing)
     */
    app.post("/api/alarms/:alarmId/notify", localAuth_1.isAuthenticated, async (req, res) => {
        try {
            const alarmId = parseInt(req.params.alarmId);
            const { emails, currentValue } = req.body;
            if (!emails || !Array.isArray(emails) || emails.length === 0) {
                return res.status(400).json({ message: "At least one email recipient required" });
            }
            // Get alarm details
            const alarm = await localStorage_1.storage.getAlarm(alarmId);
            if (!alarm) {
                return res.status(404).json({ message: "Alarm not found" });
            }
            // Get station details
            const station = await localStorage_1.storage.getStation(alarm.stationId);
            if (!station) {
                return res.status(404).json({ message: "Station not found" });
            }
            const success = await (0, emailService_1.sendAlarmEmail)(emails, {
                stationName: station.name,
                stationId: station.id,
                alarmName: alarm.name,
                severity: alarm.severity,
                condition: alarm.condition,
                threshold: alarm.threshold,
                currentValue: currentValue ?? alarm.threshold,
                unit: '', // Would come from sensor config
                triggeredAt: new Date(),
            });
            if (success) {
                res.json({ message: "Alarm notification sent", recipients: emails });
            }
            else {
                res.status(500).json({ message: "Failed to send alarm notification" });
            }
        }
        catch (error) {
            console.error("Error sending alarm notification:", error);
            res.status(500).json({ message: "Failed to send alarm notification" });
        }
    });
}
