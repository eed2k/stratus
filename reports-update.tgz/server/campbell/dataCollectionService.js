"use strict";
// Stratus Weather Server
// Created by Lukas Esterhuizen
Object.defineProperty(exports, "__esModule", { value: true });
exports.dataCollectionService = exports.DataCollectionService = void 0;
/**
 * Data Collection Service
 * Manages data collection from Campbell Scientific dataloggers
 */
const events_1 = require("events");
const connectionManager_1 = require("./connectionManager");
const localStorage_1 = require("../localStorage");
class DataCollectionService extends events_1.EventEmitter {
    constructor() {
        super();
        this.activeStations = new Map();
        this.dataBuffers = new Map();
        this.flushTimers = new Map();
        this.stationStatuses = new Map();
        this.BUFFER_SIZE = 100;
        this.FLUSH_INTERVAL = 10000; // 10 seconds
        this.connectionManager = new connectionManager_1.ConnectionManager();
        this.setupConnectionManagerListeners();
    }
    /**
     * Setup listeners for connection manager events
     */
    setupConnectionManagerListeners() {
        this.connectionManager.on('connected', ({ stationId }) => {
            console.log(`Station ${stationId} connected`);
            this.updateStationStatusField(stationId, { isConnected: true, lastConnectionTime: new Date() });
            this.emit('station-connected', stationId);
        });
        this.connectionManager.on('disconnected', ({ stationId }) => {
            console.log(`Station ${stationId} disconnected`);
            this.updateStationStatusField(stationId, { isConnected: false });
            this.emit('station-disconnected', stationId);
        });
        this.connectionManager.on('data', async ({ stationId, records, tableName }) => {
            await this.handleIncomingData(stationId, records, tableName);
        });
        this.connectionManager.on('error', ({ stationId, error }) => {
            console.error(`Station ${stationId} error:`, error);
            this.emit('station-error', { stationId, error });
        });
        this.connectionManager.on('reconnecting', ({ stationId, attempt }) => {
            console.log(`Station ${stationId} reconnecting (attempt ${attempt})`);
            this.emit('station-reconnecting', { stationId, attempt });
        });
        this.connectionManager.on('reconnect-failed', ({ stationId, attempts }) => {
            console.error(`Station ${stationId} reconnection failed after ${attempts} attempts`);
            this.emit('station-reconnect-failed', { stationId, attempts });
        });
    }
    /**
     * Update station status field
     */
    updateStationStatusField(stationId, updates) {
        const current = this.stationStatuses.get(stationId) || { stationId, isConnected: false };
        this.stationStatuses.set(stationId, { ...current, ...updates });
    }
    /**
     * Convert config to ConnectionConfig format expected by connectionManager
     */
    toConnectionConfig(config) {
        return {
            type: config.connectionType || 'tcp',
            mode: 'pull',
            host: config.host,
            port: config.port || 6785,
            pakbusAddress: config.pakbusAddress || 1,
            securityCode: config.securityCode || 0,
        };
    }
    /**
     * Start data collection for a station
     */
    async startStation(config) {
        const { stationId, connectionConfig } = config;
        try {
            // Store configuration
            this.activeStations.set(stationId, config);
            // Initialise data buffer
            this.dataBuffers.set(stationId, []);
            // Initialise status
            this.stationStatuses.set(stationId, { stationId, isConnected: false });
            // Setup flush timer
            const flushTimer = setInterval(() => {
                this.flushDataBuffer(stationId);
            }, this.FLUSH_INTERVAL);
            this.flushTimers.set(stationId, flushTimer);
            // Add and connect to station
            const connConfig = this.toConnectionConfig(connectionConfig);
            await this.connectionManager.addConnection(stationId, connConfig);
            await this.connectionManager.connect(stationId);
            console.log(`Data collection started for station ${stationId}`);
        }
        catch (error) {
            console.error(`Failed to start station ${stationId}:`, error);
            throw error;
        }
    }
    /**
     * Stop data collection for a station
     */
    async stopStation(stationId) {
        try {
            // Flush remaining data
            await this.flushDataBuffer(stationId);
            // Clear flush timer
            const flushTimer = this.flushTimers.get(stationId);
            if (flushTimer) {
                clearInterval(flushTimer);
                this.flushTimers.delete(stationId);
            }
            // Disconnect
            await this.connectionManager.disconnect(stationId);
            await this.connectionManager.removeConnection(stationId);
            // Clean up
            this.activeStations.delete(stationId);
            this.dataBuffers.delete(stationId);
            this.stationStatuses.delete(stationId);
            console.log(`Data collection stopped for station ${stationId}`);
        }
        catch (error) {
            console.error(`Failed to stop station ${stationId}:`, error);
            throw error;
        }
    }
    /**
     * Handle incoming data from datalogger
     */
    async handleIncomingData(stationId, records, tableName) {
        if (!records || records.length === 0) {
            return;
        }
        console.log(`Received ${records.length} records from station ${stationId}, table ${tableName}`);
        // Update last data time
        this.updateStationStatusField(stationId, { lastDataTime: new Date() });
        // Transform records to weather data format
        const weatherDataRecords = records.map(record => this.transformToWeatherData(stationId, record, tableName));
        // Add to buffer
        const buffer = this.dataBuffers.get(stationId) || [];
        buffer.push(...weatherDataRecords);
        this.dataBuffers.set(stationId, buffer);
        // Flush if buffer is full
        if (buffer.length >= this.BUFFER_SIZE) {
            await this.flushDataBuffer(stationId);
        }
        // Emit real-time data event
        this.emit('data-received', {
            stationId,
            records: weatherDataRecords,
            tableName,
        });
    }
    /**
     * Transform Campbell Scientific data record to standard weather data format
     */
    transformToWeatherData(stationId, record, tableName) {
        // Map common Campbell Scientific field names
        const fieldMappings = {
            'AirTC': 'temperature',
            'AirTC_Avg': 'temperature',
            'Temp_C': 'temperature',
            'RH': 'humidity',
            'RH_Avg': 'humidity',
            'BP_mbar': 'pressure',
            'BP_mbar_Avg': 'pressure',
            'Press_mbar': 'pressure',
            'WS_ms': 'windSpeed',
            'WS_ms_Avg': 'windSpeed',
            'WindSpeed': 'windSpeed',
            'WindDir': 'windDirection',
            'WindDir_D1_WVT': 'windDirection',
            'WS_ms_Max': 'windGust',
            'WindGust': 'windGust',
            'Rain_mm_Tot': 'rainfall',
            'Rain_mm': 'rainfall',
            'SlrW': 'solarRadiation',
            'SlrW_Avg': 'solarRadiation',
            'Solar_Wm2': 'solarRadiation',
            'UV_Index': 'uvIndex',
            'DewPoint': 'dewPoint',
            'DewPt_C': 'dewPoint',
        };
        const data = {};
        // Map fields
        for (const [campbellField, standardField] of Object.entries(fieldMappings)) {
            if (record[campbellField] !== undefined && record[campbellField] !== null) {
                data[standardField] = record[campbellField];
            }
        }
        // Include all original fields in data
        for (const [key, value] of Object.entries(record)) {
            if (key !== 'timestamp' && value !== undefined && value !== null) {
                data[key] = value;
            }
        }
        // Calculate dew point if not present
        if (data.temperature !== undefined && data.humidity !== undefined && data.dewPoint === undefined) {
            data.dewPoint = this.calculateDewPoint(data.temperature, data.humidity);
        }
        return {
            stationId,
            tableName,
            timestamp: record.timestamp || new Date(),
            data,
        };
    }
    /**
     * Calculate dew point from temperature and humidity
     */
    calculateDewPoint(temperature, humidity) {
        const a = 17.27;
        const b = 237.7;
        const alpha = ((a * temperature) / (b + temperature)) + Math.log(humidity / 100);
        return (b * alpha) / (a - alpha);
    }
    /**
     * Flush data buffer to database
     */
    async flushDataBuffer(stationId) {
        const buffer = this.dataBuffers.get(stationId);
        if (!buffer || buffer.length === 0) {
            return;
        }
        try {
            // Insert data in batches
            const batchSize = 50;
            for (let i = 0; i < buffer.length; i += batchSize) {
                const batch = buffer.slice(i, i + batchSize);
                await Promise.all(batch.map(data => localStorage_1.storage.insertWeatherData(data)));
            }
            console.log(`Flushed ${buffer.length} records for station ${stationId}`);
            // Clear buffer
            this.dataBuffers.set(stationId, []);
            // Emit flush event
            this.emit('data-flushed', { stationId, count: buffer.length });
        }
        catch (error) {
            console.error(`Failed to flush data for station ${stationId}:`, error);
            this.emit('flush-error', { stationId, error });
        }
    }
    /**
     * Get station status
     */
    getStationStatus(stationId) {
        return this.stationStatuses.get(stationId);
    }
    /**
     * Get all station statuses
     */
    getAllStationStatuses() {
        return Array.from(this.stationStatuses.values());
    }
    /**
     * Manually collect data from a station
     */
    async collectDataNow(stationId, tableName) {
        const config = this.activeStations.get(stationId);
        if (!config) {
            throw new Error(`Station ${stationId} is not active`);
        }
        // Return empty array - actual collection happens via connection manager events
        return [];
    }
    /**
     * Get table definition from datalogger (stub)
     */
    async getTableDefinition(stationId, tableName) {
        return {
            tableName,
            columns: [],
            recordInterval: 60
        };
    }
    /**
     * Check if station is active
     */
    isStationActive(stationId) {
        return this.activeStations.has(stationId);
    }
    /**
     * Get active station IDs
     */
    getActiveStationIds() {
        return Array.from(this.activeStations.keys());
    }
    /**
     * Restart a station
     */
    async restartStation(stationId) {
        const config = this.activeStations.get(stationId);
        if (!config) {
            throw new Error(`Station ${stationId} is not active`);
        }
        await this.stopStation(stationId);
        await this.startStation(config);
    }
    /**
     * Stop all stations
     */
    async stopAll() {
        const stationIds = Array.from(this.activeStations.keys());
        await Promise.all(stationIds.map(id => this.stopStation(id)));
    }
    /**
     * Initialise service with stations from database
     */
    async initialize() {
        try {
            const stations = await localStorage_1.storage.getStations();
            for (const station of stations) {
                // Skip demo stations - they don't need real connections
                if (station.connectionType === 'demo') {
                    console.log(`Skipping demo station: ${station.name}`);
                    continue;
                }
                if (!station.isActive)
                    continue;
                const connectionConfig = typeof station.connectionConfig === 'string'
                    ? JSON.parse(station.connectionConfig || '{}')
                    : (station.connectionConfig || {});
                // Skip stations without a valid host/endpoint (import-only stations)
                const hasValidEndpoint = connectionConfig?.host || station.ipAddress;
                if (!hasValidEndpoint) {
                    console.log(`Skipping station ${station.id} (${station.name}) - no host configured (import-only)`);
                    continue;
                }
                const config = {
                    stationId: station.id,
                    enabled: true,
                    connectionConfig: {
                        stationId: station.id,
                        connectionType: station.connectionType || 'tcp',
                        host: connectionConfig?.host || station.ipAddress,
                        port: connectionConfig?.port || station.port || 6785,
                        serialPort: connectionConfig?.serialPort,
                        baudRate: connectionConfig?.baudRate || 115200,
                        pakbusAddress: station.pakbusAddress || 1,
                        securityCode: station.securityCode || 0,
                        dataTable: connectionConfig?.dataTable || 'OneMin',
                        pollInterval: connectionConfig?.pollInterval || 60,
                        autoReconnect: true,
                        reconnectInterval: 30,
                        maxReconnectAttempts: 10,
                    },
                };
                try {
                    await this.startStation(config);
                }
                catch (error) {
                    console.error(`Failed to start station ${station.id}:`, error);
                }
            }
            console.log(`Data collection service initialized with ${this.activeStations.size} stations`);
        }
        catch (error) {
            console.error('Failed to initialize data collection service:', error);
            throw error;
        }
    }
}
exports.DataCollectionService = DataCollectionService;
// Singleton instance
exports.dataCollectionService = new DataCollectionService();
