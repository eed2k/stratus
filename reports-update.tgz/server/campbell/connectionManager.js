"use strict";
// Stratus Weather Server
// Created by Lukas Esterhuizen
Object.defineProperty(exports, "__esModule", { value: true });
exports.connectionManager = exports.ConnectionManager = void 0;
/**
 * Connection Manager
 * Handles multiple connection types for Campbell Scientific stations
 * Supports Pull (active polling) and Push (passive receive) modes
 *
 * CLOUD DEPLOYMENT NOTE:
 * This version is designed for cloud deployment where direct serial
 * connections are not available. All connections use TCP/IP:
 * - TCP: Direct socket connection to station's TCP interface
 * - GSM/4G: Connect to cellular modem's TCP gateway endpoint
 * - LoRa: Connect to LoRaWAN network server via TCP/IP
 */
const events_1 = require("events");
const net_1 = require("net");
const pakbusProtocol_1 = require("./pakbusProtocol");
class ConnectionManager extends events_1.EventEmitter {
    constructor() {
        super();
        this.connections = new Map();
        this.discoveryInProgress = false;
    }
    /**
     * Add a new station connection
     */
    async addConnection(stationId, config) {
        if (this.connections.has(stationId)) {
            await this.removeConnection(stationId);
        }
        const pakbusConfig = {
            address: config.pakbusAddress,
            securityCode: config.securityCode,
            neighborAddress: config.neighborAddress,
        };
        const connection = {
            config,
            transport: null,
            pakbus: new pakbusProtocol_1.PakBusProtocol(pakbusConfig),
            health: {
                stationId,
                isConnected: false,
                lastConnected: null,
                lastError: null,
                errorCount: 0,
                successfulTransactions: 0,
                failedTransactions: 0,
                averageLatency: 0,
            },
            retryTimer: null,
            keepAliveTimer: null,
        };
        this.connections.set(stationId, connection);
        this.setupPakBusEvents(stationId, connection);
        // Auto-connect if mode is pull
        if (config.mode === "pull") {
            await this.connect(stationId);
        }
    }
    /**
     * Connect to a station
     */
    async connect(stationId) {
        const connection = this.connections.get(stationId);
        if (!connection) {
            throw new Error(`Station ${stationId} not found`);
        }
        try {
            const transport = await this.createTransport(connection.config);
            connection.transport = transport;
            // Pipe transport to PakBus protocol
            this.pipeTransport(connection);
            // Send hello transaction
            const helloResult = await connection.pakbus.hello();
            if (helloResult.success) {
                connection.health.isConnected = true;
                connection.health.lastConnected = new Date();
                connection.health.lastError = null;
                this.emit("connected", stationId);
                // Start keep-alive if configured
                if (connection.config.keepAlive) {
                    this.startKeepAlive(stationId);
                }
                return true;
            }
            else {
                throw new Error(helloResult.error || "Hello transaction failed");
            }
        }
        catch (error) {
            connection.health.isConnected = false;
            connection.health.lastError = error.message;
            connection.health.errorCount++;
            this.emit("error", stationId, error);
            // Schedule retry
            this.scheduleRetry(stationId);
            return false;
        }
    }
    /**
     * Disconnect from a station
     */
    async disconnect(stationId) {
        const connection = this.connections.get(stationId);
        if (!connection)
            return;
        // Clear timers
        if (connection.retryTimer) {
            clearTimeout(connection.retryTimer);
            connection.retryTimer = null;
        }
        if (connection.keepAliveTimer) {
            clearInterval(connection.keepAliveTimer);
            connection.keepAliveTimer = null;
        }
        // Clean up pending PakBus transactions to prevent memory leaks
        if (connection.pakbus) {
            connection.pakbus.cleanup();
        }
        // Close transport (TCP socket)
        if (connection.transport) {
            connection.transport.destroy();
            connection.transport = null;
        }
        connection.health.isConnected = false;
        this.emit("disconnected", stationId);
    }
    /**
     * Remove a station connection
     */
    async removeConnection(stationId) {
        await this.disconnect(stationId);
        this.connections.delete(stationId);
    }
    /**
     * Get connection health for a station
     */
    getHealth(stationId) {
        return this.connections.get(stationId)?.health || null;
    }
    /**
     * Get all connection health statuses
     */
    getAllHealth() {
        return Array.from(this.connections.values()).map((c) => c.health);
    }
    /**
     * Discover stations on the network (TCP only in cloud deployment)
     */
    async discoverStations(config) {
        if (this.discoveryInProgress) {
            throw new Error("Discovery already in progress");
        }
        this.discoveryInProgress = true;
        const discovered = [];
        try {
            // For TCP discovery, scan common ports
            if (config.host) {
                const ports = [6785, 6786, 6787, 6788]; // Common PakBus ports
                for (const port of ports) {
                    try {
                        const result = await this.probeAddress(config.host, port);
                        if (result) {
                            discovered.push({ address: result, type: "tcp" });
                        }
                    }
                    catch {
                        // Continue scanning
                    }
                }
            }
            this.emit("discovery-complete", discovered);
            return discovered;
        }
        finally {
            this.discoveryInProgress = false;
        }
    }
    /**
     * List available connection endpoints
     * Note: Serial ports not available in cloud deployment
     */
    async listAvailableEndpoints() {
        return [
            { type: "tcp", description: "Direct TCP/IP connection to station" },
            { type: "gsm", description: "Cellular modem via TCP gateway" },
            { type: "lora", description: "LoRaWAN network server via TCP/IP" },
            { type: "http", description: "HTTP API endpoint" },
        ];
    }
    /**
     * Get PakBus protocol instance for a station
     */
    getPakBus(stationId) {
        return this.connections.get(stationId)?.pakbus || null;
    }
    /**
     * Create transport based on connection type
     * All transports use TCP/IP in cloud deployment
     */
    async createTransport(config) {
        switch (config.type) {
            case "tcp":
                return this.createTcpTransport(config);
            case "gsm":
                return this.createGsmGatewayTransport(config);
            case "lora":
                return this.createLoRaGatewayTransport(config);
            case "http":
                // HTTP connections don't use sockets directly
                // Return a dummy socket that will be replaced with HTTP fetch
                throw new Error("HTTP connections use direct API calls, not socket transport");
            default:
                throw new Error(`Unknown connection type: ${config.type}`);
        }
    }
    /**
     * Create TCP socket transport
     */
    createTcpTransport(config) {
        return new Promise((resolve, reject) => {
            if (!config.host) {
                reject(new Error("Host not specified"));
                return;
            }
            const socket = new net_1.Socket();
            const timeout = config.timeout || 10000;
            socket.setTimeout(timeout);
            socket.connect(config.port || 6785, config.host, () => {
                socket.setTimeout(0);
                resolve(socket);
            });
            socket.on("error", (err) => {
                reject(new Error(`TCP connection failed: ${err.message}`));
            });
            socket.on("timeout", () => {
                socket.destroy();
                reject(new Error("TCP connection timeout"));
            });
        });
    }
    /**
     * Create GSM/4G gateway transport (via TCP to modem gateway)
     * Connects to cellular modem's TCP endpoint instead of serial
     */
    async createGsmGatewayTransport(config) {
        const host = config.gatewayHost || config.host;
        const port = config.gatewayPort || config.port || 6785;
        if (!host) {
            throw new Error("GSM gateway host not specified");
        }
        console.log(`[GSM] Connecting to cellular gateway at ${host}:${port}`);
        return this.createTcpTransport({
            ...config,
            host,
            port,
            type: "tcp",
        });
    }
    /**
     * Create LoRa gateway transport (via TCP to LoRaWAN network server)
     */
    async createLoRaGatewayTransport(config) {
        const host = config.gatewayHost || config.host;
        const port = config.gatewayPort || config.port || 1700;
        if (!host) {
            throw new Error("LoRa network server host not specified");
        }
        console.log(`[LoRa] Connecting to LoRaWAN network server at ${host}:${port}`);
        return this.createTcpTransport({
            ...config,
            host,
            port,
            type: "tcp",
        });
    }
    /**
     * Pipe transport to PakBus protocol
     */
    pipeTransport(connection) {
        if (!connection.transport)
            return;
        connection.transport.on("data", (data) => {
            connection.pakbus.processIncoming(data);
        });
        connection.pakbus.on("send", (data) => {
            if (connection.transport) {
                connection.transport.write(data);
            }
        });
    }
    /**
     * Setup PakBus event handlers
     */
    setupPakBusEvents(stationId, connection) {
        connection.pakbus.on("data", (data) => {
            connection.health.successfulTransactions++;
            this.emit("data", stationId, data);
        });
        connection.pakbus.on("error", (error) => {
            connection.health.failedTransactions++;
            connection.health.lastError = error.message;
            this.emit("pakbus-error", stationId, error);
        });
        connection.pakbus.on("status", (status) => {
            if (status.batteryVoltage !== undefined) {
                connection.health.batteryVoltage = status.batteryVoltage;
            }
            this.emit("status", stationId, status);
        });
    }
    /**
     * Schedule connection retry
     */
    scheduleRetry(stationId) {
        const connection = this.connections.get(stationId);
        if (!connection)
            return;
        const { retryAttempts = 3, retryDelay = 5000 } = connection.config;
        if (connection.health.errorCount <= retryAttempts) {
            connection.retryTimer = setTimeout(() => {
                this.connect(stationId);
            }, retryDelay);
        }
        else {
            this.emit("max-retries", stationId);
        }
    }
    /**
     * Start keep-alive timer
     */
    startKeepAlive(stationId) {
        const connection = this.connections.get(stationId);
        if (!connection)
            return;
        const interval = connection.config.keepAliveInterval || 60000;
        connection.keepAliveTimer = setInterval(async () => {
            try {
                await connection.pakbus.hello();
            }
            catch (error) {
                // Clear the keep-alive timer first to prevent multiple reconnect attempts
                if (connection.keepAliveTimer) {
                    clearInterval(connection.keepAliveTimer);
                    connection.keepAliveTimer = null;
                }
                this.emit("error", { stationId, error: `Keep-alive failed: ${error}` });
                await this.disconnect(stationId);
                await this.connect(stationId);
            }
        }, interval);
    }
    /**
     * Probe TCP address for PakBus device
     */
    async probeAddress(host, port) {
        try {
            const socket = await this.createTcpTransport({ type: "tcp", host, port, pakbusAddress: 1, mode: "pull" });
            const pakbus = new pakbusProtocol_1.PakBusProtocol({ address: 1 });
            let foundAddress = null;
            socket.on("data", (data) => {
                pakbus.processIncoming(data);
            });
            pakbus.on("send", (data) => {
                socket.write(data);
            });
            const result = await pakbus.hello();
            if (result.success) {
                foundAddress = result.address || 1;
            }
            socket.destroy();
            return foundAddress;
        }
        catch {
            return null;
        }
    }
    /**
     * Delay helper
     */
    delay(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }
}
exports.ConnectionManager = ConnectionManager;
exports.connectionManager = new ConnectionManager();
