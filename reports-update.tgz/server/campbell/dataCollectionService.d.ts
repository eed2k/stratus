/**
 * Data Collection Service
 * Manages data collection from Campbell Scientific dataloggers
 */
import { EventEmitter } from 'events';
import { ConnectionConfig } from './connectionManager';
export type { ConnectionConfig };
export interface StationStatus {
    stationId: number;
    isConnected: boolean;
    lastConnectionTime?: Date;
    lastDataTime?: Date;
    batteryVoltage?: number;
    panelTemperature?: number;
    programName?: string;
    programSignature?: number;
    osVersion?: string;
}
export interface DataCollectionConfig {
    stationId: number;
    enabled: boolean;
    connectionConfig: {
        stationId?: number;
        connectionType?: string;
        protocol?: string;
        host?: string;
        port?: number;
        serialPort?: string;
        baudRate?: number;
        pakbusAddress?: number;
        securityCode?: number;
        dataTable?: string;
        pollInterval?: number;
        autoReconnect?: boolean;
        reconnectInterval?: number;
        maxReconnectAttempts?: number;
    };
}
export declare class DataCollectionService extends EventEmitter {
    private connectionManager;
    private activeStations;
    private dataBuffers;
    private flushTimers;
    private stationStatuses;
    private readonly BUFFER_SIZE;
    private readonly FLUSH_INTERVAL;
    constructor();
    /**
     * Setup listeners for connection manager events
     */
    private setupConnectionManagerListeners;
    /**
     * Update station status field
     */
    private updateStationStatusField;
    /**
     * Convert config to ConnectionConfig format expected by connectionManager
     */
    private toConnectionConfig;
    /**
     * Start data collection for a station
     */
    startStation(config: DataCollectionConfig): Promise<void>;
    /**
     * Stop data collection for a station
     */
    stopStation(stationId: number): Promise<void>;
    /**
     * Handle incoming data from datalogger
     */
    private handleIncomingData;
    /**
     * Transform Campbell Scientific data record to standard weather data format
     */
    private transformToWeatherData;
    /**
     * Calculate dew point from temperature and humidity
     */
    private calculateDewPoint;
    /**
     * Flush data buffer to database
     */
    private flushDataBuffer;
    /**
     * Get station status
     */
    getStationStatus(stationId: number): StationStatus | undefined;
    /**
     * Get all station statuses
     */
    getAllStationStatuses(): StationStatus[];
    /**
     * Manually collect data from a station
     */
    collectDataNow(stationId: number, tableName?: string): Promise<any[]>;
    /**
     * Get table definition from datalogger (stub)
     */
    getTableDefinition(stationId: number, tableName: string): Promise<any>;
    /**
     * Check if station is active
     */
    isStationActive(stationId: number): boolean;
    /**
     * Get active station IDs
     */
    getActiveStationIds(): number[];
    /**
     * Restart a station
     */
    restartStation(stationId: number): Promise<void>;
    /**
     * Stop all stations
     */
    stopAll(): Promise<void>;
    /**
     * Initialise service with stations from database
     */
    initialize(): Promise<void>;
}
export declare const dataCollectionService: DataCollectionService;
