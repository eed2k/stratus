/**
 * PakBus Protocol Implementation
 * Complete Campbell Scientific PakBus protocol support
 * Includes packet framing, CRC calculation, and all message types
 */
import { EventEmitter } from "events";
export interface PakBusConfig {
    address: number;
    securityCode?: number;
    neighborAddress?: number;
    timeout?: number;
}
export interface TableDefinition {
    tableNumber: number;
    tableName: string;
    columns: Array<{
        name: string;
        type: string;
        units: string;
        processing: string;
    }>;
    recordInterval: number;
}
export interface CollectedRecord {
    timestamp: Date;
    recordNumber: number;
    values: Record<string, number | string>;
}
export interface TransactionResult {
    success: boolean;
    error?: string;
    data?: any;
    address?: number;
}
export declare const MESSAGE_TYPES: {
    HELLO: number;
    HELLO_ACK: number;
    BYE: number;
    GET_SETTINGS: number;
    SET_SETTINGS: number;
    GET_TABLE_DEFS: number;
    COLLECT_DATA: number;
    FILE_SEND: number;
    FILE_RECEIVE: number;
    FILE_CONTROL: number;
    CLOCK_SET: number;
    CLOCK_GET: number;
    PROGRAM_CONTROL: number;
    PLEASE_WAIT: number;
    FAILURE: number;
};
export declare class PakBusProtocol extends EventEmitter {
    private config;
    private transactionNumber;
    private receiveBuffer;
    private pendingTransactions;
    constructor(config: PakBusConfig);
    /**
     * Clean up all pending transactions (call on disconnect)
     * Prevents memory leaks from orphaned transactions
     */
    cleanup(): void;
    /**
     * Process incoming data from transport
     */
    processIncoming(data: Buffer): void;
    /**
     * Send hello transaction
     */
    hello(): Promise<TransactionResult>;
    /**
     * Get table definitions from datalogger
     */
    getTableDefinitions(): Promise<TransactionResult>;
    /**
     * Collect data from a specific table
     */
    collectData(tableName: string, startRecord?: number, numRecords?: number): Promise<TransactionResult>;
    /**
     * Get station settings
     */
    getSettings(): Promise<TransactionResult>;
    /**
     * Set station clock
     */
    setClock(time?: Date): Promise<TransactionResult>;
    /**
     * Get station clock
     */
    getClock(): Promise<TransactionResult>;
    /**
     * Upload file to datalogger
     */
    uploadFile(fileName: string, content: Buffer): Promise<TransactionResult>;
    /**
     * Download file from datalogger
     */
    downloadFile(fileName: string): Promise<TransactionResult>;
    /**
     * List files on datalogger
     */
    listFiles(directory?: string): Promise<TransactionResult>;
    /**
     * Delete file on datalogger
     */
    deleteFile(fileName: string): Promise<TransactionResult>;
    /**
     * Run/stop program
     */
    programControl(action: "run" | "stop" | "compile"): Promise<TransactionResult>;
    /**
     * Build PakBus packet
     */
    private buildPacket;
    /**
     * Frame packet with sync bytes and quote escaping
     */
    private framePacket;
    /**
     * Unframe packet - remove sync bytes and unescape
     */
    private unframePacket;
    /**
     * Calculate Signature16 (CRC-CCITT)
     */
    private calculateSignature;
    /**
     * Calculate signature nullifier
     */
    private calculateSignatureNullifier;
    /**
     * Get next transaction number
     */
    private getNextTransactionNumber;
    /**
     * Process receive buffer for complete packets
     */
    private processBuffer;
    /**
     * Process a complete PakBus packet
     */
    private processPacket;
    /**
     * Handle response message
     */
    private handleResponse;
    /**
     * Parse error code from failure message
     */
    private parseErrorCode;
    /**
     * Parse payload based on message type
     */
    private parsePayload;
    /**
     * Parse hello acknowledgment
     */
    private parseHelloAck;
    /**
     * Parse table definitions
     */
    private parseTableDefs;
    /**
     * Parse settings
     */
    private parseSettings;
    /**
     * Parse clock
     */
    private parseClock;
    /**
     * Parse collected data records
     */
    private parseCollectedData;
    /**
     * Parse file content
     */
    private parseFileContent;
    /**
     * Get data type name from code
     */
    private getDataTypeName;
    /**
     * Get processing name from code
     */
    private getProcessingName;
    /**
     * Internal method to send pre-built packet and wait for response
     */
    private sendPacket;
    /**
     * Send transaction and wait for response
     * Public method for external modules (like FileManager) to send PakBus transactions
     */
    sendTransaction(destAddress: number, msgType: number, payload: Buffer): Promise<TransactionResult>;
    private buildHelloMessage;
    private buildGetTableDefsMessage;
    private buildCollectDataMessage;
    private buildGetSettingsMessage;
    private buildSetClockMessage;
    private buildGetClockMessage;
    private buildFileSendMessage;
    private buildFileReceiveMessage;
    private buildFileControlMessage;
    private buildProgramControlMessage;
}
