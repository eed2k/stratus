import type { Express } from "express";
export declare function registerCampbellRoutes(app: Express): void;
