/**
 * Connection Manager
 * Handles multiple connection types for Campbell Scientific stations
 * Supports Pull (active polling) and Push (passive receive) modes
 *
 * CLOUD DEPLOYMENT NOTE:
 * This version is designed for cloud deployment where direct serial
 * connections are not available. All connections use TCP/IP:
 * - TCP: Direct socket connection to station's TCP interface
 * - GSM/4G: Connect to cellular modem's TCP gateway endpoint
 * - LoRa: Connect to LoRaWAN network server via TCP/IP
 */
import { EventEmitter } from "events";
import { PakBusProtocol } from "./pakbusProtocol";
export type ConnectionType = "tcp" | "gsm" | "lora" | "http";
export type ConnectionMode = "pull" | "push";
export interface ConnectionConfig {
    type: ConnectionType;
    mode: ConnectionMode;
    host?: string;
    port?: number;
    pakbusAddress: number;
    securityCode?: number;
    neighborAddress?: number;
    modemType?: "gsm" | "lora";
    gatewayHost?: string;
    gatewayPort?: number;
    apn?: string;
    apiEndpoint?: string;
    apiKey?: string;
    timeout?: number;
    retryAttempts?: number;
    retryDelay?: number;
    keepAlive?: boolean;
    keepAliveInterval?: number;
}
export interface ConnectionHealth {
    stationId: number;
    isConnected: boolean;
    lastConnected: Date | null;
    lastError: string | null;
    errorCount: number;
    successfulTransactions: number;
    failedTransactions: number;
    averageLatency: number;
    signalStrength?: number;
    batteryVoltage?: number;
}
export declare class ConnectionManager extends EventEmitter {
    private connections;
    private discoveryInProgress;
    constructor();
    /**
     * Add a new station connection
     */
    addConnection(stationId: number, config: ConnectionConfig): Promise<void>;
    /**
     * Connect to a station
     */
    connect(stationId: number): Promise<boolean>;
    /**
     * Disconnect from a station
     */
    disconnect(stationId: number): Promise<void>;
    /**
     * Remove a station connection
     */
    removeConnection(stationId: number): Promise<void>;
    /**
     * Get connection health for a station
     */
    getHealth(stationId: number): ConnectionHealth | null;
    /**
     * Get all connection health statuses
     */
    getAllHealth(): ConnectionHealth[];
    /**
     * Discover stations on the network (TCP only in cloud deployment)
     */
    discoverStations(config: Partial<ConnectionConfig>): Promise<Array<{
        address: number;
        type: string;
    }>>;
    /**
     * List available connection endpoints
     * Note: Serial ports not available in cloud deployment
     */
    listAvailableEndpoints(): Promise<Array<{
        type: string;
        description: string;
    }>>;
    /**
     * Get PakBus protocol instance for a station
     */
    getPakBus(stationId: number): PakBusProtocol | null;
    /**
     * Create transport based on connection type
     * All transports use TCP/IP in cloud deployment
     */
    private createTransport;
    /**
     * Create TCP socket transport
     */
    private createTcpTransport;
    /**
     * Create GSM/4G gateway transport (via TCP to modem gateway)
     * Connects to cellular modem's TCP endpoint instead of serial
     */
    private createGsmGatewayTransport;
    /**
     * Create LoRa gateway transport (via TCP to LoRaWAN network server)
     */
    private createLoRaGatewayTransport;
    /**
     * Pipe transport to PakBus protocol
     */
    private pipeTransport;
    /**
     * Setup PakBus event handlers
     */
    private setupPakBusEvents;
    /**
     * Schedule connection retry
     */
    private scheduleRetry;
    /**
     * Start keep-alive timer
     */
    private startKeepAlive;
    /**
     * Probe TCP address for PakBus device
     */
    private probeAddress;
    /**
     * Delay helper
     */
    private delay;
}
export declare const connectionManager: ConnectionManager;
