import { EventEmitter } from 'events';
/**
 * PakBus Protocol Implementation for Campbell Scientific Dataloggers
 * Supports PakBus protocol versions 3.x and 4.x
 */
export interface PakBusConfig {
    address: number;
    securityCode?: number;
    maxPacketSize?: number;
    timeout?: number;
}
export interface PakBusMessage {
    signature: number;
    sourceAddress: number;
    destAddress: number;
    expectMore: number;
    priority: number;
    messageType: number;
    transactionNumber: number;
    payload: Buffer;
}
export interface DataTableDefinition {
    tableName: string;
    fieldNames: string[];
    fieldTypes: string[];
    fieldUnits: string[];
    fieldProcessing: string[];
}
export declare class PakBusProtocol extends EventEmitter {
    private config;
    private transactionNumber;
    private pendingTransactions;
    constructor(config: PakBusConfig);
    /**
     * Create a PakBus frame with proper framing and CRC
     */
    createFrame(message: Partial<PakBusMessage>): Buffer;
    /**
     * Parse a received PakBus frame
     */
    parseFrame(data: Buffer): PakBusMessage | null;
    /**
     * Calculate signature nullifier for PakBus protocol
     */
    private calculateNullifier;
    /**
     * Get next transaction number (0-255)
     */
    private getNextTransactionNumber;
    /**
     * Send Hello command to establish communication
     */
    createHelloCommand(): Buffer;
    /**
     * Create GetProgStat command (get program statistics)
     */
    createGetProgStatCommand(securityCode?: number): Buffer;
    /**
     * Create Clock command to read/set datalogger time
     */
    createClockCommand(setTime?: Date): Buffer;
    /**
     * Create TableDef command to get table definitions
     */
    createTableDefCommand(tableName?: string): Buffer;
    /**
     * Create CollectData command to retrieve data records
     */
    createCollectDataCommand(tableName: string, mode?: number, p1?: number, p2?: number): Buffer;
    /**
     * Parse GetProgStat response
     */
    parseProgStatResponse(payload: Buffer): any;
    /**
     * Parse table definition response
     */
    parseTableDefResponse(payload: Buffer): DataTableDefinition | null;
    /**
     * Parse collected data records
     */
    parseCollectDataResponse(payload: Buffer, tableDef: DataTableDefinition): any[];
}
