"use strict";
// Stratus Weather Server
// Created by Lukas Esterhuizen
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.log = log;
require("dotenv/config");
const express_1 = __importDefault(require("express"));
const compression_1 = __importDefault(require("compression"));
const helmet_1 = __importDefault(require("helmet"));
const routes_1 = require("./routes");
const static_1 = require("./static");
const http_1 = require("http");
const db_1 = require("./db");
const postgres = __importStar(require("./db-postgres"));
const auditLogService_1 = require("./services/auditLogService");
const stalenessMonitorService_1 = require("./services/stalenessMonitorService");
const weeklyDigestService_1 = require("./services/weeklyDigestService");
const reportSchedulerService_1 = require("./services/reportSchedulerService");
// Check if PostgreSQL mode is enabled
const usePostgres = postgres.isPostgresEnabled();
// Environment validation
const validateEnvironment = () => {
    const port = parseInt(process.env.PORT || "5000", 10);
    if (isNaN(port) || port < 0 || port > 65535) {
        console.error("Invalid PORT environment variable. Must be a number between 0 and 65535.");
        process.exit(1);
    }
    // Validate VITE_DEMO_MODE if set
    if (process.env.VITE_DEMO_MODE && !['true', 'false'].includes(process.env.VITE_DEMO_MODE)) {
        console.warn("VITE_DEMO_MODE should be 'true' or 'false'. Defaulting to false.");
    }
    return { port };
};
const { port: validatedPort } = validateEnvironment();
const app = (0, express_1.default)();
const httpServer = (0, http_1.createServer)(app);
// Trust proxy when behind reverse proxy (nginx)
// This is required for rate limiting to work correctly with X-Forwarded-For headers
app.set('trust proxy', 1);
// Security headers with Helmet.js
// Note: upgrade-insecure-requests disabled for HTTP-only deployments
app.use((0, helmet_1.default)({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            scriptSrc: [
                "'self'",
                "'unsafe-inline'",
                "https://unpkg.com", // Leaflet JS CDN
                "https://cdnjs.cloudflare.com", // Leaflet JS fallback CDN
                "https://cdn.jsdelivr.net", // Leaflet JS fallback CDN
            ],
            styleSrc: [
                "'self'",
                "'unsafe-inline'",
                "https://unpkg.com", // Leaflet CSS CDN
                "https://cdnjs.cloudflare.com", // Leaflet CSS fallback CDN
                "https://cdn.jsdelivr.net", // Leaflet CSS fallback CDN
            ],
            imgSrc: [
                "'self'",
                "data:",
                "blob:",
                "https:",
                "https://*.tile.openstreetmap.org", // OpenStreetMap tiles
            ],
            connectSrc: [
                "'self'",
                "ws:",
                "wss:",
                "https://nominatim.openstreetmap.org", // OSM Nominatim geocoding API
                "https://unpkg.com", // Leaflet CDN
                "https://cdnjs.cloudflare.com", // Leaflet fallback CDN
                "https://cdn.jsdelivr.net", // Leaflet fallback CDN
            ],
            fontSrc: ["'self'", "data:"],
            objectSrc: ["'none'"],
            mediaSrc: ["'self'"],
            frameSrc: ["'none'"],
            upgradeInsecureRequests: null, // Disable for HTTP-only servers
        },
    },
    crossOriginEmbedderPolicy: false, // Allow embedding resources
    crossOriginResourcePolicy: { policy: "cross-origin" },
    crossOriginOpenerPolicy: false, // Disable for HTTP
    originAgentCluster: false, // Disable for HTTP
}));
app.use(express_1.default.json({
    limit: '5mb',
    verify: (req, _res, buf) => {
        req.rawBody = buf;
    },
}));
app.use(express_1.default.urlencoded({ extended: false }));
// Enable gzip/brotli compression for all responses
// This dramatically reduces JSON payload sizes (e.g. 2MB → ~200KB for weather data)
app.use((0, compression_1.default)({ level: 6 }));
function log(message, source = "express") {
    const formattedTime = new Date().toLocaleTimeString("en-US", {
        hour: "numeric",
        minute: "2-digit",
        second: "2-digit",
        hour12: true,
    });
    console.log(`${formattedTime} [${source}] ${message}`);
}
app.use((req, res, next) => {
    const start = Date.now();
    const path = req.path;
    let capturedJsonResponse = undefined;
    const originalResJson = res.json;
    res.json = function (bodyJson, ...args) {
        capturedJsonResponse = bodyJson;
        return originalResJson.apply(res, [bodyJson, ...args]);
    };
    res.on("finish", () => {
        const duration = Date.now() - start;
        if (path.startsWith("/api")) {
            let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
            if (capturedJsonResponse) {
                // Redact sensitive fields from log output
                const safe = { ...capturedJsonResponse };
                const sensitiveKeys = ['password', 'passwordHash', 'apiKey', 'token', 'refreshToken', 'appSecret', 'secret'];
                const redact = (obj) => {
                    if (!obj || typeof obj !== 'object')
                        return;
                    for (const key of Object.keys(obj)) {
                        if (sensitiveKeys.some(sk => key.toLowerCase().includes(sk.toLowerCase()))) {
                            obj[key] = '[REDACTED]';
                        }
                        else if (typeof obj[key] === 'object') {
                            redact(obj[key]);
                        }
                    }
                };
                redact(safe);
                logLine += ` :: ${JSON.stringify(safe)}`;
            }
            log(logLine);
        }
    });
    next();
});
(async () => {
    // Initialise database first
    try {
        if (usePostgres) {
            await postgres.initPostgresDatabase();
            log("PostgreSQL database initialized successfully");
        }
        else {
            await (0, db_1.initDatabase)();
            log("SQLite database initialized successfully");
        }
    }
    catch (error) {
        console.error("Failed to initialize database:", error);
        process.exit(1);
    }
    // Create default admin user if no users exist (works for both SQLite and PostgreSQL)
    try {
        const bcrypt = await Promise.resolve().then(() => __importStar(require('bcryptjs')));
        const hashFn = bcrypt.hash || bcrypt.default?.hash;
        if (!hashFn) {
            throw new Error("bcrypt.hash function not found");
        }
        const adminEmail = process.env.STRATUS_ADMIN_EMAIL || process.env.ADMIN_EMAIL;
        const adminPassword = process.env.STRATUS_ADMIN_PASSWORD || process.env.ADMIN_PASSWORD;
        const adminName = process.env.STRATUS_ADMIN_NAME || "Admin";
        if (adminEmail && adminPassword) {
            if (usePostgres) {
                // PostgreSQL mode - use postgres module functions
                const existingAdmin = await postgres.getUserByEmail(adminEmail);
                if (!existingAdmin) {
                    const passwordHash = await hashFn(adminPassword, 10);
                    const nameParts = adminName.split(' ');
                    const firstName = nameParts[0] || "Admin";
                    const lastName = nameParts.slice(1).join(' ') || null;
                    await postgres.createUser({
                        email: adminEmail,
                        firstName,
                        lastName,
                        passwordHash,
                        role: 'admin',
                        assignedStations: null,
                        isActive: true
                    });
                    log(`Default admin user created: ${adminEmail}`);
                }
                else {
                    log(`Admin user already exists: ${adminEmail}`);
                }
            }
            else {
                // SQLite mode
                const { getUserByEmail, createUser, getAllActiveUsers } = await Promise.resolve().then(() => __importStar(require('./db')));
                const users = getAllActiveUsers();
                if (users.length === 0) {
                    const passwordHash = await hashFn(adminPassword, 10);
                    const nameParts = adminName.split(' ');
                    const firstName = nameParts[0] || "Admin";
                    const lastName = nameParts.slice(1).join(' ') || null;
                    createUser(adminEmail, firstName, lastName, passwordHash, "admin", []);
                    log(`Default admin user created: ${adminEmail}`);
                }
            }
        }
        else {
            log("Warning: No admin credentials configured. Set STRATUS_ADMIN_EMAIL and STRATUS_ADMIN_PASSWORD environment variables.");
        }
    }
    catch (err) {
        console.error("Failed to create default admin user:", err);
    }
    await (0, routes_1.registerRoutes)(httpServer, app);
    app.use((err, _req, res, _next) => {
        const status = err.status || err.statusCode || 500;
        const message = err.message || "Internal Server Error";
        res.status(status).json({ message });
        console.error('[ErrorHandler]', err);
    });
    // importantly only setup vite in development and after
    // setting up all the other routes so the catch-all route
    // doesn't interfere with the other routes
    if (process.env.NODE_ENV === "production") {
        (0, static_1.serveStatic)(app);
    }
    else {
        const { setupVite } = await Promise.resolve().then(() => __importStar(require("./vite")));
        await setupVite(httpServer, app);
    }
    // ALWAYS serve the app on the port specified in the environment variable PORT
    // Other ports are firewalled. Default to 5000 if not specified.
    // this serves both the API and the client.
    // It is the only port that is not firewalled.
    const port = validatedPort;
    httpServer.on('error', (err) => {
        console.error('Server error:', err);
    });
    httpServer.listen(port, "0.0.0.0", () => {
        log(`serving on port ${port}`);
        // Log system startup
        auditLogService_1.auditLog.log(auditLogService_1.AUDIT_ACTIONS.SYSTEM_STARTUP, 'system', {
            details: { port, nodeEnv: process.env.NODE_ENV || 'development' },
            status: 'success'
        });
        // Start staleness monitor after server is ready
        (0, stalenessMonitorService_1.initStalenessMonitor)().catch(err => {
            console.error('[StalenessMonitor] Failed to initialize:', err);
        });
        // Start Mon/Fri weekly digest emails (requires DIGEST_ENABLED=true)
        (0, weeklyDigestService_1.initWeeklyDigest)().catch(err => {
            console.error('[WeeklyDigest] Failed to initialize:', err);
        });
        // Start /reports portal scheduler (registers cron tasks for each saved schedule)
        (0, reportSchedulerService_1.initReportScheduler)().catch(err => {
            console.error('[Reports] Failed to initialize scheduler:', err);
        });
    });
    // Keep process alive
    process.on('uncaughtException', (err) => {
        console.error('Uncaught exception:', err);
    });
    process.on('unhandledRejection', (reason, promise) => {
        console.error('Unhandled rejection at:', promise, 'reason:', reason);
    });
    // Graceful shutdown handler
    const gracefulShutdown = async (signal) => {
        console.log(`[Shutdown] ${signal} received, shutting down gracefully...`);
        (0, stalenessMonitorService_1.stopStalenessMonitor)();
        await auditLogService_1.auditLog.log(auditLogService_1.AUDIT_ACTIONS.SYSTEM_SHUTDOWN, 'system', {
            details: { reason: `${signal} received` },
            status: 'success'
        });
        // Close HTTP server (stop accepting new connections, drain in-flight)
        httpServer.close(() => {
            console.log('[Shutdown] HTTP server closed');
            // Close database connections
            if (usePostgres) {
                postgres.closePostgresDatabase().then(() => {
                    console.log('[Shutdown] PostgreSQL connections closed');
                    process.exit(0);
                }).catch(() => process.exit(0));
            }
            else {
                process.exit(0);
            }
        });
        // Force exit after 10s if graceful shutdown stalls
        setTimeout(() => {
            console.error('[Shutdown] Forced exit after timeout');
            process.exit(1);
        }, 10000);
    };
    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));
})();
