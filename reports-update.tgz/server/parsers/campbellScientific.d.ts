/**
 * Campbell Scientific Data File Parser
 * Supports TOA5 (ASCII Table) and TOB1 (Binary) formats
 */
export interface ParsedRecord {
    timestamp: Date;
    recordNumber: number;
    data: Record<string, number | string | null>;
}
export interface ParsedFile {
    format: "TOA5" | "TOB1" | "UNKNOWN";
    stationName: string;
    loggerModel: string;
    loggerSerial: string;
    loggerOS: string;
    programName: string;
    programSignature: string;
    tableName: string;
    headers: string[];
    units: string[];
    processingTypes: string[];
    records: ParsedRecord[];
    errors: string[];
}
/**
 * Parse TOA5 format files (ASCII table-based)
 * TOA5 files have 4 header lines:
 * 1. File format info (format, station, logger, table, etc.)
 * 2. Column names
 * 3. Units
 * 4. Processing types (Smp, Avg, Min, Max, etc.)
 */
export declare function parseTOA5(content: string): ParsedFile;
/**
 * Parse TOB1 binary format (simplified - header only)
 * TOB1 is a binary format with ASCII header
 */
export declare function parseTOB1Header(content: Buffer): Partial<ParsedFile>;
/**
 * Auto-detect file format and parse accordingly
 */
export declare function parseDataFile(content: string | Buffer): ParsedFile;
/**
 * Map Campbell Scientific field names to standard weather data fields
 * Includes comprehensive null safety checks for all field lookups
 */
export declare function mapToWeatherData(record: ParsedRecord, units?: string[], headers?: string[]): Record<string, number | null>;
/**
 * Detect wind speed unit from DAT file headers/units rows.
 * Returns 'kmh' if any wind speed column has km/h unit, otherwise 'ms'.
 */
export declare function detectWindSpeedUnit(headers?: string[], units?: string[]): 'ms' | 'kmh';
