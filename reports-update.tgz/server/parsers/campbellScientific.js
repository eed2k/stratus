"use strict";
// Stratus Weather Server
// Created by Lukas Esterhuizen
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseTOA5 = parseTOA5;
exports.parseTOB1Header = parseTOB1Header;
exports.parseDataFile = parseDataFile;
exports.mapToWeatherData = mapToWeatherData;
exports.detectWindSpeedUnit = detectWindSpeedUnit;
/**
 * Parse TOA5 format files (ASCII table-based)
 * TOA5 files have 4 header lines:
 * 1. File format info (format, station, logger, table, etc.)
 * 2. Column names
 * 3. Units
 * 4. Processing types (Smp, Avg, Min, Max, etc.)
 */
function parseTOA5(content) {
    const lines = content.split(/\r?\n/).filter(line => line.trim());
    const errors = [];
    if (lines.length < 4) {
        return {
            format: "TOA5",
            stationName: "",
            loggerModel: "",
            loggerSerial: "",
            loggerOS: "",
            programName: "",
            programSignature: "",
            tableName: "",
            headers: [],
            units: [],
            processingTypes: [],
            records: [],
            errors: ["File has fewer than 4 lines - invalid TOA5 format"],
        };
    }
    // Parse header line 1: file info
    const infoLine = parseCSVLine(lines[0]);
    const [format, stationName, loggerModel, loggerSerial, loggerOS, programName, programSignature, tableName] = infoLine;
    // Parse header line 2: column names
    const headers = parseCSVLine(lines[1]);
    // Parse header line 3: units
    const units = parseCSVLine(lines[2]);
    // Parse header line 4: processing types
    const processingTypes = parseCSVLine(lines[3]);
    // Parse data records
    const records = [];
    for (let i = 4; i < lines.length; i++) {
        try {
            const values = parseCSVLine(lines[i]);
            if (values.length === 0)
                continue;
            const rawTimestamp = values[0].replace(/"/g, "").trim();
            // Campbell Scientific TOA5 timestamps are in station local time (SAST = UTC+2)
            // without timezone markers. Append +02:00 so JS Date parses them correctly.
            const hasTimezone = /[Z+-]\d{2}:?\d{2}$/.test(rawTimestamp) || rawTimestamp.endsWith('Z');
            const timestampStr = hasTimezone ? rawTimestamp : rawTimestamp.replace(' ', 'T') + '+02:00';
            const timestamp = new Date(timestampStr);
            const recordNumber = parseInt(values[1]) || i - 3;
            const data = {};
            for (let j = 2; j < headers.length && j < values.length; j++) {
                const header = headers[j].replace(/"/g, "");
                const value = values[j].replace(/"/g, "");
                if (value === "NAN" || value === "" || value === "NaN") {
                    data[header] = null;
                }
                else {
                    const numValue = parseFloat(value);
                    data[header] = isNaN(numValue) ? value : numValue;
                }
            }
            records.push({ timestamp, recordNumber, data });
        }
        catch (err) {
            errors.push(`Error parsing line ${i + 1}: ${err}`);
        }
    }
    return {
        format: "TOA5",
        stationName: stationName?.replace(/"/g, "") || "",
        loggerModel: loggerModel?.replace(/"/g, "") || "",
        loggerSerial: loggerSerial?.replace(/"/g, "") || "",
        loggerOS: loggerOS?.replace(/"/g, "") || "",
        programName: programName?.replace(/"/g, "") || "",
        programSignature: programSignature?.replace(/"/g, "") || "",
        tableName: tableName?.replace(/"/g, "") || "",
        headers: headers.map(h => h.replace(/"/g, "")),
        units: units.map(u => u.replace(/"/g, "")),
        processingTypes: processingTypes.map(p => p.replace(/"/g, "")),
        records,
        errors,
    };
}
/**
 * Parse CSV line handling quoted values with commas
 * Preserves empty trailing fields for proper column alignment
 */
function parseCSVLine(line) {
    const result = [];
    let current = "";
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
        const char = line[i];
        if (char === '"') {
            inQuotes = !inQuotes;
            current += char;
        }
        else if (char === "," && !inQuotes) {
            result.push(current.trim());
            current = "";
        }
        else {
            current += char;
        }
    }
    // Always push the last field, even if empty (preserves trailing empty fields)
    result.push(current.trim());
    return result;
}
/**
 * Parse TOB1 binary format (simplified - header only)
 * TOB1 is a binary format with ASCII header
 */
function parseTOB1Header(content) {
    // TOB1 has ASCII header followed by binary data
    // Find the header section (ends with binary data start marker)
    const headerEnd = content.indexOf(0x00); // Null byte often marks header end
    const headerStr = content.slice(0, headerEnd > 0 ? headerEnd : 512).toString("ascii");
    const lines = headerStr.split(/\r?\n/).filter(line => line.trim());
    if (lines.length < 2) {
        return {
            format: "TOB1",
            errors: ["Could not parse TOB1 header"],
        };
    }
    const infoLine = parseCSVLine(lines[0]);
    const headers = lines.length > 1 ? parseCSVLine(lines[1]) : [];
    return {
        format: "TOB1",
        stationName: infoLine[1]?.replace(/"/g, "") || "",
        loggerModel: infoLine[2]?.replace(/"/g, "") || "",
        tableName: infoLine[7]?.replace(/"/g, "") || "",
        headers: headers.map(h => h.replace(/"/g, "")),
        errors: ["TOB1 binary data parsing not fully implemented - header only"],
    };
}
/**
 * Auto-detect file format and parse accordingly
 */
function parseDataFile(content) {
    // Check if it's a Buffer (binary) or string
    const textContent = Buffer.isBuffer(content)
        ? content.toString("utf-8", 0, 1000)
        : content.substring(0, 1000);
    // Detect format from first line
    if (textContent.startsWith('"TOA5"') || textContent.startsWith("TOA5")) {
        return parseTOA5(Buffer.isBuffer(content) ? content.toString("utf-8") : content);
    }
    if (textContent.startsWith('"TOB1"') || textContent.startsWith("TOB1")) {
        const header = parseTOB1Header(Buffer.isBuffer(content) ? content : Buffer.from(content));
        return {
            format: "TOB1",
            stationName: header.stationName || "",
            loggerModel: header.loggerModel || "",
            loggerSerial: "",
            loggerOS: "",
            programName: "",
            programSignature: "",
            tableName: header.tableName || "",
            headers: header.headers || [],
            units: [],
            processingTypes: [],
            records: [],
            errors: header.errors || [],
        };
    }
    // Try generic CSV parsing for array-based files
    if (textContent.includes(",")) {
        try {
            return parseGenericCSV(Buffer.isBuffer(content) ? content.toString("utf-8") : content);
        }
        catch {
            // Fall through to unknown
        }
    }
    return {
        format: "UNKNOWN",
        stationName: "",
        loggerModel: "",
        loggerSerial: "",
        loggerOS: "",
        programName: "",
        programSignature: "",
        tableName: "",
        headers: [],
        units: [],
        processingTypes: [],
        records: [],
        errors: ["Unknown file format - could not detect TOA5 or TOB1"],
    };
}
/**
 * Parse generic CSV weather data files
 */
function parseGenericCSV(content) {
    const lines = content.split(/\r?\n/).filter(line => line.trim());
    if (lines.length < 2) {
        throw new Error("File has fewer than 2 lines");
    }
    const headers = parseCSVLine(lines[0]);
    const records = [];
    for (let i = 1; i < lines.length; i++) {
        const values = parseCSVLine(lines[i]);
        if (values.length === 0)
            continue;
        // Try to find timestamp column
        let timestamp = new Date();
        let recordNumber = i;
        const data = {};
        for (let j = 0; j < headers.length && j < values.length; j++) {
            const header = headers[j].replace(/"/g, "").trim();
            const value = values[j].replace(/"/g, "").trim();
            // Check for timestamp columns
            if (header.toLowerCase().includes("time") || header.toLowerCase().includes("date")) {
                // Assume station local time (SAST = UTC+2) if no timezone marker
                const hasTimezone = /[Z+-]\d{2}:?\d{2}$/.test(value) || value.endsWith('Z');
                const tsStr = hasTimezone ? value : value.replace(' ', 'T') + '+02:00';
                const parsed = new Date(tsStr);
                if (!isNaN(parsed.getTime())) {
                    timestamp = parsed;
                    continue;
                }
            }
            // Check for record number
            if (header.toLowerCase().includes("record") || header.toLowerCase() === "rn") {
                recordNumber = parseInt(value) || i;
                continue;
            }
            if (value === "NAN" || value === "" || value === "NaN") {
                data[header] = null;
            }
            else {
                const numValue = parseFloat(value);
                data[header] = isNaN(numValue) ? value : numValue;
            }
        }
        records.push({ timestamp, recordNumber, data });
    }
    return {
        format: "UNKNOWN",
        stationName: "Imported Data",
        loggerModel: "",
        loggerSerial: "",
        loggerOS: "",
        programName: "",
        programSignature: "",
        tableName: "Data",
        headers: headers.map(h => h.replace(/"/g, "")),
        units: [],
        processingTypes: [],
        records,
        errors: [],
    };
}
/**
 * Map Campbell Scientific field names to standard weather data fields
 * Includes comprehensive null safety checks for all field lookups
 */
function mapToWeatherData(record, units, headers) {
    // Early return if record or data is null/undefined
    if (!record || !record.data) {
        return {};
    }
    const fieldMappings = {
        temperature: ["AirTC", "AirTC_Avg", "Temp_C", "Temperature", "T_Avg", "Air_Temp", "Temp_Avg", "AirTemp_Avg", "AirTemp", "Temp", "Amb_Temp_Avg", "TEMP__2m_Avg", "TEMP_2m_Avg"],
        humidity: ["RH", "RH_Avg", "Humidity", "RelHumidity", "RH_pct", "RelHumidity_Avg"],
        pressure: ["BP_mbar", "BP_Avg", "Pressure", "BaroPres", "Baro_mbar", "Pressure_Avg", "BaroPressure_Avg", "BP_mbar_Avg", "BPress_Avg", "BPress", "Bar_Pressure_Avg"],
        windSpeed: ["WS_ms", "WS_Avg", "WindSpd", "Wind_Speed", "WS_kph", "Wind_Spd_S_WVT", "WindSpeed_Avg", "WS_ms_Avg", "WS_ms_S_WVT", "WSpd_1_Avg", "WSpd_Avg", "WSpd_1_S_WVT", "WSpd_2_Avg", "W_S_m_s_WVc(1)"],
        windDirection: ["WD_Deg", "WD_Avg", "WindDir", "Wind_Dir", "Wind_Dir_D1_WVT", "WindDir_D1_WVT", "WindDir_Avg", "WD_Deg_Avg", "WDir_1_Avg", "WDir_Avg", "WDir_1_D1_WVT", "WDir_2_Avg", "W_S_m_s_WVc(2)"],
        windGust: ["WS_Max", "WindGust", "Gust_ms", "Wind_Spd_Max", "WindSpeed_Max", "WS_ms_Max", "Wind_Gust", "WSpd_1_Max", "WSpd_Max", "W_S_m_s_WVc(3)"],
        windSpeedMin: ["WSpd_1_Min", "WSpd_Min", "WS_ms_Min", "WindSpeed_Min", "WSpd_2_Min"],
        solarRadiation: ["SlrW", "SR_Avg", "Solar_W", "Radiation", "SlrkW", "Solar_Rad_Avg", "SolarRad_Avg", "SlrW_Avg", "Solar_Rad", "SR_W", "Sol_Rad_Avg"],
        solarMJTotal: ["SlrMJ_Tot", "SlrMJ", "Solar_MJ_Tot", "SolarMJ_Tot"],
        rainfall: ["Rain_mm", "Rain_Tot", "Precip", "Rain_mm_Tot", "Rain_Tot_Tot", "Rainfall", "Precip_Tot", "Rain_1_Tot", "Rain_Tot_1", "Rain_2_Tot"],
        dewPoint: ["DewPt", "DewPoint", "Dew_C", "DewPoint_Avg", "DewPt_Avg", "DewPointTemp_Avg", "DewPointTemp"],
        soilTemperature: ["SoilTC", "Soil_Temp", "T_Soil", "SoilTemp_Avg", "SoilTC_Avg"],
        soilMoisture: ["VWC", "Soil_VWC", "VWC_Avg", "SoilMoist_Avg", "Soil_Moisture"],
        batteryVoltage: ["BattV", "Batt_V", "Battery", "BattV_Avg", "BattV_Min", "Batt_volt_Min", "LoggerBattery_Avg", "LoggerBattery", "Batt_Volt_Avg", "BAT_VOLTS_Avg"],
        lithiumBattery: ["LoggerLithiumBatt_Avg", "LoggerLithiumBatt", "LithiumBatt_Avg", "LithiumBatt"],
        panelTemperature: ["PTemp", "PTemp_C", "Panel_Temp", "PTemp_Avg", "PTemp_C_Avg", "LoggerTemp_Avg", "LoggerTemp"],
        pm25: ["PM2_5_Avg", "PM2_5", "PM25", "PM25_Avg"],
        pm10: ["PM10_Avg", "PM10", "PM_10_Avg"],
        particulateCount: ["partic_Avg", "partic", "Particulate_Avg", "Particulate_Count"],
        so2: ["SO2__Avg", "SO2_Avg", "SO2"],
        moduleTemperature: ["MOD_TEMP_Avg", "MOD_TEMP", "ModTemp_Avg", "Module_Temp_Avg"],
        uvIndex: ["UV_Index_Avg", "UV_Index", "UVI", "UV_Avg"],
        lightning: ["Lightning_Tot", "Lightning_Count", "Lightning"],
        lightningDistance: ["LightningDist", "Lightning_Dist", "LightningDist_Avg", "Lightning_Distance"],
        lightningEnergy: ["LightningEnergy", "Lightning_Energy", "LightningEnergy_Avg"],
        waterLevel: ["Water_Level_Avg", "WaterLevel", "Water_Level"],
        chargerVoltage: ["DC_Chg_Volts", "ChgV_Avg", "Charger_V", "SolarCharger_V"],
        temperatureSwitch: ["Temp_Switch_Avg", "TempSwitch", "Temp_Switch"],
        levelSwitch: ["Level_Switch", "LevelSwitch", "Level_Switch_Avg"],
        temperatureSwitchOutlet: ["Temp_Switch_Outlet", "TempSwitchOutlet"],
        levelSwitchStatus: ["Level_Switch_Status", "LevelSwitchStatus"],
        windDirStdDev: ["Wind_Dir_SD1_WVT", "WindDir_SD1_WVT", "WDir_SD1_WVT", "WDir_1_Std", "WDir_Std", "WDir_2_Std"],
        sdi12WindVector: ["SDI12_WVc", "SDI12_WV", "SDI12_Wind"],
        pumpSelectWell: ["Pump_Select_Well", "PumpSelectWell", "Pump_Well"],
        pumpSelectBore: ["Pump_Select_Bore", "PumpSelectBore", "Pump_Bore"],
        portStatusC1: ["Port_Status_C1", "PortStatusC1", "Port_C1"],
        portStatusC2: ["Port_Status_C2", "PortStatusC2", "Port_C2"],
        // Airshed / multi-height temperature
        temperature8m: ["Temp8m_Avg", "Temp_8m_Avg", "Temp8m", "AirTC_8m_Avg"],
        deltaTemperature: ["DeltaTemp_Avg", "Delta_Temp_Avg", "DeltaTemp", "Delta_T_Avg"],
        // Visibility
        visibility: ["Visibility_km", "Visibility", "Vis_km", "Visibility_Avg"],
        visibilityVolt: ["Visibility_Volt", "Vis_Volt", "Visibility_V"],
        // Lightning Raw
        lightningRaw: ["Lightning_Raw", "LightningRaw", "Lightning_mA"],
        // MPPT Solar Charge Controller fields (Charger 1)
        mpptSolarVoltage: ["MPPT_SolV_Avg", "MPPT_SolarVoltage", "Solar_Voltage", "SolV_Avg", "MPPT_Vsol", "Vsol_Avg", "SolarCharger_PanelVoltage_1_Avg"],
        mpptSolarCurrent: ["MPPT_SolI_Avg", "MPPT_SolarCurrent", "Solar_Current", "SolI_Avg", "MPPT_Isol", "Isol_Avg", "SolarCharger_PanelCurrent_1_Avg"],
        mpptSolarPower: ["MPPT_SolP_Avg", "MPPT_SolarPower", "Solar_Power", "SolP_Avg", "MPPT_Psol", "Psol_Avg", "SolarCharger_PanelPower_1_Avg"],
        mpptLoadVoltage: ["MPPT_LdV_Avg", "MPPT_LoadVoltage", "Load_Voltage", "LdV_Avg", "MPPT_Vload", "Vload_Avg", "SolarCharger_LoadVoltage_1_Avg"],
        mpptLoadCurrent: ["MPPT_LdI_Avg", "MPPT_LoadCurrent", "Load_Current", "LdI_Avg", "MPPT_Iload", "Iload_Avg", "SolarCharger_LoadCurrent_1_Avg"],
        mpptBatteryVoltage: ["MPPT_BatV_Avg", "MPPT_BatteryVoltage", "MPPT_Vbat", "Vbat_Avg", "SolarCharger_BatteryVoltage_1_Avg"],
        mpptChargerState: ["MPPT_ChgS", "MPPT_ChargerState", "Charger_State", "ChgState", "MPPT_State", "SolarCharger_State_1"],
        mpptAbsiAvg: ["MPPT_ABSI_Avg", "MPPT_ABSI", "ABSI_Avg"],
        mpptBoardTemp: ["SolarCharger_BoardTemp_1_Avg", "MPPT_BoardTemp", "MPPT_Temp"],
        mpptMode: ["SolarCharger_Mode_1", "MPPT_Mode"],
        // MPPT Charger 1 configuration
        mpptBulkFloatVoltage: ["SolarCharger_BulkFloatVoltage_1", "MPPT_BulkFloatVoltage"],
        mpptFloatVoltage: ["SolarCharger_FloatVoltage_1", "MPPT_FloatVoltage"],
        mpptCurrentLimit: ["SolarCharger_CurrentLimit_1", "MPPT_CurrentLimit"],
        mpptAbsorbTimeLimit: ["SolarCharger_AbsorbTimeLimit_1", "MPPT_AbsorbTimeLimit"],
        mpptAbsorbFullCurrent: ["SolarCharger_AbsorbFullCurrent_1", "MPPT_AbsorbFullCurrent"],
        mpptVCalSlope: ["SolarCharger_VCalSlope_1", "MPPT_VCalSlope"],
        mpptICalSlope: ["SolarCharger_ICalSlope_1", "MPPT_ICalSlope"],
        // MPPT Solar Charge Controller fields (Charger 2)
        mppt2SolarVoltage: ["SolarCharger_PanelVoltage_2_Avg", "MPPT2_SolV_Avg", "MPPT2_SolarVoltage"],
        mppt2SolarCurrent: ["SolarCharger_PanelCurrent_2_Avg", "MPPT2_SolI_Avg", "MPPT2_SolarCurrent"],
        mppt2SolarPower: ["SolarCharger_PanelPower_2_Avg", "MPPT2_SolP_Avg", "MPPT2_SolarPower"],
        mppt2LoadVoltage: ["SolarCharger_LoadVoltage_2_Avg", "MPPT2_LdV_Avg", "MPPT2_LoadVoltage"],
        mppt2LoadCurrent: ["SolarCharger_LoadCurrent_2_Avg", "MPPT2_LdI_Avg", "MPPT2_LoadCurrent"],
        mppt2BatteryVoltage: ["SolarCharger_BatteryVoltage_2_Avg", "MPPT2_BatV_Avg", "MPPT2_BatteryVoltage"],
        mppt2ChargerState: ["SolarCharger_State_2", "MPPT2_ChgS", "MPPT2_ChargerState"],
        mppt2BoardTemp: ["SolarCharger_BoardTemp_2_Avg", "MPPT2_BoardTemp", "MPPT2_Temp"],
        mppt2Mode: ["SolarCharger_Mode_2", "MPPT2_Mode"],
        // MPPT Charger 2 configuration
        mppt2BulkFloatVoltage: ["SolarCharger_BulkFloatVoltage_2", "MPPT2_BulkFloatVoltage"],
        mppt2FloatVoltage: ["SolarCharger_FloatVoltage_2", "MPPT2_FloatVoltage"],
        mppt2CurrentLimit: ["SolarCharger_CurrentLimit_2", "MPPT2_CurrentLimit"],
        mppt2AbsorbTimeLimit: ["SolarCharger_AbsorbTimeLimit_2", "MPPT2_AbsorbTimeLimit"],
        mppt2AbsorbFullCurrent: ["SolarCharger_AbsorbFullCurrent_2", "MPPT2_AbsorbFullCurrent"],
        mppt2VCalSlope: ["SolarCharger_VCalSlope_2", "MPPT2_VCalSlope"],
        mppt2ICalSlope: ["SolarCharger_ICalSlope_2", "MPPT2_ICalSlope"],
    };
    const result = {};
    for (const [standardField, possibleNames] of Object.entries(fieldMappings)) {
        if (!Array.isArray(possibleNames))
            continue;
        for (const name of possibleNames) {
            if (!name)
                continue;
            const value = record.data[name];
            if (value !== undefined && value !== null) {
                // Safely convert to number with validation
                if (typeof value === "number" && !isNaN(value) && isFinite(value)) {
                    result[standardField] = value;
                    break;
                }
                else if (typeof value === "string") {
                    const parsed = parseFloat(value);
                    if (!isNaN(parsed) && isFinite(parsed)) {
                        result[standardField] = parsed;
                        break;
                    }
                }
            }
        }
        // Initialise to null if not found
        if (result[standardField] === undefined) {
            result[standardField] = null;
        }
    }
    // Wind speed: preserve original units from DAT file (m/s or km/h)
    // Unit detection is handled by detectWindSpeedUnit() — no conversion here.
    // Convert charger voltage from mV to V if the source unit is mV
    if (result['chargerVoltage'] !== null && result['chargerVoltage'] !== undefined && headers && units) {
        const chargerAliases = fieldMappings['chargerVoltage'];
        if (chargerAliases) {
            for (const alias of chargerAliases) {
                const headerIdx = headers.indexOf(alias);
                if (headerIdx >= 0 && headerIdx < units.length) {
                    const unit = units[headerIdx]?.toLowerCase()?.trim();
                    if (unit === 'mv' || unit === 'millivolts') {
                        result['chargerVoltage'] = result['chargerVoltage'] / 1000; // mV → V
                    }
                    break;
                }
            }
        }
        // Sanity check: if charger voltage > 100V, it's likely in mV (unreasonable for a solar charger)
        if (result['chargerVoltage'] > 100) {
            result['chargerVoltage'] = result['chargerVoltage'] / 100;
        }
    }
    // Sanity check solar radiation: cap at physically realistic max (~1500 W/m²)
    // Values above this indicate raw/uncalibrated sensor readings
    if (result['solarRadiation'] !== null && result['solarRadiation'] !== undefined) {
        if (result['solarRadiation'] > 2000) {
            // Likely raw mV or miscalibrated — store null to avoid misleading charts
            result['solarRadiation'] = null;
        }
    }
    // Clamp relative humidity to 0–100% (capacitive sensors can read slightly above 100% in saturated air)
    if (result['humidity'] !== null && result['humidity'] !== undefined) {
        result['humidity'] = Math.min(100, Math.max(0, result['humidity']));
    }
    return result;
}
/**
 * Detect wind speed unit from DAT file headers/units rows.
 * Returns 'kmh' if any wind speed column has km/h unit, otherwise 'ms'.
 */
function detectWindSpeedUnit(headers, units) {
    if (!headers || !units)
        return 'ms';
    const windAliases = [
        "WS_ms", "WS_Avg", "WindSpd", "Wind_Speed", "WS_kph",
        "Wind_Spd_S_WVT", "WindSpeed_Avg", "WS_ms_Avg", "WS_ms_S_WVT",
        "WSpd_1_Avg", "WSpd_Avg", "WSpd_1_S_WVT", "WSpd_2_Avg",
        "WS_Max", "WindGust", "Gust_ms", "Wind_Spd_Max",
        "WindSpeed_Max", "WS_ms_Max", "Wind_Gust", "WSpd_1_Max", "WSpd_Max",
    ];
    for (const alias of windAliases) {
        const idx = headers.indexOf(alias);
        if (idx >= 0 && idx < units.length) {
            const unit = units[idx]?.toLowerCase()?.trim();
            if (unit === 'km/h' || unit === 'kph' || unit === 'kmh') {
                return 'kmh';
            }
        }
    }
    return 'ms';
}
