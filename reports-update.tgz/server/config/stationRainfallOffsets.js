"use strict";
// Stratus Weather Server
// Created by Lukas Esterhuizen
Object.defineProperty(exports, "__esModule", { value: true });
exports.STATION_RAINFALL_OFFSETS = void 0;
exports.applyRainfallOffset = applyRainfallOffset;
/**
 * Per-station rainfall offset configuration.
 *
 * Some stations (e.g. RIKA cloud-fed devices) report a CUMULATIVE rainfall
 * counter that includes rain accumulated before the device was integrated
 * into Stratus. The offset is the cumulative value AT THE POINT OF INTEGRATION
 * — subtracting it gives the cumulative rain since integration.
 *
 * The offset is also useful for suppressing PHANTOM RAIN after a hardware
 * counter reset: if the device counter drops to 0 and slowly climbs back,
 * `Math.max(0, raw - offset)` keeps the displayed value at 0 until the
 * counter exceeds the previous cumulative high, preventing the post-reset
 * climb from being counted as new rainfall.
 *
 * Apply the same transform anywhere rainfall is summed/aggregated so that
 * monthly (client-side) and yearly (server-side) totals stay consistent.
 */
exports.STATION_RAINFALL_OFFSETS = {
    // RIKA R25021205 — counter reset history; offset suppresses phantom rain
    // after each hardware reset by clamping post-reset values back to 0
    // until they exceed the original integration baseline.
    2: 212,
};
/**
 * Apply the per-station rainfall offset, clamping negatives to 0.
 * Returns the raw value unchanged if no offset is configured.
 */
function applyRainfallOffset(stationId, raw) {
    if (raw === null || raw === undefined)
        return raw;
    const offset = exports.STATION_RAINFALL_OFFSETS[stationId];
    if (!offset)
        return raw;
    return Math.max(0, raw - offset);
}
