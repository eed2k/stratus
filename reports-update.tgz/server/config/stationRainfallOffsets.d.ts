/**
 * Per-station rainfall offset configuration.
 *
 * Some stations (e.g. RIKA cloud-fed devices) report a CUMULATIVE rainfall
 * counter that includes rain accumulated before the device was integrated
 * into Stratus. The offset is the cumulative value AT THE POINT OF INTEGRATION
 * — subtracting it gives the cumulative rain since integration.
 *
 * The offset is also useful for suppressing PHANTOM RAIN after a hardware
 * counter reset: if the device counter drops to 0 and slowly climbs back,
 * `Math.max(0, raw - offset)` keeps the displayed value at 0 until the
 * counter exceeds the previous cumulative high, preventing the post-reset
 * climb from being counted as new rainfall.
 *
 * Apply the same transform anywhere rainfall is summed/aggregated so that
 * monthly (client-side) and yearly (server-side) totals stay consistent.
 */
export declare const STATION_RAINFALL_OFFSETS: Record<number, number>;
/**
 * Apply the per-station rainfall offset, clamping negatives to 0.
 * Returns the raw value unchanged if no offset is configured.
 */
export declare function applyRainfallOffset(stationId: number, raw: number | null): number | null;
