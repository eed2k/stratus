/**
 * Logger Utility
 *
 * Centralized logging for the Stratus server.
 * In production, logs can be configured to write to files,
 * or be silenced based on log level.
 *
 * Log Levels:
 * - error: Critical errors that need attention
 * - warn: Warning conditions
 * - info: Informational messages (default in production)
 * - debug: Detailed debugging information (disabled in production)
 */
type LogLevel = 'error' | 'warn' | 'info' | 'debug';
interface LoggerConfig {
    level: LogLevel;
    prefix?: string;
    silent?: boolean;
}
declare class Logger {
    private config;
    constructor(config?: Partial<LoggerConfig>);
    private shouldLog;
    private formatMessage;
    error(message: string, ...args: unknown[]): void;
    warn(message: string, ...args: unknown[]): void;
    info(message: string, ...args: unknown[]): void;
    debug(message: string, ...args: unknown[]): void;
    /**
     * Create a child logger with a specific prefix
     */
    child(prefix: string): Logger;
}
declare const logger: Logger;
export declare const authLogger: Logger;
export declare const dbLogger: Logger;
export declare const campbellLogger: Logger;
export declare const apiLogger: Logger;
export declare const wsLogger: Logger;
export declare const syncLogger: Logger;
export declare const fileWatcherLogger: Logger;
export declare const emailLogger: Logger;
export { Logger };
export default logger;
