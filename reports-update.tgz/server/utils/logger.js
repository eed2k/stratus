"use strict";
// Stratus Weather Server
// Created by Lukas Esterhuizen
Object.defineProperty(exports, "__esModule", { value: true });
exports.Logger = exports.emailLogger = exports.fileWatcherLogger = exports.syncLogger = exports.wsLogger = exports.apiLogger = exports.campbellLogger = exports.dbLogger = exports.authLogger = void 0;
const LOG_LEVELS = {
    error: 0,
    warn: 1,
    info: 2,
    debug: 3,
};
// Get log level from environment or default to 'info' in production, 'debug' in development
const getDefaultLevel = () => {
    const envLevel = process.env.LOG_LEVEL?.toLowerCase();
    if (envLevel && LOG_LEVELS[envLevel] !== undefined) {
        return envLevel;
    }
    return process.env.NODE_ENV === 'production' ? 'info' : 'debug';
};
class Logger {
    constructor(config = {}) {
        this.config = {
            level: config.level || getDefaultLevel(),
            prefix: config.prefix,
            silent: config.silent || false,
        };
    }
    shouldLog(level) {
        if (this.config.silent)
            return false;
        return LOG_LEVELS[level] <= LOG_LEVELS[this.config.level];
    }
    formatMessage(level, message) {
        const timestamp = new Date().toISOString();
        const prefix = this.config.prefix ? `[${this.config.prefix}]` : '';
        return `${timestamp} ${level.toUpperCase()} ${prefix} ${message}`;
    }
    error(message, ...args) {
        if (this.shouldLog('error')) {
            console.error(this.formatMessage('error', message), ...args);
        }
    }
    warn(message, ...args) {
        if (this.shouldLog('warn')) {
            console.warn(this.formatMessage('warn', message), ...args);
        }
    }
    info(message, ...args) {
        if (this.shouldLog('info')) {
            console.log(this.formatMessage('info', message), ...args);
        }
    }
    debug(message, ...args) {
        if (this.shouldLog('debug')) {
            console.log(this.formatMessage('debug', message), ...args);
        }
    }
    /**
     * Create a child logger with a specific prefix
     */
    child(prefix) {
        return new Logger({
            ...this.config,
            prefix: this.config.prefix ? `${this.config.prefix}:${prefix}` : prefix,
        });
    }
}
exports.Logger = Logger;
// Default logger instance
const logger = new Logger();
// Named loggers for different modules
exports.authLogger = logger.child('Auth');
exports.dbLogger = logger.child('DB');
exports.campbellLogger = logger.child('Campbell');
exports.apiLogger = logger.child('API');
exports.wsLogger = logger.child('WebSocket');
exports.syncLogger = logger.child('Sync');
exports.fileWatcherLogger = logger.child('FileWatcher');
exports.emailLogger = logger.child('Email');
exports.default = logger;
